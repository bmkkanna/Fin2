package com.aug.core;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ResourceBundle;

import org.json.JSONObject;

public class AugmentedCoreService {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
			String token  = callSingleSingOnApi( args[0],  args[1]);
			System.out.println(token);
			}catch(Exception e) {
				e.printStackTrace();
			}

	}
	public static String callSingleSingOnApi(String userName, String password) throws IOException {
		URL url;
		String token = null;
//		ResourceBundle rd
//        = ResourceBundle.getBundle("system");
		try {
			url = new URL(
					"http://localhost:8080/bfweb/retail/MisysSSOFBPService/SSOloginService");
			HttpURLConnection conn = (HttpURLConnection) url.openConnection();
			conn.setRequestMethod("POST");

			// Set the request headers
			conn.setRequestProperty("Content-Type", "application/json");
			// conn.setRequestProperty("Authorization", "Bearer your-access-token");
			conn.setDoOutput(true);
			JSONObject json = new JSONObject();
			json.put("password", password);
			json.put("userName", userName);
			// String jsonInputString = "{\"password\":\"retail\",\"userName\":\"retail\"}";
			String jsonInputString = json.toString();
			try (OutputStream os = conn.getOutputStream()) {
				byte[] input = jsonInputString.getBytes("utf-8");
				os.write(input, 0, input.length);
			}
			int responseCode = conn.getResponseCode();
			if (responseCode == HttpURLConnection.HTTP_OK) {
				try (BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream()))) {
					StringBuilder response = new StringBuilder();
					String responseLine = null;
					while ((responseLine = br.readLine()) != null) {
						response.append(responseLine.trim());
					}
					
					JSONObject json1 = new JSONObject(response.toString());
					String token1 = json1.getString("result");
					System.out.println("token1 :"+token1);
					token = response.toString();
				} catch (Exception ex) {
					System.out.println("Single singn on service failed...");
					return ex.getMessage();
				}
			} else {
				System.out.println("Single singn on service failed..." + conn.getResponseMessage());
				return conn.getResponseMessage();
			}
		} catch (MalformedURLException e) {
			e.printStackTrace();
			return e.getMessage();
		}
		return token;
	}

}
