package com.api.demo;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.UUID;

import org.json.JSONObject;

public class APICall {
	public static void main(String[] args) {
		try {

			String nationalTyepId = "5432199";
			String token = callSingleSingOnApi();
			if (null != token) {
				System.out.println("Token Generated:- " + token);
				String partyId = callCreatePartyAPI(token, nationalTyepId);
				System.out.println("Party Created :- " + partyId);
				String partyDetails = callReadPartyApi(token, partyId);
				JSONObject json = new JSONObject(partyDetails);
				System.out.println("Read party Api details:- " + json);
				/*String accountDetails = createAccount(token);
				System.out.println(" accountDetails :"+accountDetails);*/

			}
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

	private static String createAccount(String token) throws IOException {
		URL url;
		String acocuntId = null;
		try {
			url = new URL("http://ec2-3-81-230-232.compute-1.amazonaws.com:8080/bfweb/retail/v1/accounts/term-deposits");
			HttpURLConnection conn = (HttpURLConnection) url.openConnection();
			conn.setRequestMethod("POST");

			JSONObject json = new JSONObject(token.toString());
			String actualToken1 = json.getString("result");
			// Set the request headers
			conn.setRequestProperty("Content-Type", "application/json");
			conn.setRequestProperty("Authorization", actualToken1);
			conn.setRequestProperty("X-Request-ID", UUID.randomUUID().toString());
			conn.setRequestProperty("Idempotency-Key", UUID.randomUUID().toString());
			
			conn.setDoOutput(true);

			String jsonInputString = "{\r\n" + "  \"accountOwnership\": \"SOLE\",\r\n"
					+ "  \"branchCode\": \"00000001\",\r\n" + "  \"customerId\": \"000000001\",\r\n"
					+ "  \"fundingAccountId\": \"010101000000100\",\r\n"
					+ "  \"maturityInstructions\": \"CAPITALISE\",\r\n" + "  \"modeOfOperation\": \"SOLE\",\r\n"
					+ "  \"principal\": {\r\n" + "    \"currency\": \"USD\",\r\n" + "    \"value\": 20000\r\n"
					+ "  },\r\n" + "  \"productId\": \"03010DEFAULTUSD\",\r\n" + "  \"startDate\": \"2025-02-28\",\r\n"
					+ "  \"tenor\": {\r\n" + "    \"frequency\": \"DAY\",\r\n" + "    \"value\": 60\r\n" + "  }\r\n"
					+ "}";
			try (OutputStream os = conn.getOutputStream()) {
				byte[] input = jsonInputString.getBytes("utf-8");
				os.write(input, 0, input.length);
			}
			int responseCode = conn.getResponseCode();
			if (responseCode == HttpURLConnection.HTTP_CREATED) {
				try (BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream()))) {
					StringBuilder response = new StringBuilder();
					String responseLine = null;
					while ((responseLine = br.readLine()) != null) {
						response.append(responseLine.trim());
					}
					JSONObject json1 = new JSONObject(response.toString());
					acocuntId = json1.getString("accountId");
				} catch (Exception ex) {
					System.out.println("Create party service failed...");
				}
			} else {
				System.out.println("Create party service failed..." + conn.getResponseMessage());
			}
		} catch (MalformedURLException e) {
			e.printStackTrace();
		}
		return acocuntId;
	}

	private static String callCreatePartyAPI(String actualToken, String nationalTypeId) throws IOException {
		URL url;
		String partyId = null;
		try {
			url = new URL("http://ec2-3-81-230-232.compute-1.amazonaws.com:8080/bfweb/retail/v1/party/");
			HttpURLConnection conn = (HttpURLConnection) url.openConnection();
			conn.setRequestMethod("POST");

			JSONObject json = new JSONObject(actualToken.toString());
			String actualToken1 = json.getString("result");
			// Set the request headers
			conn.setRequestProperty("Content-Type", "application/json");
			conn.setRequestProperty("Authorization", actualToken1);
			conn.setRequestProperty("X-Request-ID", UUID.randomUUID().toString());
			conn.setDoOutput(true);

			String jsonInputString = "{\r\n" + "  \"basicDetails\": {\r\n" + "    \"activeSWIFTCustomer\": true,\r\n"
					+ "    \"addressDetails\": [\r\n" + "      {\r\n"
					+ "        \"addressLine1\": \"Bagmane Constellation Business Park\",\r\n"
					+ "        \"addressLine2\": \"4th, 5th & 6th Floor\",\r\n"
					+ "        \"addressLine3\": \"North Block\",\r\n"
					+ "        \"addressLine4\": \"Virgo Building\",\r\n"
					+ "        \"addressLine5\": \"Outer Ring Rd\",\r\n"
					+ "        \"addressLine6\": \"Doddanekundi\",\r\n"
					+ "        \"addressLine7\": \"Marathahalli Post\",\r\n"
					+ "        \"addressLine8\": \"Opposite Soul Space Arena Mall\",\r\n"
					+ "        \"addressLine9\": \"Next to Bagmane World Technology Centre\",\r\n"
					+ "        \"addressStatus\": \"OWNER\",\r\n"
					+ "        \"addressStatusDescription\": \"Owner\",\r\n" + "        \"addressType\": \"3\",\r\n"
					+ "        \"addressTypeDescription\": \"Correspondence Address\",\r\n"
					+ "        \"country\": \"IND\",\r\n" + "        \"countryDescription\": \"India\",\r\n"
					+ "        \"dunsNumber\": \"832532951\",\r\n" + "        \"fromDate\": \"2018-10-30\",\r\n"
					+ "        \"goneAway\": false,\r\n" + "        \"isDefault\": true,\r\n"
					+ "        \"postCode\": \"W26BD\",\r\n" + "        \"principalContact\": \"Calvin\",\r\n"
					+ "        \"stateOrProvince\": \"KA\",\r\n"
					+ "        \"stateOrProvinceDescription\": \"KARNATAKA\",\r\n"
					+ "        \"toDate\": \"2028-10-29\",\r\n" + "        \"townOrCity\": \"Bangalore\"\r\n"
					+ "      }\r\n" + "    ],\r\n" + "    \"bankPartyStatus\": {\r\n"
					+ "      \"effectiveDate\": \"2018-10-02\",\r\n"
					+ "      \"reason\": \"Watchlisted on OFAC list\",\r\n" + "      \"status\": \"001\",\r\n"
					+ "      \"statusDescription\": \"Active\"\r\n" + "    },\r\n"
					+ "    \"branchCode\": \"00000001\",\r\n" + "    \"branchName\": \"Head Office\",\r\n"
					+ "    \"chargeFundingAccount\": \"567072639872\",\r\n" + "    \"contactDetails\": [\r\n"
					+ "      {\r\n" + "        \"areaCode\": \"080\",\r\n" + "        \"contactMethod\": \"SMS\",\r\n"
					+ "        \"contactMethodDescription\": \"Mobile\",\r\n"
					+ "        \"contactName\": \"Savio\",\r\n"
					+ "        \"contactPosition\": \"General Manager\",\r\n"
					+ "        \"contactType\": \"PERSONALMOBILE\",\r\n"
					+ "        \"contactTypeDescription\": \"Personal\",\r\n"
					+ "        \"contactValue\": \"9762656362\",\r\n" + "        \"fromDate\": \"2018-10-31\",\r\n"
					+ "        \"isdCode\": \"+91\",\r\n" + "        \"useForContact\": true\r\n" + "      }\r\n"
					+ "    ],\r\n" + "    \"documentCollectionStatus\": \"DOCCOLLECTED\",\r\n"
					+ "    \"documentCollectionStatusDescription\": \"Documents collected and validated centrally\",\r\n"
					+ "    \"isConsolidateStatementRequired\": false,\r\n"
					+ "    \"isInternetBankingEnabled\": false,\r\n" + "    \"isMobileBankingEnabled\": false,\r\n"
					+ "    \"isWithHoldingTaxLiable\": true,\r\n" + "    \"kycExpiryDate\": \"2021-01-02\",\r\n"
					+ "    \"kycStatus\": \"001\",\r\n" + "    \"kycStatusDescription\": \"Compliant\",\r\n"
					+ "    \"languageId\": \"EN\",\r\n" + "    \"lineOfBusinesses\": [\r\n" + "      {\r\n"
					+ "        \"lineOfBusiness\": \"COREBANKING\",\r\n"
					+ "        \"lineOfBusinessDescription\": \"Core Banking\"\r\n" + "      }\r\n" + "    ],\r\n"
					+ "    \"localityType\": \"LOCALPRIVATE\",\r\n"
					+ "    \"localityTypeDescription\": \"Local Private\",\r\n"
					+ "    \"partyAlternativeId\": \"0067\",\r\n" + "    \"partyCategory\": \"PROSPECT\",\r\n"
					+ "    \"partyCategoryDescription\": \"Prospect\",\r\n"
					+ "    \"partyStatusDescription\": \"Accepted\",\r\n" + "    \"partySubType\": \"100\",\r\n"
					+ "    \"partySubTypeDescription\": \"Individual\",\r\n" + "    \"partyType\": \"1062\",\r\n"
					+ "    \"partyTypeDescription\": \"Personal\",\r\n" + "    \"publicPartyStatuses\": [\r\n"
					+ "      {\r\n" + "        \"effectiveDate\": \"2018-01-02\",\r\n"
					+ "        \"reason\": \"Death\",\r\n" + "        \"status\": \"007\",\r\n"
					+ "        \"statusDescription\": \"Deceased\"\r\n" + "      }\r\n" + "    ],\r\n"
					+ "    \"relationManager\": \"demobank\",\r\n" + "    \"roleDetails\": [\r\n" + "      {\r\n"
					+ "        \"effectiveDate\": \"2018-01-02\",\r\n" + "        \"reason\": \"auto\",\r\n"
					+ "        \"role\": \"POLICYHOLD\",\r\n" + "        \"roleDescription\": \"Policy Holder\"\r\n"
					+ "      }\r\n" + "    ],\r\n" + "    \"segmentCategory\": \"GOLD\",\r\n"
					+ "    \"segmentCategoryDescription\": \"Gold\",\r\n"
					+ "    \"segmentEffectiveFrom\": \"2018-10-30\",\r\n" + "    \"shortName\": \"Jos\",\r\n"
					+ "    \"signTxnReference\": \"123PER8JD\",\r\n"
					+ "    \"taxExemptionReason\": \"TAXEXEMPTIONREASON1\",\r\n"
					+ "    \"taxExemptionReasonDescription\": \"Individual without income\"\r\n" + "  },\r\n"
					+ "  \"isKYCCheckInParty\": false,\r\n" + "  \"personalDetails\": {\r\n"
					+ "    \"civilStatus\": \"MARITAL_STATUS_04\",\r\n"
					+ "    \"civilStausDescription\": \"Married\",\r\n" + "    \"countryBirth\": \"IND\",\r\n"
					+ "    \"countryBirthDescription\": \"India\",\r\n" + "    \"countryCitizen\": \"IND\",\r\n"
					+ "    \"countryCitizenDescription\": \"India\",\r\n" + "    \"countryResidency\": \"IND\",\r\n"
					+ "    \"countryResidencyDescription\": \"India\",\r\n" + "    \"dateOfBirth\": \"1991-08-22\",\r\n"
					+ "    \"employmentDetails\": [\r\n" + "      {\r\n"
					+ "        \"businessType\": \"FORESTRYLOGGING\",\r\n"
					+ "        \"businessTypeDescription\": \"Forestry, logging and related service activities\",\r\n"
					+ "        \"contractEndDate\": \"2021-06-10\",\r\n" + "        \"employeeId\": \"711804\",\r\n"
					+ "        \"employerAddressDetails\": [\r\n" + "          {\r\n"
					+ "            \"addressLine1\": \"Bagmane Constellation Business Park\",\r\n"
					+ "            \"addressLine2\": \"4th, 5th & 6th Floor\",\r\n"
					+ "            \"addressLine3\": \"North Block\",\r\n"
					+ "            \"addressLine4\": \"Virgo Building\",\r\n"
					+ "            \"addressLine5\": \"Outer Ring Rd\",\r\n"
					+ "            \"addressLine6\": \"Doddanekundi\",\r\n"
					+ "            \"addressLine7\": \"Marathahalli Post\",\r\n"
					+ "            \"addressLine8\": \"Opposite Soul Space Arena Mall\",\r\n"
					+ "            \"addressLine9\": \"Next to Bagmane World Technology Centre\",\r\n"
					+ "            \"addressStatus\": \"OWNER\",\r\n"
					+ "            \"addressStatusDescription\": \"Owner\",\r\n"
					+ "            \"addressType\": \"3\",\r\n"
					+ "            \"addressTypeDescription\": \"Correspondence Address\",\r\n"
					+ "            \"country\": \"IND\",\r\n" + "            \"countryDescription\": \"India\",\r\n"
					+ "            \"dunsNumber\": \"832532951\",\r\n" + "            \"fromDate\": \"2018-10-30\",\r\n"
					+ "            \"goneAway\": false,\r\n" + "            \"isDefault\": true,\r\n"
					+ "            \"postCode\": \"W26BD\",\r\n" + "            \"principalContact\": \"Calvin\",\r\n"
					+ "            \"stateOrProvince\": \"KA\",\r\n"
					+ "            \"stateOrProvinceDescription\": \"KARNATAKA\",\r\n"
					+ "            \"toDate\": \"2028-10-29\",\r\n" + "            \"townOrCity\": \"Bangalore\"\r\n"
					+ "          }\r\n" + "        ],\r\n" + "        \"employerPhoneNum\": \"080404999\",\r\n"
					+ "        \"employmentType\": \"FULLTIME\",\r\n"
					+ "        \"employmentTypeDescription\": \"Full Time\",\r\n"
					+ "        \"grossAnnualSalary\": 30000,\r\n"
					+ "        \"grossAnnualSalaryCurrencyCode\": \"EUR\",\r\n" + "        \"isCurrent\": true,\r\n"
					+ "        \"jobFinishDate\": \"2019-06-30\",\r\n" + "        \"jobStartDate\": \"2015-06-01\",\r\n"
					+ "        \"jobTitle\": \"BUSANALYST\",\r\n"
					+ "        \"jobTitleDescription\": \"Business Analyst\",\r\n"
					+ "        \"nameOfTheEmployer\": \"Finastra\",\r\n"
					+ "        \"paymentFrequency\": \"MONTHLY\",\r\n"
					+ "        \"paymentFrequencyDescription\": \"Monthly\",\r\n"
					+ "        \"paymentMethod\": \"CHEQUE\",\r\n"
					+ "        \"paymentMethodDescription\": \"Cheque\"\r\n" + "      }\r\n" + "    ],\r\n"
					+ "    \"employmentStatus\": \"001\",\r\n"
					+ "    \"employmentStatusDescription\": \"Full time\",\r\n"
					+ "    \"fatcaDetailsShortPersonal\": {\r\n" + "      \"isUSResident\": false,\r\n"
					+ "      \"isUSTaxResident\": false,\r\n" + "      \"tin\": \"234581\"\r\n" + "    },\r\n"
					+ "    \"fathersName\": \"David\",\r\n" + "    \"firstName\": \"George\",\r\n"
					+ "    \"gender\": \"002\",\r\n" + "    \"genderDescription\": \"Male\",\r\n"
					+ "    \"grandFathersName\": \"John\",\r\n" + "    \"isTaxPayer\": true,\r\n"
					+ "    \"lastName\": \"Benson\",\r\n" + "    \"middleName\": \"Joseph\",\r\n"
					+ "    \"motherMaidenName\": \"Rose\",\r\n" + "    \"nationalIdNum\": \"+" + nationalTypeId
					+ "\",\r\n" + "    \"nationalTypeId\": \"NATIONAL_ID_001\",\r\n"
					+ "    \"nationalTypeIdDescription\": \"Passport\",\r\n" + "    \"numOfDependents\": 5,\r\n"
					+ "    \"religion\": \"RELIGION3\",\r\n" + "    \"religionDescription\": \"Hinduism\",\r\n"
					+ "    \"residencyStatus\": \"RESIDENT_STATUS_01\",\r\n"
					+ "    \"residencyStatusDescription\": \"India\",\r\n" + "    \"residentState\": \"KA\",\r\n"
					+ "    \"residentStateDescription\": \"Karnataka\",\r\n" + "    \"spouseName\": \"Andrew\",\r\n"
					+ "    \"taxCountry\": \"IND\",\r\n" + "    \"taxCountryDescription\": \"India\",\r\n"
					+ "    \"taxIDNumber\": \"AEFR3890\",\r\n" + "    \"title\": \"001\",\r\n"
					+ "    \"titleDescription\": \"Mr.\",\r\n" + "    \"townBirth\": \"Bengaluru\"\r\n" + "  }\r\n"
					+ "}";
			try (OutputStream os = conn.getOutputStream()) {
				byte[] input = jsonInputString.getBytes("utf-8");
				os.write(input, 0, input.length);
			}
			int responseCode = conn.getResponseCode();
			if (responseCode == HttpURLConnection.HTTP_CREATED) {
				try (BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream()))) {
					StringBuilder response = new StringBuilder();
					String responseLine = null;
					while ((responseLine = br.readLine()) != null) {
						response.append(responseLine.trim());
					}
					JSONObject json1 = new JSONObject(response.toString());
					partyId = json1.getString("partyId");
				} catch (Exception ex) {
					System.out.println("Create party service failed...");
				}
			} else {
				System.out.println("Create party service failed..." + conn.getResponseMessage());
			}
		} catch (MalformedURLException e) {
			e.printStackTrace();
		}
		return partyId;

	}

	private static String callSingleSingOnApi() throws IOException {
		URL url;
		String token = null;
		try {
			url = new URL(
					"http://ec2-3-81-230-232.compute-1.amazonaws.com:8080/bfweb/retail/MisysSSOFBPService/SSOloginService");
			HttpURLConnection conn = (HttpURLConnection) url.openConnection();
			conn.setRequestMethod("POST");

			// Set the request headers
			conn.setRequestProperty("Content-Type", "application/json");
			// conn.setRequestProperty("Authorization", "Bearer your-access-token");
			conn.setDoOutput(true);

			// String jsonInputString = "{\"password\":\"retail\",\"userName\":\"retail\"}";
			String jsonInputString = "{\"password\":\"retail\",\"userName\":\"retail\"}";
			try (OutputStream os = conn.getOutputStream()) {
				byte[] input = jsonInputString.getBytes("utf-8");
				os.write(input, 0, input.length);
			}
			int responseCode = conn.getResponseCode();
			if (responseCode == HttpURLConnection.HTTP_OK) {
				try (BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream()))) {
					StringBuilder response = new StringBuilder();
					String responseLine = null;
					while ((responseLine = br.readLine()) != null) {
						response.append(responseLine.trim());
					}
					
					JSONObject json1 = new JSONObject(response.toString());
					String token1 = json1.getString("result");
					System.out.println("token1 :"+token1);
					token = response.toString();
				} catch (Exception ex) {
					System.out.println("Single singn on service failed...");
				}
			} else {
				System.out.println("Single singn on service failed..." + conn.getResponseMessage());
			}
		} catch (MalformedURLException e) {
			e.printStackTrace();
		}
		return token;
	}

	private static String callReadPartyApi(String token, String partyId) throws IOException {
		URL url;
		String resp = null;
		try {
			url = new URL("http://ec2-3-81-230-232.compute-1.amazonaws.com:8080/bfweb/retail/v1/party/" + partyId);
			HttpURLConnection conn = (HttpURLConnection) url.openConnection();
			conn.setRequestMethod("GET");
			JSONObject json = new JSONObject(token.toString());
			String actualToken = json.getString("result");

			// Set the request headers
			conn.setRequestProperty("Content-Type", "application/json");
			conn.setRequestProperty("Authorization", actualToken);
			conn.setRequestProperty("X-Request-ID", UUID.randomUUID().toString());
			conn.setDoOutput(true);

			int responseCode = conn.getResponseCode();
			if (responseCode == HttpURLConnection.HTTP_OK) {
				try (BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream()))) {
					StringBuilder response = new StringBuilder();
					String responseLine = null;
					while ((responseLine = br.readLine()) != null) {
						response.append(responseLine.trim());
					}
					resp = response.toString();
				} catch (Exception ex) {
					System.out.println("Read party API service failed..." + conn.getResponseMessage());
				}
			} else if (responseCode == HttpURLConnection.HTTP_BAD_REQUEST) {
				System.out.println("Read party API service failed..." + conn.getResponseMessage());
			} else {
				System.out.println("Read party API service failed..." + conn.getResponseMessage());
			}

		} catch (MalformedURLException e) {
			e.printStackTrace();
		}
		return resp;
	}
}
