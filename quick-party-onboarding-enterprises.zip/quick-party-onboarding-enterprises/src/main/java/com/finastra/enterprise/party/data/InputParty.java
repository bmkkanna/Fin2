package com.finastra.enterprise.party.data;

import java.util.ArrayList;

import com.fasterxml.jackson.annotation.JsonIgnore;

public class InputParty {
	private String partyID;
	private Boolean isKYCCheckInParty;
	private InputPartyBasicDetails basicDetails;
	private PartyInputEnterpriseDetails enterpriseDetails;
	private ArrayList<PartyKYCAdditionalDetails> kycAdditionalDetails;
	private String alternatePartyId;
	private String name;
	private String type;
	private String uriPath;
	private String kycStatus;
	private String kycErrorMessage;
	private String outPutParty;
	
	public String getOutPutParty() {
		return outPutParty;
	}

	public void setOutPutParty(String outPutParty) {
		this.outPutParty = outPutParty;
	}

	@JsonIgnore
	private int rownum;

	@JsonIgnore
	private String status;

	@JsonIgnore
	private String errorMessage;

	public int getRownum() {
		return rownum;
	}

	public void setRownum(int rownum) {
		this.rownum = rownum;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getErrorMessage() {
		return errorMessage;
	}

	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}

	public Boolean getIsKYCCheckInParty() {
		return isKYCCheckInParty;
	}

	public void setIsKYCCheckInParty(Boolean isKYCCheckInParty) {
		this.isKYCCheckInParty = isKYCCheckInParty;
	}

	public ArrayList<PartyKYCAdditionalDetails> getKycAdditionalDetails() {
		return kycAdditionalDetails;
	}

	public void setKycAdditionalDetails(ArrayList<PartyKYCAdditionalDetails> kycAdditionalDetails) {
		this.kycAdditionalDetails = kycAdditionalDetails;
	}

	public PartyInputEnterpriseDetails getEnterpriseDetails() {
		return enterpriseDetails;
	}

	public void setEnterpriseDetails(PartyInputEnterpriseDetails enterpriseDetails) {
		this.enterpriseDetails = enterpriseDetails;
	}

	public InputPartyBasicDetails getBasicDetails() {
		return basicDetails;
	}

	public void setBasicDetails(InputPartyBasicDetails basicDetails) {
		this.basicDetails = basicDetails;
	}

	public String getPartyID() {
		return partyID;
	}

	public void setPartyID(String partyID) {
		this.partyID = partyID;
	}

	public String getAlternatePartyId() {
		return alternatePartyId;
	}

	public void setAlternatePartyId(String alternatePartyId) {
		this.alternatePartyId = alternatePartyId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getUriPath() {
		return uriPath;
	}

	public void setUriPath(String uriPath) {
		this.uriPath = uriPath;
	}

	public String getKycStatus() {
		return kycStatus;
	}

	public void setKycStatus(String kycStatus) {
		this.kycStatus = kycStatus;
	}

	public String getKycErrorMessage() {
		return kycErrorMessage;
	}

	public void setKycErrorMessage(String kycErrorMessage) {
		this.kycErrorMessage = kycErrorMessage;
	}

}
