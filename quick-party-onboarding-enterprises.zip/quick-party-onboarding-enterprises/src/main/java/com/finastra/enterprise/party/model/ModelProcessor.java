package com.finastra.enterprise.party.model;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.finastra.enterprise.party.config.AppConfig;
import com.finastra.enterprise.party.data.InputParty;
import com.finastra.enterprise.party.data.InputPartyAddressDetails;
import com.finastra.enterprise.party.data.InputPartyBasicDetails;
import com.finastra.enterprise.party.data.InputPartyLineOfBusinesses;
import com.finastra.enterprise.party.data.InputPartyMainBusinessActivities;
import com.finastra.enterprise.party.data.InputPartyRelationshipDetails;
import com.finastra.enterprise.party.data.OutPutEnterprisParty;
import com.finastra.enterprise.party.data.PartyInputContactDetails;
import com.finastra.enterprise.party.data.PartyInputDocumentDetails;
import com.finastra.enterprise.party.data.PartyInputEnterpriseDetails;
import com.finastra.enterprise.party.data.PartyKYCAdditionalDetails;
import com.finastra.enterprise.party.data.RequestSSOLogin;
import com.finastra.enterprise.party.utility.AppConstants;
import com.finastra.enterprise.party.utility.AppHttpClient;

public class ModelProcessor {

	private static final Logger logger = LoggerFactory.getLogger(ModelProcessor.class);

	AppHttpClient httpClient = null;
	

	public ModelProcessor() {
		super();
		this.httpClient = new AppHttpClient();
	}

	public File obtainInputFileObject(AppConfig appConfig) {
		File file = new File(appConfig.getDirectoryInput() + appConfig.getInputFile());

		return file;
	}

	public List<InputParty> readInputFileAndUpdatePOJO(File inputFile, AppConfig appConfig) {
		List<InputParty> inputPartyList = new ArrayList<InputParty>();

		// obtaining bytes from the file
		FileInputStream fis;
		try {
			fis = new FileInputStream(inputFile);

			// creating Workbook instance that refers to .xlsx file
			XSSFWorkbook wb = new XSSFWorkbook(fis);

			// creating a Sheet object to retrieve object
			XSSFSheet sheet = wb.getSheet(appConfig.getInputSheet());

			// number of rows of newly form excel files
			// int rowCount = sheet.getPhysicalNumberOfRows();
			// logger.info("Total number of rows in the Excel Sheet: " + (rowCount - 1));
			boolean kycckeck = false;
			boolean flag = true;
			Iterator<Row> rowIterator = sheet.iterator();

			// iterating over each row in excel sheet.
			while (rowIterator.hasNext()) {
				Row row = rowIterator.next();
				Iterator<Cell> cellIterator = row.cellIterator();

				InputParty partyDetails = new InputParty();
				partyDetails.setRownum(row.getRowNum());

				InputPartyBasicDetails partyBasicDetails = new InputPartyBasicDetails();
				InputPartyAddressDetails partyAddressDetails = new InputPartyAddressDetails();

				ArrayList<InputPartyAddressDetails> addressDetails = new ArrayList<InputPartyAddressDetails>();
				addressDetails.add(partyAddressDetails);

				InputPartyLineOfBusinesses partyLineOfBusines = new InputPartyLineOfBusinesses();
				ArrayList<InputPartyLineOfBusinesses> lineOfBusinesses = new ArrayList<InputPartyLineOfBusinesses>();
				lineOfBusinesses.add(partyLineOfBusines);

				InputPartyMainBusinessActivities businesActiDetalis = new InputPartyMainBusinessActivities();

				ArrayList<InputPartyMainBusinessActivities> mainBusinessActivities = new ArrayList<InputPartyMainBusinessActivities>();
				mainBusinessActivities.add(businesActiDetalis);

				PartyInputContactDetails partyContactDetails = new PartyInputContactDetails();
				PartyInputContactDetails partyContactDetails1 = new PartyInputContactDetails();
				ArrayList<PartyInputContactDetails> contactDetails = new ArrayList<PartyInputContactDetails>();
				
				contactDetails.add(partyContactDetails);
				contactDetails.add(partyContactDetails1);
				
				PartyInputDocumentDetails partyDocumentDetails = new PartyInputDocumentDetails();
				ArrayList<PartyInputDocumentDetails> documentDetails = new ArrayList<PartyInputDocumentDetails>();
				documentDetails.add(partyDocumentDetails);

				partyBasicDetails.setAddressDetails(addressDetails);
				partyBasicDetails.setContactDetails(contactDetails);
				partyBasicDetails.setDocumentDetails(documentDetails);
				partyBasicDetails.setLineOfBusinesses(lineOfBusinesses);

				PartyInputEnterpriseDetails enterpriseDetails = new PartyInputEnterpriseDetails();
				enterpriseDetails.setMainBusinessActivities(mainBusinessActivities);
				PartyKYCAdditionalDetails AdditionalDetails = new PartyKYCAdditionalDetails();
				
				
				
				ArrayList<InputPartyRelationshipDetails> relationshipDetails = new ArrayList<InputPartyRelationshipDetails>();
				partyBasicDetails.setRelationshipDetails(relationshipDetails);
				

				ArrayList<PartyKYCAdditionalDetails> kycAdditionalDetails = new ArrayList<PartyKYCAdditionalDetails>();
				kycAdditionalDetails.add(AdditionalDetails);
				partyDetails.setBasicDetails(partyBasicDetails);
				partyDetails.setEnterpriseDetails(enterpriseDetails);
				partyDetails.setKycAdditionalDetails(kycAdditionalDetails);
				partyDetails.setIsKYCCheckInParty(kycckeck);
				partyAddressDetails.setIsDefault(flag);
				partyContactDetails1.setContactMethod("");
			
			     String[] relatedPartyIdList=null;
			     String[] relationshipTypeList=null;
			     String[] fromDateList=null;
				

				while (cellIterator.hasNext()) {
					Cell cell = cellIterator.next();
					DataFormatter formatter = new DataFormatter();
					

					if (cell.getColumnIndex() == 0) { // to read the first column
						partyBasicDetails.setLocalityType(cell.getStringCellValue());
						

					} else if (cell.getColumnIndex() == 1) {
						partyBasicDetails.setPartyType(formatter.formatCellValue(cell));
					

					} else if (cell.getColumnIndex() == 2) {
						partyLineOfBusines.setLineOfBusiness(cell.getStringCellValue());
						

					} else if (cell.getColumnIndex() == 3) {
						partyBasicDetails.setPartySubType(cell.getStringCellValue());
					

					} else if (cell.getColumnIndex() == 4) {
						partyBasicDetails.setPartyCategory(cell.getStringCellValue());

					} else if (cell.getColumnIndex() == 5) {
						enterpriseDetails.setEnterpriseName(cell.getStringCellValue());

					} else if (cell.getColumnIndex() == 6) {
						enterpriseDetails.setRegistrationNumber(formatter.formatCellValue(cell));
						

					} else if (cell.getColumnIndex() == 7) {
						enterpriseDetails.setCountryTaxDomicile(cell.getStringCellValue());

					} else if (cell.getColumnIndex() == 8) {
						enterpriseDetails.setCountryOfRegistration(cell.getStringCellValue());

					} else if (cell.getColumnIndex() == 9) {
						enterpriseDetails.setStateOfRegistration(cell.getStringCellValue());

					} else if (cell.getColumnIndex() == 10) {
						
						enterpriseDetails.setDateFormed(formatter.formatCellValue(cell));	

					} else if (cell.getColumnIndex() == 11) {
						enterpriseDetails.setEnterpriseStatus(cell.getStringCellValue());

					} else if (cell.getColumnIndex() == 12) {
						partyBasicDetails.setIsWithHoldingTaxLiable(Boolean.parseBoolean(cell.getStringCellValue()));
						
					} else if (cell.getColumnIndex() == 13) {
						partyBasicDetails.setTaxExemptionReason(cell.getStringCellValue());

					} else if (cell.getColumnIndex() == 14) {
						partyAddressDetails.setAddressType(formatter.formatCellValue(cell));
						

					} else if (cell.getColumnIndex() == 15) {
						partyAddressDetails.setCountry(formatter.formatCellValue(cell));

					} else if (cell.getColumnIndex() == 16) {
						partyAddressDetails.setPostCode(formatter.formatCellValue(cell));
 
					} else if (cell.getColumnIndex() == 17) {
						//partyContactDetails.setContactType(cell.getStringCellValue()); //Email_Contact_Type
						partyContactDetails.setContactType(Optional.ofNullable(cell.getStringCellValue()).orElse("")); //Email_Contact_Type

					} else if (cell.getColumnIndex() == 18) {
						
						partyContactDetails.setContactValue(Optional.ofNullable(cell.getStringCellValue()).orElse("")); //Email

					} else if (cell.getColumnIndex() == 19) {
						
						partyContactDetails1.setContactType(Optional.ofNullable(cell.getStringCellValue()).orElse(""));
						
					} else if (cell.getColumnIndex() == 20) {
						
						partyContactDetails.setAreaCode(cell.getStringCellValue());//area code
										
					} else if (cell.getColumnIndex() == 21) {
						
						partyContactDetails1.setContactValue(Optional.ofNullable(formatter.formatCellValue(cell)).orElse(""));//Mobile_Number_Number					

					} else if (cell.getColumnIndex() == 22) {
						partyAddressDetails.setAddressLine1(formatter.formatCellValue(cell));
						

					} else if (cell.getColumnIndex() == 23) {
						partyAddressDetails.setAddressLine2(cell.getStringCellValue());

					} else if (cell.getColumnIndex() == 24) {
						partyAddressDetails.setAddressLine3(cell.getStringCellValue());

					} else if (cell.getColumnIndex() == 25) {
						partyAddressDetails.setAddressLine4(cell.getStringCellValue());

					} else if (cell.getColumnIndex() == 26) {
						partyAddressDetails.setTownOrCity(cell.getStringCellValue());

					} else if (cell.getColumnIndex() == 27) {
						partyAddressDetails.setStateOrProvince(cell.getStringCellValue());

					} else if (cell.getColumnIndex() == 28) { /////// correctmapping
				
						partyAddressDetails.setIsDefault(Boolean.parseBoolean(cell.getStringCellValue()));		
						
					} else if (cell.getColumnIndex() == 29) {
						partyDocumentDetails.setDocumentCategory(cell.getStringCellValue());

					} else if (cell.getColumnIndex() == 30) { // c
						partyDocumentDetails.setDocumentType(cell.getStringCellValue());

					} else if (cell.getColumnIndex() == 31) {
						partyDocumentDetails.setImageId(formatter.formatCellValue(cell));
					

					} else if (cell.getColumnIndex() == 32) {
						partyDocumentDetails.setValidToDate(formatter.formatCellValue(cell));
					

					} else if (cell.getColumnIndex() == 33) {
						partyDocumentDetails.setIsDocumentVerified(Boolean.parseBoolean(cell.getStringCellValue()));
						
					} else if (cell.getColumnIndex() == 34) {
						partyBasicDetails.setDocumentCollectionStatus(cell.getStringCellValue());

					} else if (cell.getColumnIndex() == 35) { // correct mapping
						partyBasicDetails.setShortName(cell.getStringCellValue());
						
					} else if (cell.getColumnIndex() == 36) {                        //PartyId 36
						//partyDetails.setPartyID(cell.getStringCellValue());
	                  partyDetails.setPartyID(Optional.ofNullable(cell.getStringCellValue()).orElse(""));
							
					} else if (cell.getColumnIndex() == 37) {
						businesActiDetalis.setBusinessActivity(formatter.formatCellValue(cell));
						

					} else if (cell.getColumnIndex() == 38) {
						businesActiDetalis.setCountry(cell.getStringCellValue());//Business_Activity_Country

					} else if (cell.getColumnIndex() == 39) {
						businesActiDetalis.setIndustrySector(formatter.formatCellValue(cell));//Business_Activity_Industry_Sector
						

					} else if (cell.getColumnIndex() == 40) {
						businesActiDetalis.setBusinessFocus(cell.getStringCellValue());//Business_Activity_Business_Focus

					} else if (cell.getColumnIndex() == 41) {
						businesActiDetalis.setBusinessType(cell.getStringCellValue());

					} else if (cell.getColumnIndex() == 42) {
						
							businesActiDetalis.setIsMainActivity(Boolean.parseBoolean(cell.getStringCellValue()));

					} else if (cell.getColumnIndex() == 43) {
							businesActiDetalis.setIsPrimaryActivity(Boolean.parseBoolean(cell.getStringCellValue()));
						
					} else if (cell.getColumnIndex() == 44) {
						partyBasicDetails.setBranchCode(formatter.formatCellValue(cell));

					} else if (cell.getColumnIndex() == 45) {     //Contact_Method-1
						
						partyContactDetails.setContactMethod(Optional.ofNullable(cell.getStringCellValue()).orElse(""));
						
						
					} else if (cell.getColumnIndex() == 46) { //Contact_Method-2
												
						partyContactDetails1.setContactMethod(Optional.ofNullable(cell.getStringCellValue()).orElse(""));
					
					} else if (cell.getColumnIndex() == 47) {     //Date_of_Incorporation
						enterpriseDetails.setDateIncorporated(formatter.formatCellValue(cell));
	
						
					} else if (cell.getColumnIndex() == 48) {      //Date_Commenced_Trading
						enterpriseDetails.setDateCommencedTrading(formatter.formatCellValue(cell));
						
						
					} else if (cell.getColumnIndex() == 49) {      //Related_Party_Id
						
						relatedPartyIdList = cell.getStringCellValue().split(",");
						
					} else if (cell.getColumnIndex() == 50) {      //Relationship_Type
						
						relationshipTypeList = cell.getStringCellValue().split(",");
						
					} else if (cell.getColumnIndex() == 51) {      //From_Date
						
						fromDateList = formatter.formatCellValue(cell).split(",");
						
					} else if (cell.getColumnIndex() == 52) { //Relationship_Percentage
						
						String[] relationshipPercentage = formatter.formatCellValue(cell).split(",");
						for(int i=0;i<relatedPartyIdList.length;i++) {
							InputPartyRelationshipDetails relationshipPartyDetails = new InputPartyRelationshipDetails();
							if(relatedPartyIdList!=null&&i<relatedPartyIdList.length) {
							relationshipPartyDetails.setRelatedPartyId(relatedPartyIdList[i]);
							}
							if(relationshipTypeList!=null&&i<relationshipTypeList.length) {
							relationshipPartyDetails.setRelationshipType(relationshipTypeList[i]);
							}
							if(fromDateList!=null&&i<fromDateList.length) {
							relationshipPartyDetails.setFromDate(fromDateList[i]);
							}
							if(relationshipPercentage!=null&&i<relationshipPercentage.length) {
							relationshipPartyDetails.setRelationshipPercentage(relationshipPercentage[i]);	
							}
							
							relationshipDetails.add(relationshipPartyDetails);
							
						}
						
					} else if (cell.getColumnIndex() == 53) {      //Party_Alternative_Id
						partyBasicDetails.setPartyAlternativeId(formatter.formatCellValue(cell));
	
					} else if (cell.getColumnIndex() == 54) {
						partyDetails.setStatus(cell.getStringCellValue());
						
					} else if (cell.getColumnIndex() == 55) {
						partyDetails.setErrorMessage(cell.getStringCellValue());
						
					} else {
						
					}
				}
				
														
				inputPartyList.add(partyDetails);
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		// Removing Excel file Header from Collection.
		if (inputPartyList.size() > 0) {
			inputPartyList.remove(0);
		}
		inputPartyList.removeIf(acc -> "SUCESS".equals(acc.getStatus()));
		return inputPartyList;
	}

	public String generatePayload(InputParty partyDetails) {

		ObjectMapper objectMapper = new ObjectMapper();
		String payload = "";
		try {
			payload = objectMapper.writeValueAsString(partyDetails);
		} catch (Exception e) {
			e.printStackTrace();
		}

		return payload;
	}

	public HashMap<String, String> makeSSORequest(AppConfig appConfig) {

		// Payload Preparation.
		String payLoad = "";
		RequestSSOLogin reqSSOLogin = new RequestSSOLogin();
		reqSSOLogin.setUserName(appConfig.getUsername());
		reqSSOLogin.setPassword(appConfig.getPassword());
		ObjectMapper objectMapper = new ObjectMapper();
		try {
			payLoad = objectMapper.writeValueAsString(reqSSOLogin);
		} catch (Exception e) {
			e.printStackTrace();
		}

		// Input Params.
		HashMap<String, String> paramMap = null;

		// Prepare url.
		String url = appConfig.getAppBaseUrl() + AppConstants.SSO_LOGIN_URL;

		// Call rest web-service.
		logger.debug("+++++++++ Implementing SSO Login +++++++++++++");
		logger.debug("URL: " + url);
		logger.debug("Payload: " + payLoad);

		HashMap<String, String> responseMap = httpClient.executePostRequest(url, paramMap, payLoad);

		logger.debug("Response Code: " + responseMap.get(AppConstants.HTTP_RESPONSE_STATUS_CODE));
		logger.debug("Response Content: " + responseMap.get(AppConstants.HTTP_RESPONSE_CONTENT));
		logger.debug("++++++++++ SSO Login part completed +++++++++++++++");

		return responseMap;
	}

	public HashMap<String, String> makeSSOLogout(AppConfig appConfig) {

		// Payload Preparation.
		JSONObject jsonObject = new JSONObject();
		jsonObject.put("userLocator", appConfig.getAuthToken());
		String payLoad = jsonObject.toString();

		// Input Params.
		HashMap<String, String> paramMap = null;

		// Prepare url.
		String url = appConfig.getAppBaseUrl() + AppConstants.SSO_LOGOUT_URL;

		// Call rest web-service.
		logger.debug("+++++++++ Implementing SSO Logout +++++++++++++");
		logger.debug("URL: " + url);
		logger.debug("Payload: " + payLoad);

		HashMap<String, String> responseMap = httpClient.executePostRequest(url, paramMap, payLoad);

		logger.debug("Response Code: " + responseMap.get(AppConstants.HTTP_RESPONSE_STATUS_CODE));
		logger.debug("Response Content: " + responseMap.get(AppConstants.HTTP_RESPONSE_CONTENT));
		logger.debug("++++++++++ SSO Logout part completed +++++++++++++++");

		return responseMap;
	}

	public HashMap<String, String> makeQuickOnbordingEntPartyAPICall(String payLoad, AppConfig appConfig) {

		// Input params.
		HashMap<String, String> paramMap = new HashMap<String, String>();
		paramMap.put(AppConstants.AUTHORIZATION_PARAM, appConfig.getAuthToken());
		paramMap.put(AppConstants.X_REQUEST_ID_PARAM, UUID.randomUUID().toString());
		paramMap.put(AppConstants.IDEMPOTENCY_KEY_PARAM, UUID.randomUUID().toString());

		// Prepare URL.
		String url = appConfig.getAppBaseUrl() + AppConstants.PARTY_API_URL;

		// Call rest web-service.
		logger.debug("+++++++++ Implementing Party Create API Call +++++++++++++");
		logger.debug("URL: " + url);
		logger.debug("Payload: " + payLoad);

		HashMap<String, String> responseMap = httpClient.executePostRequest(url, paramMap, payLoad);

		logger.debug("Response Code: " + responseMap.get(AppConstants.HTTP_RESPONSE_STATUS_CODE));
		logger.debug("Response Content: " + responseMap.get(AppConstants.HTTP_RESPONSE_CONTENT));
		logger.debug("++++++++++ Party Create API Call completed +++++++++++++++");

		return responseMap;
	}

	public File checkAndCreateExcelFileIfNotExist(AppConfig appConfig) {

		File outputFile = new File(appConfig.getDirectoryOutput() + appConfig.getOutputFile());

		FileInputStream fis = null;

		// Workbook object
		XSSFWorkbook workbook = null;

		if (outputFile.exists()) {
			try {
				fis = new FileInputStream(outputFile);
				workbook = new XSSFWorkbook(fis);
			} catch (Exception e1) {
				e1.printStackTrace();
			}
		}

		FileOutputStream out = null;
		if (!outputFile.exists()) {
			try {
				logger.debug(AppConstants.OUTPUT_EXCEL_FILE_NOT_EXIST);
				out = new FileOutputStream(outputFile);

				workbook = new XSSFWorkbook();

				// Spreadsheet object
				XSSFSheet spreadsheet = workbook.createSheet(appConfig.getOutputSheet());
				createHeaderRow(spreadsheet);

				workbook.write(out);
				out.close();

				logger.debug(AppConstants.OUTPUT_EXCEL_FILE_CREATED_MSG);
				logger.debug(AppConstants.OUTPUT_EXCEL_SHEET_CREATED_MSG);
			} catch (Exception e) {
				e.printStackTrace();
			}
		} else {
			logger.debug(AppConstants.OUTPUT_EXCEL_FILE_EXISTS);

			// Check Spreadsheet exists or not in Excel file.
			if (workbook.getNumberOfSheets() != 0) {
				boolean isSpreadSheetExist = false;
				for (int i = 0; i < workbook.getNumberOfSheets(); i++) {
					if (workbook.getSheetName(i).equals(appConfig.getOutputSheet())) {
						isSpreadSheetExist = true;
						break;
					}
				}

				if (isSpreadSheetExist) {
					logger.debug(AppConstants.OUTPUT_EXCEL_SHEET_EXISTS);
				} else {
					// Create new sheet to the workbook
					logger.debug(AppConstants.OUTPUT_EXCEL_SHEET_NOT_EXIST);
					XSSFSheet spreadsheet = workbook.createSheet(appConfig.getOutputSheet());
					createHeaderRow(spreadsheet);

					try {
						out = new FileOutputStream(outputFile);
						workbook.write(out);
						out.close();
					} catch (Exception ex) {
						ex.printStackTrace();
					}

					logger.debug(AppConstants.OUTPUT_EXCEL_SHEET_CREATED_MSG);
				}
			} else {
				// Create new sheet to the workbook if empty
				logger.debug(AppConstants.OUTPUT_EXCEL_SHEET_NOT_EXIST);
				XSSFSheet spreadsheet = workbook.createSheet(appConfig.getOutputSheet());
				createHeaderRow(spreadsheet);

				try {
					out = new FileOutputStream(outputFile);
					workbook.write(out);
					out.close();
				} catch (Exception ex) {
					ex.printStackTrace();
				}

				logger.debug(AppConstants.OUTPUT_EXCEL_SHEET_CREATED_MSG);
			}

		}

		return outputFile;
	}

	private void createHeaderRow(XSSFSheet spreadsheet) {
		// Getting last row number.
		int lastRow = -1;

		Row row = spreadsheet.createRow(++lastRow);
		row.createCell(0).setCellValue("PartyId");
		row.createCell(1).setCellValue("Alternate_PartyId");
		row.createCell(2).setCellValue("Enterprise_Name");
		row.createCell(3).setCellValue("Party_Type");
		row.createCell(4).setCellValue("uriPath");
		row.createCell(5).setCellValue("kycStatus");
		row.createCell(6).setCellValue("kycErrorMessage");

	}


	public void updateExcelDocument(ArrayList<InputParty> processedInputPartys,
			ArrayList<OutPutEnterprisParty> outputEnterprisPartys, AppConfig appConfig) {

		// Update Output Excel Sheet.
		// Verify if file exists or not. If it does not exist then create one.
		File outputFile = checkAndCreateOutputExcelFileIfNotExist(appConfig);

		if (outputEnterprisPartys.size() > 0) {
			logger.info(AppConstants.PROCESSING_OUTPUT_EXCEL_SHEET);

			// Append Data to output excel file.
			for (OutPutEnterprisParty outputParty : outputEnterprisPartys) {
				appendDataToOutputFile(outputParty, outputFile, appConfig);
			}
		}

		// Update Input Excel sheet.
		if (processedInputPartys.size() > 0) {
			logger.info(AppConstants.PROCESSING_INPUT_EXCEL_SHEET);

			// Append Data to input excel file.
			for (InputParty inputPartytDetails : processedInputPartys) {
				appendDataToInputFile(inputPartytDetails, appConfig);
			}
		}
	}

	public File checkAndCreateOutputExcelFileIfNotExist(AppConfig appConfig) {

		File outputFile = new File(appConfig.getDirectoryOutput() + appConfig.getOutputFile());

		FileInputStream fis = null;

		// Workbook object
		XSSFWorkbook workbook = null;

		if (outputFile.exists()) {
			try {
				fis = new FileInputStream(outputFile);
				workbook = new XSSFWorkbook(fis);
			} catch (Exception e1) {
				e1.printStackTrace();
			}
		}

		FileOutputStream out = null;
		if (!outputFile.exists()) {
			try {
				logger.debug(AppConstants.OUTPUT_EXCEL_FILE_NOT_EXIST);
				out = new FileOutputStream(outputFile);

				workbook = new XSSFWorkbook();

				// Spreadsheet object
				XSSFSheet spreadsheet = workbook.createSheet(appConfig.getOutputSheet());
				createHeaderRow(spreadsheet);

				workbook.write(out);
				out.close();

				logger.debug(AppConstants.OUTPUT_EXCEL_FILE_CREATED_MSG);
				logger.debug(AppConstants.OUTPUT_EXCEL_SHEET_CREATED_MSG);
			} catch (Exception e) {
				e.printStackTrace();
			}
		} else {
			logger.debug(AppConstants.OUTPUT_EXCEL_FILE_EXISTS);

			// Check Spreadsheet exists or not in Excel file.
			if (workbook.getNumberOfSheets() != 0) {
				boolean isSpreadSheetExist = false;
				for (int i = 0; i < workbook.getNumberOfSheets(); i++) {
					if (workbook.getSheetName(i).equals(appConfig.getOutputSheet())) {
						isSpreadSheetExist = true;
						break;
					}
				}

				if (isSpreadSheetExist) {
					logger.debug(AppConstants.OUTPUT_EXCEL_SHEET_EXISTS);
				} else {
					// Create new sheet to the workbook
					logger.debug(AppConstants.OUTPUT_EXCEL_SHEET_NOT_EXIST);
					XSSFSheet spreadsheet = workbook.createSheet(appConfig.getOutputSheet());
					createHeaderRow(spreadsheet);

					try {
						out = new FileOutputStream(outputFile);
						workbook.write(out);
						out.close();
					} catch (Exception ex) {
						ex.printStackTrace();
					}

					logger.debug(AppConstants.OUTPUT_EXCEL_SHEET_CREATED_MSG);
				}
			} else {
				// Create new sheet to the workbook if empty
				logger.debug(AppConstants.OUTPUT_EXCEL_SHEET_NOT_EXIST);
				XSSFSheet spreadsheet = workbook.createSheet(appConfig.getOutputSheet());
				createHeaderRow(spreadsheet);

				try {
					out = new FileOutputStream(outputFile);
					workbook.write(out);
					out.close();
				} catch (Exception ex) {
					ex.printStackTrace();
				}

				logger.debug(AppConstants.OUTPUT_EXCEL_SHEET_CREATED_MSG);
			}

		}

		return outputFile;
	}

	public void appendDataToOutputFile(OutPutEnterprisParty outPutEnterprisParty, File outputFile,
			AppConfig appConfig) {
		try {
			FileInputStream fis = new FileInputStream(outputFile);

			// Workbook object
			XSSFWorkbook workbook = new XSSFWorkbook(fis);

			// Spreadsheet object
			XSSFSheet spreadSheet = workbook.getSheet(appConfig.getOutputSheet());

			// Getting last row number.
			int lastRow = spreadSheet.getLastRowNum();

			Row row = spreadSheet.createRow(++lastRow);
			row.createCell(0).setCellValue(outPutEnterprisParty.getPartyId());
			row.createCell(1).setCellValue(outPutEnterprisParty.getAlternatePartyId());
			row.createCell(2).setCellValue(outPutEnterprisParty.getName());
			row.createCell(3).setCellValue(outPutEnterprisParty.getType());
			row.createCell(4).setCellValue(outPutEnterprisParty.getUriPath());
			row.createCell(5).setCellValue(outPutEnterprisParty.getKycStatus());
			row.createCell(6).setCellValue(outPutEnterprisParty.getKycErrorMessage());

			// Closing Input Stream.
			fis.close();

			FileOutputStream fos = new FileOutputStream(outputFile);

			// Write changes
			workbook.write(fos);

			// Closing Output Stream.
			fos.close();

		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}

	public void appendDataToInputFile(InputParty inputPartyDetails, AppConfig appConfig) {
		try {
			File inputFile = new File(appConfig.getDirectoryInput() + appConfig.getInputFile());

			FileInputStream fis = new FileInputStream(inputFile);

			// creating Workbook instance that refers to .xlsx file
			XSSFWorkbook workbook = new XSSFWorkbook(fis);

			// creating a Sheet object to retrieve object
			XSSFSheet sheet = workbook.getSheet(appConfig.getInputSheet());

			Iterator<Row> rowIterator = sheet.iterator();

			// iterating over each row in excel sheet.
			while (rowIterator.hasNext()) {
				Row row = rowIterator.next();
				if (inputPartyDetails.getRownum() == row.getRowNum()) {

					row.createCell(54, CellType.STRING).setCellValue(inputPartyDetails.getStatus());
					row.createCell(55, CellType.STRING).setCellValue(inputPartyDetails.getErrorMessage());
					
					row.createCell(56, CellType.STRING).setCellValue(inputPartyDetails.getOutPutParty());
					row.createCell(57, CellType.STRING).setCellValue(inputPartyDetails.getAlternatePartyId());
					row.createCell(58, CellType.STRING).setCellValue(inputPartyDetails.getName());
					row.createCell(59, CellType.STRING).setCellValue(inputPartyDetails.getType());
					row.createCell(60, CellType.STRING).setCellValue(inputPartyDetails.getUriPath());
					row.createCell(61, CellType.STRING).setCellValue(inputPartyDetails.getKycStatus());

				}
			}
			// Closing Input Stream.
			fis.close();

			FileOutputStream fos = new FileOutputStream(inputFile);

			// Write changes
			workbook.write(fos);

			// Closing Output Stream.
			fos.close();

		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}

}
