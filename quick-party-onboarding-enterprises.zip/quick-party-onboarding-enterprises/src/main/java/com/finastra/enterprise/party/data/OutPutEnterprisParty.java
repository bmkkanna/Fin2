package com.finastra.enterprise.party.data;

import java.util.List;

public class OutPutEnterprisParty {
	private String partyId;
	private String alternatePartyId;
	private String name;
	private String type;
	private String uriPath;
	private String kycStatus;
	private String kycErrorMessage;
	private List<OutputkycAdditionalDetails> kycAdditionalDetails;

	public String getPartyId() {
		return partyId;
	}

	public void setPartyId(String partyId) {
		this.partyId = partyId;
	}

	public String getAlternatePartyId() {
		return alternatePartyId;
	}

	public void setAlternatePartyId(String alternatePartyId) {
		this.alternatePartyId = alternatePartyId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getUriPath() {
		return uriPath;
	}

	public void setUriPath(String uriPath) {
		this.uriPath = uriPath;
	}

	public String getKycStatus() {
		return kycStatus;
	}

	public void setKycStatus(String kycStatus) {
		this.kycStatus = kycStatus;
	}

	public String getKycErrorMessage() {
		return kycErrorMessage;
	}

	public void setKycErrorMessage(String kycErrorMessage) {
		this.kycErrorMessage = kycErrorMessage;
	}

	public List<OutputkycAdditionalDetails> getKycAdditionalDetails() {
		return kycAdditionalDetails;
	}

	public void setKycAdditionalDetails(List<OutputkycAdditionalDetails> kycAdditionalDetails) {
		this.kycAdditionalDetails = kycAdditionalDetails;
	}

}
