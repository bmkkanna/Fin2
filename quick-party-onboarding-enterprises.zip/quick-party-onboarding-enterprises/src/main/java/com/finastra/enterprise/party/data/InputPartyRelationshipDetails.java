package com.finastra.enterprise.party.data;

public class InputPartyRelationshipDetails {
    private String fromDate;
	private String relatedPartyId;
    private String relationshipType;
    private String relationshipPercentage;
    
	public String getFromDate() {
		return fromDate;
	}
	public void setFromDate(String fromDate) {
		this.fromDate = fromDate;
	}
	public String getRelatedPartyId() {
		return relatedPartyId;
	}
	public void setRelatedPartyId(String relatedPartyId) {
		this.relatedPartyId = relatedPartyId;
	}
	public String getRelationshipType() {
		return relationshipType;
	}
	public void setRelationshipType(String relationshipType) {
		this.relationshipType = relationshipType;
	}
	public String getRelationshipPercentage() {
		return relationshipPercentage;
	}
	public void setRelationshipPercentage(String relationshipPercentage) {
		this.relationshipPercentage = relationshipPercentage;
	}
    
    

}
