package com.finastra.enterprise.party.controller;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.finastra.enterprise.party.config.AppConfig;
import com.finastra.enterprise.party.data.InputParty;
import com.finastra.enterprise.party.data.OutPutEnterprisParty;
import com.finastra.enterprise.party.model.ModelProcessor;
import com.finastra.enterprise.party.utility.AppConstants;
import com.finastra.enterprise.party.utility.AppException;
import com.finastra.utility.ReadAndWriteExcelService;

public class AppFrontController {

	private static final Logger logger = LoggerFactory.getLogger(AppFrontController.class);

	private AppConfig appConfig = null;

	private ModelProcessor modelProcessor = null;

	public AppFrontController(AppConfig appConfig) {
		super();
		this.appConfig = appConfig;
		modelProcessor = new ModelProcessor();
	}

	public void setModelProcessor(ModelProcessor modelProcessor) {
		this.modelProcessor = modelProcessor;
	}

	public List<InputParty> readInputFile() {
		File inputFile = modelProcessor.obtainInputFileObject(appConfig);

		List<InputParty> inputPartyList = null;

		if (inputFile.exists()) {
			inputPartyList = modelProcessor.readInputFileAndUpdatePOJO(inputFile, appConfig);
		} else {
			logger.error(AppConstants.INPUT_FILE_DOES_NOT_EXIST_MSG);
		}

		return inputPartyList;
	}

	public void pushQuickPartyEnterprPartyToApi(List<InputParty> inPutDetailsList) throws Exception {
		ArrayList<OutPutEnterprisParty> outputPartys = new ArrayList<OutPutEnterprisParty>();
		ArrayList<InputParty> processedInputParty = new ArrayList<InputParty>();
		List<String> partyIdList = new ArrayList<>();
		for (InputParty inputPartyDetails : inPutDetailsList) {
			if ((inputPartyDetails.getStatus() == null) || (inputPartyDetails.getStatus().trim().equals(""))) {
				String payLoad = modelProcessor.generatePayload(inputPartyDetails);
				HashMap<String, String> responseMap = modelProcessor.makeQuickOnbordingEntPartyAPICall(payLoad, appConfig);
//				partyIdList.respon
 
				if ((responseMap != null) && (responseMap.size() > 0)) {
					if (responseMap.get(AppConstants.HTTP_RESPONSE_STATUS_CODE)
							.equals(AppConstants.PARTY_API_SUCCESS_RESPONSE_STATUS_CODE)) {
						String responseStr = responseMap.get(AppConstants.HTTP_RESPONSE_CONTENT);
 
						ObjectMapper mapper = new ObjectMapper();
						OutPutEnterprisParty outputParty = null;
						try {
							outputParty = mapper.readValue(responseStr, OutPutEnterprisParty.class);
						} catch (Exception e) {
							e.printStackTrace();
						}
 
						outputPartys.add(outputParty);
						partyIdList.add(outputParty.getPartyId());
						
						inputPartyDetails.setStatus(AppConstants.STATUS_SUCCESS);
						inputPartyDetails.setErrorMessage("");
						
						inputPartyDetails.setOutPutParty(outputParty.getPartyId());
						inputPartyDetails.setAlternatePartyId(outputParty.getAlternatePartyId());
						
						inputPartyDetails.setName(outputParty.getName());
						inputPartyDetails.setType(outputParty.getType());
						inputPartyDetails.setUriPath(outputParty.getUriPath());
						inputPartyDetails.setKycStatus(outputParty.getKycStatus());
						
						processedInputParty.add(inputPartyDetails);
 
					} else {
						String statusCode = responseMap.get(AppConstants.HTTP_RESPONSE_STATUS_CODE);
						logger.warn("Http Status Code: " + statusCode);
 
						String responseStr = responseMap.get(AppConstants.HTTP_RESPONSE_CONTENT);
 
						JSONObject jsonRootObject = new JSONObject(responseStr);
 
						String detail = jsonRootObject.getString("detail");
						int status = jsonRootObject.getInt("status");
						String title = jsonRootObject.getString("title");
						String type = jsonRootObject.getString("type");
 
						logger.warn("Error - Details: " + detail);
						logger.warn("Error - Status Code: " + status);
						logger.warn("Error - Title: " + title);
						logger.warn("Error - Type: " + type);
 
						inputPartyDetails.setStatus(AppConstants.STATUS_FAILED);
						inputPartyDetails.setErrorMessage(detail);
						processedInputParty.add(inputPartyDetails);
					}
				} else {
					inputPartyDetails.setStatus(AppConstants.STATUS_FAILED);
					inputPartyDetails.setErrorMessage(AppConstants.API_CALL_FAILED);
					processedInputParty.add(inputPartyDetails);
				}
			}
		}
 
		modelProcessor.updateExcelDocument(processedInputParty, outputPartys, appConfig);
		System.out.println("LIST OF PARTY---Enterprise--->"+partyIdList!=null?partyIdList.size():null);
		System.out.println(appConfig.getDirectoryInput() + appConfig.getInputFile());
		System.out.println("Open Account Record Restricting to excel : "+appConfig.getOpenAccountSheet());
		System.out.println("Open AccountFD Record Restricting to excel : "+appConfig.getOpenAccountFDRecordRestriction());
		if(partyIdList!=null && partyIdList.size()>0) {
		
		if(appConfig.getOpenAccountRecordRestriction().equalsIgnoreCase("true")) {
		System.out.println("Pushing generated Party IDs into Input Sheet:" + appConfig.getOpenAccountSheet());
		ReadAndWriteExcelService.processAndPushToExcelSheetWithRestrictions(
				partyIdList,
				appConfig.getDirectoryInput() + appConfig.getInputFile(),
				appConfig.getOpenAccountSheet());
		}else if(appConfig.getOpenAccountRecordRestriction().equalsIgnoreCase("false")) {
			System.out.println("Pushing generated Party IDs into Input Sheet:" + appConfig.getOpenAccountSheet());
			ReadAndWriteExcelService.processAndPushToExcelSheet(
					partyIdList,
					appConfig.getDirectoryInput() + appConfig.getInputFile(),
					appConfig.getOpenAccountSheet());
		}
		
		if(appConfig.getOpenAccountFDRecordRestriction().equalsIgnoreCase("true")) {
			
		System.out.println("Pushing generated Party IDs into Input Sheet:" + appConfig.getOpenAccountFDSheet());
		ReadAndWriteExcelService.processAndPushToExcelSheetWithRestrictions(
				partyIdList,
				appConfig.getDirectoryInput() + appConfig.getInputFile(),
				appConfig.getOpenAccountFDSheet());
		}else if(appConfig.getOpenAccountFDRecordRestriction().equalsIgnoreCase("false")) {
			System.out.println("Pushing generated Party IDs into Input Sheet:" + appConfig.getOpenAccountFDSheet());
			ReadAndWriteExcelService.processAndPushToExcelSheet(
					partyIdList,
					appConfig.getDirectoryInput() + appConfig.getInputFile(),
					appConfig.getOpenAccountFDSheet());
		}
		
		
		
		}
	}
 

	public boolean obtainAuthToken() throws AppException {

		boolean isTokenObtained = false;

		HashMap<String, String> responseMap = modelProcessor.makeSSORequest(appConfig);

		if ((responseMap != null) && (responseMap.size() > 0)) {
			if (responseMap.get(AppConstants.HTTP_RESPONSE_STATUS_CODE).equals("200")) {
				String responseStr = responseMap.get(AppConstants.HTTP_RESPONSE_CONTENT);

				JSONObject jsonObject = new JSONObject(responseStr);

				appConfig.setAuthToken(jsonObject.getString("result"));

				isTokenObtained = true;
			} else if (responseMap.get(AppConstants.HTTP_RESPONSE_STATUS_CODE).equals("422")) {
				String responseStr = responseMap.get(AppConstants.HTTP_RESPONSE_CONTENT);

				JSONObject jsonRootObject = new JSONObject(responseStr);
				JSONArray jsonEventArray = jsonRootObject.getJSONArray("events");
				JSONObject jsonObject = (JSONObject) jsonEventArray.get(0);

				String eventNumber = jsonObject.getString("eventNumber");
				String message = jsonObject.getString("message");

				logger.warn("EventNumber: " + eventNumber);
				logger.warn(message);

				throw new AppException(AppConstants.SSO_LOGIN_ERROR);
			} else {
				throw new AppException(AppConstants.SSO_LOGIN_ERROR);
			}
		} else {
			throw new AppException(AppConstants.SSO_LOGIN_ERROR);
		}

		return isTokenObtained;
	}

	public boolean isSSOLogoutImplemented() throws AppException {
		boolean isTokenObtained = false;

		HashMap<String, String> responseMap = modelProcessor.makeSSOLogout(appConfig);

		if ((responseMap != null) && (responseMap.size() > 0)) {
			if (responseMap.get(AppConstants.HTTP_RESPONSE_STATUS_CODE).equals("200")) {
				String responseStr = responseMap.get(AppConstants.HTTP_RESPONSE_CONTENT);
				JSONObject jsonObject = new JSONObject(responseStr);
				String result = jsonObject.getString("result");

				logger.info("Logout status: " + result);
				isTokenObtained = true;
			} else {
				throw new AppException(AppConstants.SSO_LOGOUT_ERROR);
			}
		} else {
			throw new AppException(AppConstants.SSO_LOGOUT_ERROR);
		}

		return isTokenObtained;
	}
}
