package com.finastra.enterprise.party.data;

public class OutputkycAdditionalDetails {
	private String fieldName;
	private String fieldDescription;

	public String getFieldName() {
		return fieldName;
	}

	public void setFieldName(String fieldName) {
		this.fieldName = fieldName;
	}

	public String getFieldDescription() {
		return fieldDescription;
	}

	public void setFieldDescription(String fieldDescription) {
		this.fieldDescription = fieldDescription;
	}

}
