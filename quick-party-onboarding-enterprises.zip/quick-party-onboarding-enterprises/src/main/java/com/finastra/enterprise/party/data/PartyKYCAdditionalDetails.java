package com.finastra.enterprise.party.data;

public class PartyKYCAdditionalDetails {
	private String fieldDescription;
	private String fieldName;

	public String getFieldDescription() {
		return fieldDescription;
	}

	public void setFieldDescription(String fieldDescription) {
		this.fieldDescription = fieldDescription;
	}

	public String getFieldName() {
		return fieldName;
	}

	public void setFieldName(String fieldName) {
		this.fieldName = fieldName;
	}

}
