package com.finastra.enterprise.party.data;

import java.util.ArrayList;

public class InputPartyBasicDetails {
	private Boolean activeSWIFTCustomer;
	private String branchCode;
	private String documentCollectionStatus;
	private Boolean isWithHoldingTaxLiable;
	private String localityType;
	private String partyCategory;
	private String partySubType;
	private String partyType;
	private String shortName;
	private String taxExemptionReason;
	private String partyAlternativeId;
	

	private ArrayList<InputPartyAddressDetails> addressDetails;
	private ArrayList<InputPartyLineOfBusinesses> lineOfBusinesses;

	private ArrayList<PartyInputContactDetails> contactDetails;
	private ArrayList<PartyInputDocumentDetails> documentDetails;
	private ArrayList<InputPartyRelationshipDetails> relationshipDetails;
	private String kycExpiryDate;

	public String getBranchCode() {
		return branchCode;
	}

	public void setBranchCode(String branchCode) {
		this.branchCode = branchCode;
	}

	public String getDocumentCollectionStatus() {
		return documentCollectionStatus;
	}

	public void setDocumentCollectionStatus(String documentCollectionStatus) {
		this.documentCollectionStatus = documentCollectionStatus;
	}

	public Boolean getActiveSWIFTCustomer() {
		return activeSWIFTCustomer;
	}

	public void setActiveSWIFTCustomer(Boolean activeSWIFTCustomer) {
		this.activeSWIFTCustomer = activeSWIFTCustomer;
	}

	public Boolean getIsWithHoldingTaxLiable() {
		return isWithHoldingTaxLiable;
	}

	public void setIsWithHoldingTaxLiable(Boolean isWithHoldingTaxLiable) {
		this.isWithHoldingTaxLiable = isWithHoldingTaxLiable;
	}

	public void setWithHoldingTaxLiable(boolean isWithHoldingTaxLiable) {
		this.isWithHoldingTaxLiable = isWithHoldingTaxLiable;
	}

	public String getLocalityType() {
		return localityType;
	}

	public void setLocalityType(String localityType) {
		this.localityType = localityType;
	}

	public String getPartyCategory() {
		return partyCategory;
	}

	public void setPartyCategory(String partyCategory) {
		this.partyCategory = partyCategory;
	}

	public String getPartySubType() {
		return partySubType;
	}

	public void setPartySubType(String partySubType) {
		this.partySubType = partySubType;
	}

	public String getPartyType() {
		return partyType;
	}

	public void setPartyType(String partyType) {
		this.partyType = partyType;
	}

	public String getShortName() {
		return shortName;
	}

	public void setShortName(String shortName) {
		this.shortName = shortName;
	}

	public String getTaxExemptionReason() {
		return taxExemptionReason;
	}

	public void setTaxExemptionReason(String taxExemptionReason) {
		this.taxExemptionReason = taxExemptionReason;
	}

	public ArrayList<InputPartyAddressDetails> getAddressDetails() {
		return addressDetails;
	}

	public void setAddressDetails(ArrayList<InputPartyAddressDetails> addressDetails) {
		this.addressDetails = addressDetails;
	}

	public ArrayList<InputPartyLineOfBusinesses> getLineOfBusinesses() {
		return lineOfBusinesses;
	}

	public void setLineOfBusinesses(ArrayList<InputPartyLineOfBusinesses> lineOfBusinesses) {
		this.lineOfBusinesses = lineOfBusinesses;
	}

	public ArrayList<PartyInputContactDetails> getContactDetails() {
		return contactDetails;
	}

	public void setContactDetails(ArrayList<PartyInputContactDetails> contactDetails) {
		this.contactDetails = contactDetails;
	}

	public ArrayList<PartyInputDocumentDetails> getDocumentDetails() {
		return documentDetails;
	}

	public void setDocumentDetails(ArrayList<PartyInputDocumentDetails> documentDetails) {
		this.documentDetails = documentDetails;
	}

	public ArrayList<InputPartyRelationshipDetails> getRelationshipDetails() {
		return relationshipDetails;
	}

	public void setRelationshipDetails(ArrayList<InputPartyRelationshipDetails> relationshipDetails) {
		this.relationshipDetails = relationshipDetails;
	}

	public String getKycExpiryDate() {
		return kycExpiryDate;
	}

	public void setKycExpiryDate(String kycExpiryDate) {
		this.kycExpiryDate = kycExpiryDate;
	}

	public String getPartyAlternativeId() {
		return partyAlternativeId;
	}

	public void setPartyAlternativeId(String partyAlternativeId) {
		this.partyAlternativeId = partyAlternativeId;
	}

}
