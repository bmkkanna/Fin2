package com.finastra.enterprise.party.data;

import java.util.ArrayList;

public class PartyInputEnterpriseDetails {
	private String countryOfRegistration;
	private String countryTaxDomicile;
	private String enterpriseName;
	private String enterpriseStatus;
	private String stateOfRegistration;
	private String registrationNumber;
	private String dateFormed;
	private String dateIncorporated;
	private String dateCommencedTrading;
	
	public String getRegistrationNumber() {
		return registrationNumber;
	}

	public void setRegistrationNumber(String registrationNumber) {
		this.registrationNumber = registrationNumber;
	}

	private ArrayList<InputPartyMainBusinessActivities> mainBusinessActivities;
	

	public ArrayList<InputPartyMainBusinessActivities> getMainBusinessActivities() {
		return mainBusinessActivities;
	}

	public void setMainBusinessActivities(ArrayList<InputPartyMainBusinessActivities> mainBusinessActivities) {
		this.mainBusinessActivities = mainBusinessActivities;
	}

	public String getCountryOfRegistration() {
		return countryOfRegistration;
	}

	public String getStateOfRegistration() {
		return stateOfRegistration;
	}

	public void setStateOfRegistration(String stateOfRegistration) {
		this.stateOfRegistration = stateOfRegistration;
	}

	public void setCountryOfRegistration(String countryOfRegistration) {
		this.countryOfRegistration = countryOfRegistration;
	}

	public String getCountryTaxDomicile() {
		return countryTaxDomicile;
	}

	public void setCountryTaxDomicile(String countryTaxDomicile) {
		this.countryTaxDomicile = countryTaxDomicile;
	}

	public String getEnterpriseName() {
		return enterpriseName;
	}

	public void setEnterpriseName(String enterpriseName) {
		this.enterpriseName = enterpriseName;
	}

	public String getEnterpriseStatus() {
		return enterpriseStatus;
	}

	public void setEnterpriseStatus(String enterpriseStatus) {
		this.enterpriseStatus = enterpriseStatus;
	}

	public String getDateFormed() {
		return dateFormed;
	}

	public void setDateFormed(String dateFormed) {
		this.dateFormed = dateFormed;
	}

	public String getDateIncorporated() {
		return dateIncorporated;
	}

	public void setDateIncorporated(String dateIncorporated) {
		this.dateIncorporated = dateIncorporated;
	}

	public String getDateCommencedTrading() {
		return dateCommencedTrading;
	}

	public void setDateCommencedTrading(String dateCommencedTrading) {
		this.dateCommencedTrading = dateCommencedTrading;
	}

}
