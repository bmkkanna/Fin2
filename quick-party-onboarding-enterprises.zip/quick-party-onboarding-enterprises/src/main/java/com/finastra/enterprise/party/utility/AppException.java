/**
 * 
 */
package com.finastra.enterprise.party.utility;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 *@author Prabhat
 */
@SuppressWarnings("serial")
public class AppException extends Exception {
	
	private static final Logger logger = LoggerFactory.getLogger(AppException.class);
	
	private String errorMessage = "";
	
	public AppException(String errorMessage) {
		super();
		this.errorMessage = errorMessage;
	}

	public AppException(Throwable th, String errorMessage) {
		super(th);
		logger.error(errorMessage);
		logger.error(th.getMessage());
	}
}
