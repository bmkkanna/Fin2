package com.finastra.enterprise.party.data;

public class InputPartyMainBusinessActivities {
	private String businessFocus;
	private String businessType;
	private String country;
	private String industrySector;
	private Boolean isMainActivity;
	private Boolean isPrimaryActivity;
	private String businessActivity;
	
	public Boolean getIsMainActivity() {
		return isMainActivity;
	}

	public void setIsMainActivity(Boolean isMainActivity) {
		this.isMainActivity = isMainActivity;
	}

	public Boolean getIsPrimaryActivity() {
		return isPrimaryActivity;
	}

	public void setIsPrimaryActivity(Boolean isPrimaryActivity) {
		this.isPrimaryActivity = isPrimaryActivity;
	}

	public String getBusinessActivity() {
		return businessActivity;
	}

	public void setBusinessActivity(String businessActivity) {
		this.businessActivity = businessActivity;
	}

	public String getBusinessFocus() {
		return businessFocus;
	}

	public void setBusinessFocus(String businessFocus) {
		this.businessFocus = businessFocus;
	}

	public String getBusinessType() {
		return businessType;
	}

	public void setBusinessType(String businessType) {
		this.businessType = businessType;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getIndustrySector() {
		return industrySector;
	}

	public void setIndustrySector(String industrySector) {
		this.industrySector = industrySector;
	}

	
	

	

}
