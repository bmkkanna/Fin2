package com.finastra.enterprise.party.data;

public class PartyInputDocumentDetails {
	private String documentCategory;
	private String documentType;
	private String imageId;
	private Boolean isDocumentVerified;
	private String validToDate;

	public Boolean getIsDocumentVerified() {
		return isDocumentVerified;
	}

	public void setIsDocumentVerified(Boolean isDocumentVerified) {
		this.isDocumentVerified = isDocumentVerified;
	}

	public String getDocumentCategory() {
		return documentCategory;
	}

	public void setDocumentCategory(String documentCategory) {
		this.documentCategory = documentCategory;
	}

	public String getDocumentType() {
		return documentType;
	}

	public void setDocumentType(String documentType) {
		this.documentType = documentType;
	}

	public String getImageId() {
		return imageId;
	}

	public void setImageId(String imageId) {
		this.imageId = imageId;
	}

	

	public String getValidToDate() {
		return validToDate;
	}

	public void setValidToDate(String validToDate) {
		this.validToDate = validToDate;
	}

}
