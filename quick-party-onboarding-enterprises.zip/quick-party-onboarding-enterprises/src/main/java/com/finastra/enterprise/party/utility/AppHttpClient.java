package com.finastra.enterprise.party.utility;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.ContentType;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;

/**
 *@author Prabhat
 */
public class AppHttpClient {
	private CloseableHttpClient httpClient;
	private CloseableHttpResponse response;

	public HashMap<String, String> executePostRequest(String url, HashMap<String, String> paramMap, String payLoad) {
		HashMap<String, String> responseMap = null;

		try {
			httpClient = HttpClients.createDefault();

			HttpPost request = new HttpPost(url);

			StringEntity entity = new StringEntity(payLoad, ContentType.APPLICATION_JSON);
			request.setEntity(entity);

			request.setHeader(AppConstants.ACCEPT_PARAM, AppConstants.CONTENT_TYPE_PARAM_VAL);
			request.setHeader(AppConstants.CONTENT_TYPE_PARAM, AppConstants.CONTENT_TYPE_PARAM_VAL);

			if ((paramMap != null) && (paramMap.size() > 0)) {
				for (Map.Entry<String, String> map : paramMap.entrySet()) {
					request.setHeader(map.getKey(), map.getValue());
				}
			}

			response = httpClient.execute(request);

			int statusCode = response.getStatusLine().getStatusCode();
			String content = EntityUtils.toString(response.getEntity());

			responseMap = new HashMap<String, String>();
			responseMap.put(AppConstants.HTTP_RESPONSE_STATUS_CODE, statusCode +"");
			responseMap.put(AppConstants.HTTP_RESPONSE_CONTENT, content);
			
		} catch (IOException ex) {
			ex.printStackTrace();
		}

		return responseMap;
	}
}