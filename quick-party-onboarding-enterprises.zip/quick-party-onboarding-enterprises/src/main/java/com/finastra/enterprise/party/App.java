package com.finastra.enterprise.party;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.finastra.enterprise.party.config.AppConfig;
import com.finastra.enterprise.party.controller.AppFrontController;
import com.finastra.enterprise.party.data.InputParty;
import com.finastra.enterprise.party.utility.AppConstants;
import com.finastra.enterprise.party.utility.AppException;

public class App {
	private static final Logger logger = LoggerFactory.getLogger(App.class);

	public static void main(String[] args) throws AppException {
		logger.info(AppConstants.APP_CONFIGURATION_MSG);
		AppConfig appConfig = new AppConfig();

		try {
			appConfig.setConfigFilePathExternal(args[0]);
			logger.info(AppConstants.EXTERNAL_CONF_FILE_SUPPLIED);
		} catch (Exception ex) {
			logger.info(AppConstants.EXTERNAL_CONF_FILE_NOT_SUPPLIED);
		}

		initialize(appConfig);
		logger.info(AppConstants.APP_CONFIGURATION_SUCCESSFUL_MSG);

		// Creating and Initializing Front Controller.
		AppFrontController controller = new AppFrontController(appConfig);

		// SSO Login and Obtain Auth Token.
		if (controller.obtainAuthToken()) {
			logger.info(AppConstants.SSO_LOGIN_MESSAGE);

			try {
				// Push Party one by one.
				List<InputParty> inputPartyDetailsList = controller.readInputFile();
				logger.info(AppConstants.INPUT_FILE_READ_SUCCESSFULLY_MSG);
				controller.pushQuickPartyEnterprPartyToApi(inputPartyDetailsList);
			} catch (Exception ex) {
				logger.error(AppConstants.PARTY_API_ERROR_MSG);
				logger.error(ex.getStackTrace().toString());
			}

			// Implement SSO Logout.
			if (controller.isSSOLogoutImplemented()) {
				logger.info(AppConstants.SSO_LOGOUT_MESSAGE);
			}
		}
	}

	private static void initialize(AppConfig appConfig) throws AppException {
		
		try {
			appConfig.loadConfiguration();
		} catch (AppException e) {
			logger.error(e.getLocalizedMessage());
			throw e;
		}
	}

}