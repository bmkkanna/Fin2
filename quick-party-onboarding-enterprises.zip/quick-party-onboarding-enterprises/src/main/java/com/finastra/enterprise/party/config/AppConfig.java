package com.finastra.enterprise.party.config;
import java.io.File;
import java.io.FileInputStream;
import java.util.Properties;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.finastra.enterprise.party.utility.AppConstants;
import com.finastra.enterprise.party.utility.AppException;

/**
 * @author Prabhat
 */
public class AppConfig {

	private static final Logger logger = LoggerFactory.getLogger(AppConfig.class);

	private String username;
	private String password;
	private String appBaseUrl;
	private String directoryInput;
	private String inputFile;
	private String inputSheet;
	private String directoryOutput;
	private String outputFile;
	private String outputSheet;
	private String openAccountSheet;
	private String openAccountFDSheet;
	// Essence SSO authToken
	private String authToken;

	// External configuration path
	private String configFilePathExternal;
	private String openAccountRecordRestriction;
	private String openAccountFDRecordRestriction;

	@SuppressWarnings("resource")
	public void loadConfiguration() throws AppException {

		Properties prop = new Properties();

		try {
			if (AppConstants.IS_EXTERNAL_CONFIGURATION) {
				String conFileAbsolutePath = getConfigFilePathExternal();
				File confFfile = new File(conFileAbsolutePath);

				if (confFfile.exists()) {
					logger.info(AppConstants.EXTERNAL_CONF_FILE_EXIST);

					// load a properties file from the given path.
					prop.load(new FileInputStream(confFfile));
				} else {
					logger.error(AppConstants.EXTERNAL_CONF_FILE_NOT_EXIST);
					throw new AppException(AppConstants.APP_CONFIGURATION_FILE_ERROR);
				}
			} else {
				// load a properties file from class path.
				prop.load(AppConfig.class.getClassLoader().getResourceAsStream(AppConstants.APP_CONFIGURATION_FILE));
			}

			// get the property value and set them.
			username = prop.getProperty("app.username");
			password = prop.getProperty("app.password");
			appBaseUrl = prop.getProperty("app.base.url");
			directoryInput = prop.getProperty("input.directory");
			inputFile = prop.getProperty("input.file");
			inputSheet = prop.getProperty("input.party.enterprise.sheet");
			directoryOutput = prop.getProperty("output.directory");
			outputFile = prop.getProperty("output.file");
			outputSheet = prop.getProperty("output.party.enterprise.sheet");
			openAccountSheet = prop.getProperty("input.openAccount.sheet");
			openAccountFDSheet = prop.getProperty("input.openFD.sheet");
			openAccountRecordRestriction = prop.getProperty("output.openAccount.sheet.restriction");
			openAccountFDRecordRestriction = prop.getProperty("output.openFD.sheet.restriction");

		} catch (Exception ex) {
			logger.error(ex.getLocalizedMessage());
			throw new AppException(ex, AppConstants.APP_CONFIGURATION_FILE_ERROR);
		}
	}

	public String getConfigFilePathExternal() {
		return configFilePathExternal;
	}

	public void setConfigFilePathExternal(String configFilePathExternal) {
		this.configFilePathExternal = configFilePathExternal;
	}

	public String getUsername() {
		return username;
	}

	public String getPassword() {
		return password;
	}

	public String getAppBaseUrl() {
		return appBaseUrl;
	}

	public String getDirectoryInput() {
		return directoryInput;
	}

	public String getInputFile() {
		return inputFile;
	}

	public String getInputSheet() {
		return inputSheet;
	}

	public String getDirectoryOutput() {
		return directoryOutput;
	}

	public String getOutputFile() {
		return outputFile;
	}

	public String getOutputSheet() {
		return outputSheet;
	}

	public String getAuthToken() {
		return authToken;
	}

	public void setAuthToken(String authToken) {
		this.authToken = authToken;
	}

	public String getOpenAccountSheet() {
		return openAccountSheet;
	}

	public String getOpenAccountFDSheet() {
		return openAccountFDSheet;
	}

	public String getOpenAccountRecordRestriction() {
		return openAccountRecordRestriction;
	}

	public String getOpenAccountFDRecordRestriction() {
		return openAccountFDRecordRestriction;
	}


	
	
}
