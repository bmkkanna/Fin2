package com.finastra.enterprise.party.data;

public class InputPartyLineOfBusinesses {
	private String lineOfBusiness;

	public String getLineOfBusiness() {
		return lineOfBusiness;
	}

	public void setLineOfBusiness(String lineOfBusiness) {
		this.lineOfBusiness = lineOfBusiness;
	}

}
