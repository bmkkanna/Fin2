package com.finastra.utility;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.ListIterator;
import java.util.Map;
import java.util.Set;
import java.util.function.Function;
import java.util.stream.Collectors;

import org.apache.poi.openxml4j.opc.OPCPackage;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ReadAndWriteExcelService {
	private static final Logger logger = LoggerFactory.getLogger(ReadAndWriteExcelService.class);

	public static void main(String args[]) {
		logger.info(AppConstants.APP_CONFIGURATION_MSG);
		AppConfig appConfig = new AppConfig();
		List<Map<String, Object>> listOfCustomerCombineIds = null;
		List<Map<String, Object>> listOfCustomerCombineCollateral = null;
		String fromSheetName = "";

		try {
			appConfig.setConfigFilePathExternal(args[0]);
			logger.info(AppConstants.EXTERNAL_CONF_FILE_SUPPLIED);

			initialize(appConfig);
			logger.info(AppConstants.APP_CONFIGURATION_SUCCESSFUL_MSG);

			// Option 1,3,4
			Map<String, String> map = new HashMap<String, String>();
			map.put("1", appConfig.getPersonalSheet());
			map.put("2", appConfig.getEnterpriseSheet());
			map.put("3", appConfig.getOpenAccountSheet());
			map.put("4", appConfig.getOpenAccountFDSheet());
			map.put("5", appConfig.getCommitmentSheet());
			map.put("6", appConfig.getCollateralSheet());
			map.put("7", appConfig.getLendingSheet());

			String filePath = appConfig.getDirectoryInput() + appConfig.getInputFile();

			String option = args[1];
			String outputSheet = map.get(args[2]);
			String[] inputSheets = option.split("\\,");

			String inputSheet = null;
			String inputSheet1 = null;
			inputSheet = map.get(inputSheets[0]);
			if (inputSheets.length > 1) {
				inputSheet1 = map.get(inputSheets[1]);
			}
			logger.info("Input sheet1 :" + inputSheet);
			logger.info("Input sheet2 :" + inputSheet1);
			logger.info("Output Sheet : " + outputSheet);
			if (inputSheets.length > 1) {
				// 5,6 7
				listOfCustomerCombineIds = listOfCustomerCombination(inputSheet, appConfig);
				listOfCustomerCombineCollateral = listOfCustomerCombination(inputSheet1, appConfig);
				manipulateList(listOfCustomerCombineCollateral,listOfCustomerCombineIds);

				logger.info("Collected List of Customer id combinations.");
				logger.info(listOfCustomerCombineCollateral.toString());

				fromSheetName = inputSheet;

				processAndPushToExcelSheetForParty(listOfCustomerCombineCollateral, filePath, outputSheet/* "OpenAccount" */,
						fromSheetName, inputSheets.length > 1, appConfig);
			} else {
				listOfCustomerCombineIds = listOfCustomerCombination(inputSheet/* "QuickPartyOnboarding-Personal" */,
						appConfig);
			logger.info("Collected List of Customer id combinations.");
			logger.info(listOfCustomerCombineIds.toString());

			fromSheetName = inputSheet;
			processAndPushToExcelSheetForParty(listOfCustomerCombineIds, filePath, outputSheet/* "OpenAccount" */,
					fromSheetName, inputSheets.length > 1, appConfig);
			}
			logger.info("Excel Service done successfully...");
		} catch (Exception ex) {
			ex.printStackTrace();
			System.exit(1);
			logger.info(ex.getMessage());
		} finally {
			if (listOfCustomerCombineIds != null)
				listOfCustomerCombineIds.clear();
			if (listOfCustomerCombineCollateral != null) {
				listOfCustomerCombineCollateral.clear();
			}

		}
	}

	private static void manipulateList(List<Map<String, Object>> collateralIdsCombination,
			List<Map<String, Object>> commitmentIdsCombination) {
		// TODO Auto-generated method stub
		Iterator<Map<String, Object>> iterator1 = collateralIdsCombination.iterator();
		Iterator<Map<String, Object>> iterator2 = commitmentIdsCombination.iterator();

		while (iterator1.hasNext() && iterator2.hasNext()) {
			Map<String, Object> currentMap1 = iterator1.next();
			Map<String, Object> currentMap2 = iterator2.next();
			currentMap1.put("ChargeFundingAccount", currentMap2.get("ChargeFundingAccount"));
			currentMap1.put("Commitment Id", currentMap2.get("Commitment Id"));
			currentMap1.put("CommitmentAmount_Currency", currentMap2.get("CommitmentAmount_Currency"));
			
			
//			currentMap1.put("CollateralID", currentMap2.get("CollateralID"));
//			currentMap1.put("Face_Value_Currency", currentMap2.get("Face_Value_Currency"));
//			currentMap1.put("Charge_Funding_Account", currentMap2.get("Charge_Funding_Account"));
			System.out.println("Map from Map1: " + currentMap1);
			System.out.println("Map from Map2: " + currentMap2);
		}
	}

	private static void initialize(AppConfig appConfig) throws AppException {
		try {
			appConfig.loadConfiguration();
		} catch (AppException e) {
			logger.error(e.getLocalizedMessage());
			throw e;
		}
	}

	public static void processAndPushToExcelSheetWithRestrictions(List<String> listOfCustomerId, String filePath,
			String sheetName) throws IOException {
		List<Map<String, Object>> modifiedExcelDataList = null;
		List<Map<String, Object>> existingRecord = readExcel(filePath, sheetName);
		int size = 0;
		if (listOfCustomerId.size() < existingRecord.size()) {
			size = listOfCustomerId.size();
		} else
			size = existingRecord.size();

		modifiedExcelDataList = amendCustomerIdWithRestrictions(listOfCustomerId, existingRecord, size);
		pushToExcelSheet(modifiedExcelDataList, filePath, sheetName);

	}

	public static List<Map<String, Object>> readCustomerIdCombineList(String sheetName) throws IOException {
		List<Map<String, Object>> dataList = ReadAndWriteExcelService.readExcel(
				"C:\\Essence\\Misys\\Input\\Party_Account_FD V0.1.1.2.xlsx", "QuickPartyOnboarding-Enterprise",
				"SUCCESS");
		return dataList;
	}

	public static List<Map<String, Object>> listOfCustomerCombination(String inputSheetName, AppConfig appConfig)
			throws Exception {

		logger.info("Collecting List of Customer id combinations.");
		List<Map<String, Object>> deduplicatedList = null;
		List<Map<String, Object>> dataList = null;
		List<Map<String, Object>> listOfCustomerIdCombination = null;
		dataList = ReadAndWriteExcelService.readExcel(appConfig.getDirectoryInput() + appConfig.getInputFile(),
				inputSheetName, AppConstants.STATUS_SUCCESS);
		if (dataList != null && dataList.size() > 0) {
			if (inputSheetName.equalsIgnoreCase(appConfig.getEnterpriseSheet())
					|| inputSheetName.equalsIgnoreCase(appConfig.getPersonalSheet())) {
				listOfCustomerIdCombination = dataList.stream()
						.map(inputMap -> inputMap.entrySet().stream().filter(
								entry -> entry.getKey().equals("Party_Id") || entry.getKey().equals("Related_Party_Id"))
								.collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue)))
						.collect(Collectors.toList());
			} else if (inputSheetName.equalsIgnoreCase(appConfig.getOpenAccountSheet())) {
				listOfCustomerIdCombination = dataList.stream()
						.map(inputMap -> inputMap.entrySet().stream().filter(
								entry -> entry.getKey().equals("CustomerId") || entry.getKey().equals("AccountId"))
								.collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue)))
						.collect(Collectors.toList());
			} else if (inputSheetName.equalsIgnoreCase(appConfig.getCollateralSheet())) {
				listOfCustomerIdCombination = dataList.stream()
						.map(inputMap -> inputMap.entrySet().stream()
								.filter(entry -> entry.getKey().equals("Customer ID")
										|| entry.getKey().equals("Charge_Funding_Account")
										|| entry.getKey().equals("CollateralID")
										|| entry.getKey().equals("Face_Value_Currency"))
								.collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue)))
						.collect(Collectors.toList());
			} else if (inputSheetName.equalsIgnoreCase(appConfig.getCommitmentSheet())) {
				listOfCustomerIdCombination = dataList.stream()
						.map(inputMap -> inputMap.entrySet().stream()
								.filter(entry -> entry.getKey().equals("Customer ID")
										|| entry.getKey().equals("ChargeFundingAccount")
										|| entry.getKey().equals("Commitment Id")
										|| entry.getKey().equals("CommitmentAmount_Currency"))
								.collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue)))
						.collect(Collectors.toList());
			}
			Set<Map<String, Object>> uniqueMaps = new LinkedHashSet<>(listOfCustomerIdCombination);
			// Convert back to a list if needed
			deduplicatedList = new ArrayList<>(uniqueMaps);
		} else {
			throw new Exception("There is no party id generated...in " + inputSheetName);
		}

		return deduplicatedList;
	}

	/*
	 * public static void processAndPushToAccountExcesheet(String sheetName) throws
	 * IOException { List<Map<String, Object>> dataList = null;
	 * if(sheetName.equalsIgnoreCase("QuickPartyOnboarding-Enterprise")) { dataList
	 * = ReadAndWriteExcelService.readExcel(
	 * "C:\\Essence\\Misys\\Input\\Party_Account_FD V0.1.1.2.xlsx",
	 * "QuickPartyOnboarding-Enterprise","SUCCESS");
	 * 
	 * 
	 * }else if(sheetName.equalsIgnoreCase("QuickPartyOnboarding-Personal")) {
	 * dataList = ReadAndWriteExcelService.readExcel(
	 * "C:\\Essence\\Misys\\Input\\Party_Account_FD V0.1.1.2.xlsx",
	 * "QuickPartyOnboarding-Personal","SUCCESS");
	 * 
	 * 
	 * }else if(sheetName.equalsIgnoreCase("OpenAccount")) { dataList =
	 * ReadAndWriteExcelService.readExcel(
	 * "C:\\Essence\\Misys\\Input\\Party_Account_FD V0.1.1.2.xlsx",
	 * "OpenAccount","SUCCESS");
	 * 
	 * 
	 * }
	 * 
	 * if(dataList!=null && dataList.size()>0) { List<Map<String, Object>>
	 * listOfCustomersJointCustomer=null;
	 * if(sheetName.equalsIgnoreCase("QuickPartyOnboarding-Enterprise") ||
	 * sheetName.equalsIgnoreCase("QuickPartyOnboarding-Personal")) {
	 * listOfCustomersJointCustomer = dataList.stream() .map(inputMap ->
	 * inputMap.entrySet().stream().filter(entry ->
	 * entry.getKey().equals("Party_Id") ||
	 * entry.getKey().equals("Related_Party_Id"))
	 * .collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue)))
	 * .collect(Collectors.toList()); Set<Map<String, Object>> uniqueMaps = new
	 * LinkedHashSet<>(listOfCustomersJointCustomer); // Convert back to a list if
	 * needed List<Map<String, Object>> deduplicatedList = new
	 * ArrayList<>(uniqueMaps); processAndPushToExcelSheetForParty(deduplicatedList,
	 * "C:\\Essence\\Misys\\Input\\Party_Account_FD V0.1.1.2.xlsx", "OpenAccount");
	 * }else if(sheetName.equalsIgnoreCase("OpenAccount")) {
	 * listOfCustomersJointCustomer = dataList.stream() .map(inputMap ->
	 * inputMap.entrySet().stream().filter(entry ->
	 * entry.getKey().equals("CustomerId") || entry.getKey().equals("AccountId"))
	 * .collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue)))
	 * .collect(Collectors.toList()); Set<Map<String, Object>> uniqueMaps = new
	 * LinkedHashSet<>(listOfCustomersJointCustomer); // Convert back to a list if
	 * needed List<Map<String, Object>> deduplicatedList = new
	 * ArrayList<>(uniqueMaps); processAndPushToExcelSheetForParty(deduplicatedList,
	 * "C:\\Essence\\Misys\\Input\\Party_Account_FD V0.1.1.2.xlsx",
	 * "CreateCommitments");
	 * 
	 * }
	 * 
	 * }else { System.out.println("There is no party id generated..."); } }
	 */
	public static void processAndPushToExcelSheetForParty(List<Map<String, Object>> listOfCustomerOrJointCustomer,
			String filePath, String sheetName, String fromSheetName, boolean isCommitmentAndCollateral,
			AppConfig appConfig) throws Exception {
		logger.info("Processing for Appended List into sheet :" + sheetName);
		List<Map<String, Object>> modifiedExcelDataList = null;
		List<Map<String, Object>> remainingData = new ArrayList<Map<String, Object>>();
		List<Map<String, Object>> oldRecordList = null;
		List<Map<String, Object>> actualCustStatusExcelDataList = null;
		Set<Map<String, Object>> uniqueMaps = null;
		List<Map<String, Object>> deduplicatedList = null;
		try {
//		if(sheetName.equalsIgnoreCase(appConfig.getOpenAccountSheet()) || sheetName.equalsIgnoreCase(appConfig.getOpenAccountFDSheet()) || 
//				sheetName.equalsIgnoreCase(appConfig.getCollateralSheet())) {
//			Maintaining old or processed record
			/*
			 * oldRecordList = readExcel(filePath, sheetName);
			 * oldRecordList.retainAll(oldRecordList.subList(0, 1)); for
			 * (Iterator<Map<String, Object>> iterator = oldRecordList.iterator();
			 * iterator.hasNext();) { Map<String, Object> map = iterator.next();
			 * if(map.get("Customer ID")!=null &&
			 * map.get("Customer ID").toString().isEmpty()) {//referring for OpenAccount or
			 * OpenFD sheet iterator.remove(); } }
			 */
//			} 
			/*
			 * else if (sheetName.equalsIgnoreCase(appConfig.getCommitmentSheet())) {
			 * oldRecordList = readExcel(filePath, sheetName); for (Iterator<Map<String,
			 * Object>> iterator = oldRecordList.iterator(); iterator.hasNext();) {
			 * Map<String, Object> map = iterator.next(); if(map.containsKey("CustomerId")
			 * && map.get("CustomerId")!=null && map.get("CustomerId").toString().isEmpty())
			 * {//referring for CreateCommitment sheet iterator.remove(); } } }
			 */

			System.out.println(oldRecordList);
			actualCustStatusExcelDataList = readExcel(filePath, sheetName);
			for (Iterator<Map<String, Object>> iterator = actualCustStatusExcelDataList.iterator(); iterator
					.hasNext();) {
				Map<String, Object> map = iterator.next();
				if (map.get("Status") != null
						&& map.get("Status").toString().equalsIgnoreCase(AppConstants.STATUS_FAILED)) {
					iterator.remove();
				} else if (map.get("Status") != null
						&& map.get("Status").toString().equalsIgnoreCase(AppConstants.STATUS_SUCCESS)) {
					map.put("Status", "");
					emptyAllMap(map, sheetName, appConfig);

				}
			}
			logger.info("Final List for customer IDs amendment:" + actualCustStatusExcelDataList.size());

			if (actualCustStatusExcelDataList.size() > 0) {

				uniqueMaps = new LinkedHashSet<>(actualCustStatusExcelDataList);
				// Convert back to a list if needed
				deduplicatedList = new ArrayList<>(uniqueMaps);

				modifiedExcelDataList = amendCustomerRelatedCustIds(listOfCustomerOrJointCustomer, deduplicatedList,
						sheetName, fromSheetName, isCommitmentAndCollateral, appConfig);
//		Maintaining old or processed record
//		remainingData.addAll(oldRecordList);
				remainingData.addAll(modifiedExcelDataList);
				logger.info("Final collected List into sheet :" + sheetName);
				logger.info(remainingData.toString());
				pushToExcelSheet(remainingData, filePath, sheetName);
			} else {
				System.out.println("There is no Active records to transfer");
			}
		} catch (Exception e) {
			throw e;
		} finally {
			if (remainingData != null)
				remainingData.clear();

			if (actualCustStatusExcelDataList != null)
				actualCustStatusExcelDataList.clear();

			if (modifiedExcelDataList != null)
				modifiedExcelDataList.clear();
		}
		if (uniqueMaps != null)
			uniqueMaps.clear();
		if (deduplicatedList != null)
			deduplicatedList.clear();

	}

	private static void emptyAllMap(Map<String, Object> map, String sheetName, AppConfig appConfig) {
		// Commitment output.
		if (sheetName.equalsIgnoreCase(appConfig.getCommitmentSheet())) {
			map.put("Commitment Id", "");
			map.put("Customer Id", "");
			map.put("Title Output", "");
			map.put("Commitment Amount Value", "");
			map.put("Commitment Amount Currency", "");
			map.put("Revolving Commitment", "");
			map.put("Agreement Date", "");
			map.put("First Drawdown Date", "");
			map.put("Expiry Date", "");
			map.put("Final Repayment Date", "");
			map.put("Branch Sort Code", "");
			map.put("Fee Rate", "");
			map.put("Additional Details", "");
			map.put("Charge Funding Account", "");
			map.put("Commitment Charge Amount Value", "");
			map.put("Commitment Charge Amount currency", "");
			map.put("Exchange Rate Type", "");
			map.put("Limit Reference", "");
		} else if (sheetName.equalsIgnoreCase(appConfig.getLendingSheet())) {
			// Loan output
			map.put("Loan_Id", "");
			map.put("Customer_Id", "");
			map.put("customer_Name", "");
			map.put("Customer_Type", "");
			map.put("Branch", "");
			map.put("Product_Name", "");
			map.put("Loan_Purpose", "");
			map.put("Loan_Amount", "");
			map.put("Currency", "");
			map.put("Loan_Start_Date", "");
			map.put("Maturity_Date", "");
			map.put("Repayment_Type", "");
			map.put("Effective_Interest_Rate", "");
			map.put("Repayment_Start_Date", "");
		} else if (sheetName.equalsIgnoreCase(appConfig.getCollateralSheet())) {
			// Collateral Output
			map.put("CustomerID", "");
			map.put("CollateralType", "");
			map.put("CollateralID", "");
			map.put("CoverValue", "");
			map.put("CoverCurrency", "");
		} else if (sheetName.equalsIgnoreCase(appConfig.getPersonalSheet())) {
			// Party Personal Output
			map.put("Party_Id", "");
			map.put("Alternate Party ID", "");
			map.put("Name", "");
			map.put("URI Path", "");
			map.put("KYC Status", "");
			map.put("KYC Error Message", "");
			map.put("Field Name", "");
			map.put("Field Description", "");
		} else if (sheetName.equalsIgnoreCase(appConfig.getEnterpriseSheet())) {
			// Party Enterprise Output
			map.put("Party_Id", "");
			map.put("Alternate_PartyId", "");
			map.put("Enterprise_Name", "");
			map.put("Party_Type", "");
			map.put("uriPath", "");
			map.put("kycStatus", "");
			map.put("kycErrorMessage", "");
		} else if (sheetName.equalsIgnoreCase(appConfig.getOpenAccountSheet())) {
			// Open Account Output
			map.put("CustomerId", "");
			map.put("AccountId", "");
			map.put("CustomerName", "");
			map.put("ProductDescription", "");
			map.put("AccountName", "");
			map.put("ModeOfOperation", "");
			map.put("PostingRestriction", "");
			map.put("Comments", "");
			map.put("JointCustomerId", "");
			map.put("JointCustomerName", "");
			map.put("MandateId", "");
			map.put("MandateHolderName", "");
			map.put("MandateType", "");
		} else if (sheetName.equalsIgnoreCase(appConfig.getOpenAccountFDSheet())) {
			// Open Account FD Output
			map.put("Customer_ID", "");
			map.put("Account Id", "");
			map.put("Customer Name", "");
			map.put("Product Id", "");
			map.put("Product Description", "");
			map.put("Fixed_Deposit_Amount", "");
			map.put("Currency_Type", "");
			map.put("Interest_Payout_Account", "");
			map.put("interestRate", "");
			map.put("Contra Account No", "");
			map.put("Capitalisation_Method", "");
			map.put("Create Datetime", "");
			map.put("Interest Amount", "");
			map.put("Maturity Amount", "");
			map.put("Maturity Date", "");
		}

	}

	public static void processAndPushToExcelSheet(List<String> listOfCustomerId, String filePath, String sheetName)
			throws IOException {
		List<Map<String, Object>> modifiedExcelDataList = null;
		List<Map<String, Object>> remainingData = new ArrayList<Map<String, Object>>();
		List<Map<String, Object>> oldRecordList = readExcel(filePath, sheetName);

		for (Iterator<Map<String, Object>> iterator = oldRecordList.iterator(); iterator.hasNext();) {
			Map<String, Object> map = iterator.next();
			if (map.get("Customer ID") != null && map.get("Customer ID").toString().isEmpty()) {
				iterator.remove();
			}
		}

		System.out.println(oldRecordList);
		List<Map<String, Object>> actualCustStatusExcelDataList = readExcel(filePath, sheetName);
		for (Iterator<Map<String, Object>> iterator = actualCustStatusExcelDataList.iterator(); iterator.hasNext();) {
			Map<String, Object> map = iterator.next();
			if (map.get("Status") != null && map.get("Status").toString().equalsIgnoreCase("FAILED")) {
				iterator.remove();
			} else if (map.get("Status") != null && map.get("Status").toString().equalsIgnoreCase("SUCCESS")) {
				map.put("Status", "");
			}
		}

		System.out.println("Record from " + sheetName + " is " + actualCustStatusExcelDataList.size());

		if (actualCustStatusExcelDataList.size() > 0) {
			modifiedExcelDataList = amendCustomerIdWithOutRestriction(listOfCustomerId, actualCustStatusExcelDataList,
					listOfCustomerId.size());
			remainingData.addAll(oldRecordList);
			remainingData.addAll(modifiedExcelDataList);
			pushToExcelSheet(remainingData, filePath, sheetName);
		} else {
			System.out.println("There is no Active records to transfer");
		}
		if (remainingData != null)
			remainingData.clear();

		if (actualCustStatusExcelDataList != null)
			actualCustStatusExcelDataList.clear();

		if (modifiedExcelDataList != null)
			modifiedExcelDataList.clear();

	}

	public static List<Map<String, Object>> readExcel(String filePath, String sheetName, String successRecord)
			throws IOException {
		List<Map<String, Object>> dataList = new ArrayList<Map<String, Object>>();
		OPCPackage pkg = null;
		Workbook wb = null;
		try {
			pkg = OPCPackage.open(filePath);
			wb = new XSSFWorkbook(pkg);
			Sheet sheet = wb.getSheet(sheetName);
			System.out.println(sheet);
			Row headerRow = sheet.getRow(0);

			int columnCount = headerRow.getPhysicalNumberOfCells();
			for (int i = 1; i <= sheet.getLastRowNum(); i++) {
				Row row = sheet.getRow(i);
				if (row == null)
					break;
				boolean proceedToAdd = true;
				Map<String, Object> dataMap = new LinkedHashMap<>();
				for (int j = 0; j < columnCount; j++) {
					Cell cell = row.getCell(j);
					// System.out.println("Cell---->"+cell);
					// System.out.println("headerRow.getCell(j)"+headerRow.getCell(j));
					String header = headerRow.getCell(j).getStringCellValue();
					String value = (cell != null) ? cell.toString() : "";
					dataMap.put(header, value);
				}
				if (dataMap.get("Status") != null && dataMap.get("Status").toString().equalsIgnoreCase(successRecord))
					dataList.add(dataMap);

			}
			System.out.println(dataList.size());
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		} finally {
			if (wb != null)
				wb.close();
//			if(pkg!=null)
//			pkg.close();
		}
		return dataList;
	}

	public static List<Map<String, Object>> readExcel(String filePath, String sheetName) throws IOException {
		List<Map<String, Object>> dataList = new ArrayList<Map<String, Object>>();
		OPCPackage pkg = null;
		Workbook wb = null;
		try {
			pkg = OPCPackage.open(filePath);
			wb = new XSSFWorkbook(pkg);
			Sheet sheet = wb.getSheet(sheetName);
			System.out.println(sheet);
			Row headerRow = sheet.getRow(0);

			int columnCount = headerRow.getPhysicalNumberOfCells();
			for (int i = 1; i <= sheet.getLastRowNum(); i++) {
				Row row = sheet.getRow(i);
				if (row == null)
					break;
				boolean proceedToAdd = true;
				Map<String, Object> dataMap = new LinkedHashMap<>();
				for (int j = 0; j < columnCount; j++) {
					Cell cell = row.getCell(j);
					// System.out.println("Cell---->"+cell);
					// System.out.println("headerRow.getCell(j)"+headerRow.getCell(j));
					String header = headerRow.getCell(j).getStringCellValue();
					String value = (cell != null) ? cell.toString() : "";
					dataMap.put(header, value);
				}
				dataList.add(dataMap);

			}
			System.out.println(dataList.size());
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		} finally {
			if (wb != null)
				wb.close();
//			if(pkg!=null)
//			pkg.close();
		}
		return dataList;
	}

	public static <T> void removeDuplicatesFromList(List<T> list, Function<T, ?>... keyFunctions) {

		Set<List<?>> set = new HashSet<>();

		ListIterator<T> iter = list.listIterator();
		while (iter.hasNext()) {
			T element = iter.next();

			List<?> functionResults = Arrays.stream(keyFunctions).map(function -> function.apply(element))
					.collect(Collectors.toList());

			if (!set.add(functionResults)) {
				iter.remove();
			}
		}
	}

	public static Set<Map<String, Object>> readExcelSet(String filePath, String sheetName) throws IOException {
		Set<Map<String, Object>> dataList = new HashSet<Map<String, Object>>();
		OPCPackage pkg = null;
		Workbook wb = null;
		try {
			pkg = OPCPackage.open(filePath);
			wb = new XSSFWorkbook(pkg);
			Sheet sheet = wb.getSheet(sheetName);
			System.out.println(sheet);
			Row headerRow = sheet.getRow(0);

			int columnCount = headerRow.getPhysicalNumberOfCells();
			Map<String, Object> dataMap = new LinkedHashMap<>();
			for (int i = 1; i <= sheet.getLastRowNum(); i++) {
				Row row = sheet.getRow(i);
				if (row == null)
					break;
				boolean proceedToAdd = true;
				for (int j = 0; j < columnCount; j++) {
					Cell cell = row.getCell(j);
					// System.out.println("Cell---->"+cell);
					// System.out.println("headerRow.getCell(j)"+headerRow.getCell(j));
					String header = headerRow.getCell(j).getStringCellValue();
					String value = (cell != null) ? cell.toString() : "";
					dataMap.put(header, value);
				}
				dataList.add(dataMap);

			}
			System.out.println(dataList.size());
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		} finally {
			if (wb != null)
				wb.close();
//			if(pkg!=null)
//			pkg.close();
		}
		return dataList;
	}

	public static List<Map<String, Object>> amendCustomerIdWithRestrictions(List<String> listOfCustomerId,
			List<Map<String, Object>> actualExcelDataList, int size) throws IOException {
		List<Map<String, Object>> modifiableExcelDataList = new ArrayList<Map<String, Object>>();
//		List<Map<String, Object>> tempList = null;
//		for (int i = 0; i <size; i++) {
//			int j=0;
//			tempList = new ArrayList<>();
		try {
			Map<String, Object> tempMap = null;
//			for (Map<String, Object> map : actualExcelDataList) {
			for (int j = 0; j < size; j++) {
				Map<String, Object> map = actualExcelDataList.get(j);
				System.out.println("Map " + (j + 1) + ": " + map);
				map.put("Customer ID", listOfCustomerId.get(j));
				tempMap = new LinkedHashMap<>(map);
				modifiableExcelDataList.add(tempMap);
//				
//				modifiableExcelDataList.addAll(tempList);
			}
//		}
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		System.out.println(modifiableExcelDataList.size());
		return modifiableExcelDataList;
	}

	public static List<Map<String, Object>> amendCustomerIdWithOutRestriction(List<String> listOfCustomerId,
			List<Map<String, Object>> actualExcelDataList, int size) throws IOException {
		List<Map<String, Object>> modifiableExcelDataList = new ArrayList<Map<String, Object>>();
		Set<Map<String, Object>> modifiableExcelDataSet = new LinkedHashSet<Map<String, Object>>();
		List<Map<String, Object>> tempList = null;

		for (int i = 0; i < listOfCustomerId.size(); i++) {
			tempList = new ArrayList<>();
			Map<String, Object> tempMap = null;
			for (Map<String, Object> map : actualExcelDataList) {
				map.put("Customer ID", listOfCustomerId.get(i));
				tempMap = new LinkedHashMap<>(map);
				tempList.add(tempMap);
			}
			modifiableExcelDataSet.addAll(tempList);
		}
		modifiableExcelDataList.addAll(modifiableExcelDataSet);
		System.out.println(modifiableExcelDataList.size());
		return modifiableExcelDataList;
	}

	public static List<Map<String, Object>> amendCustomerAccountIds(List<Map<String, Object>> listOfCustomerAccountIds,
			List<Map<String, Object>> actualExcelDataList, int size) throws IOException {
		List<Map<String, Object>> modifiableExcelDataList = new ArrayList<Map<String, Object>>();
		Set<Map<String, Object>> modifiableExcelDataSet = new LinkedHashSet<Map<String, Object>>();
		List<Map<String, Object>> tempList = null;

		for (int i = 0; i < listOfCustomerAccountIds.size(); i++) {
			tempList = new ArrayList<>();
			Map<String, Object> tempMap = null;
			for (Map<String, Object> map : actualExcelDataList) {
				map.put("Customer ID", listOfCustomerAccountIds.get(i).get("Customer Id"));
				map.put("Account ID", listOfCustomerAccountIds.get(i).get("Account Id"));
				tempMap = new LinkedHashMap<>(map);
				tempList.add(tempMap);
			}
			modifiableExcelDataSet.addAll(tempList);
		}
		modifiableExcelDataList.addAll(modifiableExcelDataSet);
		System.out.println(modifiableExcelDataList.size());
		return modifiableExcelDataList;
	}

	public static List<Map<String, Object>> amendCustomerRelatedCustIds(
			List<Map<String, Object>> listOfCustomerRelatedCustIds, List<Map<String, Object>> actualExcelDataList,
			String sheetName, String fromSheetName, boolean isCommitmentAndCollateral, AppConfig appConfig)
			throws IOException {
		logger.info("Amending collected List into sheet :" + sheetName);
		List<Map<String, Object>> modifiableExcelDataList = new ArrayList<Map<String, Object>>();
		Set<Map<String, Object>> modifiableExcelDataSet = new LinkedHashSet<Map<String, Object>>();
		List<Map<String, Object>> tempList = null;

		for (int i = 0; i < listOfCustomerRelatedCustIds.size(); i++) {
			tempList = new ArrayList<>();
			Map<String, Object> tempMap = null;
//			int j=0;
			for (Map<String, Object> map : actualExcelDataList) {

				if (sheetName.equalsIgnoreCase(appConfig.getOpenAccountSheet())) {
					map.put("Customer ID", listOfCustomerRelatedCustIds.get(i).get("Party_Id"));
					if (listOfCustomerRelatedCustIds.get(i).get("Related_Party_Id") != null
							&& !listOfCustomerRelatedCustIds.get(i).get("Related_Party_Id").toString().isEmpty()) {
						map.put("Mode of Operation", "JOINT");
						map.put("Account Ownership", "JOINT");
						map.put("Joint Account Checkbox", AppConstants.YES_STRING_MSG);
						map.put("Joint_Acc-->CustomerIds", listOfCustomerRelatedCustIds.get(i).get("Related_Party_Id"));
//					String[] numberOfCustromers = listOfCustomerRelatedCustIds.get(i).get("Related_Party_Id").toString().split("\\,");

						map.put("IsMandateAvailable", AppConstants.NO_STRING_MSG);
						map.put("Mandate Holder Id", "");
						map.put("Mandate Type", "");
					} else {
						map.put("Mode of Operation", "SOLE");
						map.put("Account Ownership", "SOLE");
						map.put("Joint Account Checkbox", AppConstants.NO_STRING_MSG);
						map.put("Joint_Acc-->CustomerIds", "");

						map.put("IsMandateAvailable", AppConstants.NO_STRING_MSG);
						map.put("Mandate Holder Id", "");
						map.put("Mandate Type", "");
					}
				} else if (sheetName.equalsIgnoreCase(appConfig.getOpenAccountFDSheet())) {
					map.put("Customer ID", listOfCustomerRelatedCustIds.get(i).get("Party_Id"));
					if (listOfCustomerRelatedCustIds.get(i).get("Related_Party_Id") != null
							&& !listOfCustomerRelatedCustIds.get(i).get("Related_Party_Id").toString().isEmpty()) {
						map.put("Joint Account", AppConstants.YES_STRING_MSG);
						map.put("JointCustomerDetails", listOfCustomerRelatedCustIds.get(i).get("Related_Party_Id"));
					} else {
						map.put("Joint Account", AppConstants.NO_STRING_MSG);
						map.put("JointCustomerDetails", "");
					}
				} else if (sheetName.equalsIgnoreCase(appConfig.getCommitmentSheet())) {
					map.put("Customer ID", listOfCustomerRelatedCustIds.get(i).get("CustomerId"));
					map.put("LimitReference", listOfCustomerRelatedCustIds.get(i).get("CustomerId"));
					map.put("ChargeFundingAccount", listOfCustomerRelatedCustIds.get(i).get("AccountId"));
				} else if (sheetName.equalsIgnoreCase(appConfig.getCollateralSheet())) {
					map.put("Customer ID", listOfCustomerRelatedCustIds.get(i).get("CustomerId"));
					map.put("Charge_Funding_Account", listOfCustomerRelatedCustIds.get(i).get("AccountId"));
				} else if (sheetName.equalsIgnoreCase(appConfig.getLendingSheet())) {

					if (fromSheetName != null && fromSheetName.equalsIgnoreCase(appConfig.getCollateralSheet())
							&& !isCommitmentAndCollateral) {// ---------------------------------------
//						List<Map<String,String>> valueCalculationMap = collateralValueCalculationMap(listOfCustomerRelatedCustIds.get(i).get("Face_Value_Currency").toString());
						if (map.get("Loan_Request_Currency") != null
								&& listOfCustomerRelatedCustIds.get(i).get("Face_Value_Currency") != null
								&& map.get("Loan_Request_Currency").toString().equalsIgnoreCase(
										listOfCustomerRelatedCustIds.get(i).get("Face_Value_Currency").toString())) {
							map.put("Customer ID", listOfCustomerRelatedCustIds.get(i).get("Customer ID"));
//						map.put("Commitment_Id","");
							map.put("Fee_Collection_Account",
									listOfCustomerRelatedCustIds.get(i).get("Charge_Funding_Account"));
							map.put("Disbursement_Beneficiary_Account",
									listOfCustomerRelatedCustIds.get(i).get("Charge_Funding_Account"));

							if (map.get("Settlement_Type") != null
									&& !map.get("Settlement_Type").toString().equalsIgnoreCase("MANUAL-COLLECTION"))
								map.put("Repayment_Account",
										listOfCustomerRelatedCustIds.get(i).get("Charge_Funding_Account"));
							else
								map.put("Repayment_Account", "");

							if (map.get("Collateral_assignment_Value_Calculation") != null
									&& (map.get("Collateral_assignment_Value_Calculation").toString()
											.equalsIgnoreCase("COLLATERAL-ALLOCATION-PERCENTAGE")
											|| map.get("Collateral_assignment_Value_Calculation").toString()
													.equalsIgnoreCase("ACCOUNT-COVER-PERCENTAGE")
											|| map.get("Collateral_assignment_Value_Calculation").toString()
													.equalsIgnoreCase("FIXED-AMOUNT-ALLOCATION"))) {
								map.put("Collateral_Id", listOfCustomerRelatedCustIds.get(i).get("CollateralID"));
							}

							/*
							 * for(Map collValCalMap : valueCalculationMap) {
							 * map.put("Collateral_Id",listOfCustomerRelatedCustIds.get(i).get(
							 * "CollateralID"));
							 * map.put("Collateral_assignment_Value_Calculation",collValCalMap.get(
							 * "Collateral_assignment_Value_Calculation"));
							 * map.put("Percentage_Assignment",collValCalMap.get("Percentage_Assignment"));
							 * map.put("Fixed_Amount",collValCalMap.get("Fixed_Amount"));
							 * map.put("Fixed_Amount_Currency",collValCalMap.get("Fixed_Amount_Currency"));
							 * }
							 */

//						map.put("Collateral_assignment_Value_Calculation","COLLATERAL-ALLOCATION-PERCENTAGE");	
//						map.put("Percentage_Assignment","");	
//						map.put("Fixed_Amount","");	
//						map.put("Fixed_Amount_Currency","");	
//						map.put("Collateral_waiveCharge","");
						}
					}

					if (fromSheetName != null && fromSheetName.equalsIgnoreCase(appConfig.getCommitmentSheet())
							&& !isCommitmentAndCollateral) {
						if (map.get("Loan_Request_Currency") != null
								&& listOfCustomerRelatedCustIds.get(i).get("CommitmentAmount_Currency") != null
								&& map.get("Loan_Request_Currency").toString()
										.equalsIgnoreCase(listOfCustomerRelatedCustIds.get(i)
												.get("CommitmentAmount_Currency").toString())) {
							map.put("Customer ID", listOfCustomerRelatedCustIds.get(i).get("Customer ID"));
							map.put("Commitment_Id", listOfCustomerRelatedCustIds.get(i).get("Commitment Id"));
							map.put("Fee_Collection_Account",
									listOfCustomerRelatedCustIds.get(i).get("ChargeFundingAccount"));
							map.put("Disbursement_Beneficiary_Account",
									listOfCustomerRelatedCustIds.get(i).get("ChargeFundingAccount"));

							if (map.get("Settlement_Type") != null
									&& !map.get("Settlement_Type").toString().equalsIgnoreCase("MANUAL-COLLECTION"))
								map.put("Repayment_Account",
										listOfCustomerRelatedCustIds.get(i).get("ChargeFundingAccount"));
							else
								map.put("Repayment_Account", "");
//						map.put("Collateral_Id","");
//						map.put("Collateral_assignment_Value_Calculation","");	
//						map.put("Percentage_Assignment","");	
//						map.put("Fixed_Amount","");	
//						map.put("Fixed_Amount_Currency","");	
//						map.put("Collateral_waiveCharge","");
						}
					}
					if (fromSheetName != null && fromSheetName.equalsIgnoreCase(appConfig.getOpenAccountSheet())
							&& !isCommitmentAndCollateral) {
						map.put("Customer ID", listOfCustomerRelatedCustIds.get(i).get("CustomerId"));
						map.put("Fee_Collection_Account", listOfCustomerRelatedCustIds.get(i).get("AccountId"));
						if (map.get("Settlement_Type") != null
								&& !map.get("Settlement_Type").toString().equalsIgnoreCase("MANUAL-COLLECTION"))
							map.put("Repayment_Account", listOfCustomerRelatedCustIds.get(i).get("AccountId"));
						else
							map.put("Repayment_Account", "");
						map.put("Disbursement_Beneficiary_Account",
								listOfCustomerRelatedCustIds.get(i).get("AccountId"));
						map.put("Collateral_Id", "");
						map.put("Commitment_Id", "");
//						map.put("Collateral_assignment_Value_Calculation","");	
//						map.put("Percentage_Assignment","");	
//						map.put("Fixed_Amount","");	
//						map.put("Fixed_Amount_Currency","");	
//						map.put("Collateral_waiveCharge","");

					}

					if (isCommitmentAndCollateral) {
						if (map.get("Loan_Request_Currency") != null
								&& listOfCustomerRelatedCustIds.get(i).get("Face_Value_Currency") != null
								&& map.get("Loan_Request_Currency").toString().equalsIgnoreCase(
										listOfCustomerRelatedCustIds.get(i).get("Face_Value_Currency").toString())) {
//						List<Map<String,String>> valueCalculationMap = collateralValueCalculationMap(listOfCustomerRelatedCustIds.get(i).get("Face_Value_Currency").toString());
							map.put("Customer ID", listOfCustomerRelatedCustIds.get(i).get("Customer ID"));
							map.put("Fee_Collection_Account",
									listOfCustomerRelatedCustIds.get(i).get("Charge_Funding_Account"));
							if (map.get("Settlement_Type") != null
									&& !map.get("Settlement_Type").toString().equalsIgnoreCase("MANUAL-COLLECTION"))
								map.put("Repayment_Account",
										listOfCustomerRelatedCustIds.get(i).get("Charge_Funding_Account"));
							else
								map.put("Repayment_Account", "");

							map.put("Disbursement_Beneficiary_Account",
									listOfCustomerRelatedCustIds.get(i).get("Charge_Funding_Account"));
							if (map.get("Collateral_assignment_Value_Calculation") != null
									&& (map.get("Collateral_assignment_Value_Calculation").toString()
											.equalsIgnoreCase("COLLATERAL-ALLOCATION-PERCENTAGE")
											|| map.get("Collateral_assignment_Value_Calculation").toString()
													.equalsIgnoreCase("FIXED-AMOUNT-ALLOCATION")
											|| map.get("Collateral_assignment_Value_Calculation").toString()
													.equalsIgnoreCase("ACCOUNT-COVER-PERCENTAGE")
											|| map.get("Collateral_assignment_Value_Calculation").toString()
													.equalsIgnoreCase("FIXED-AMOUNT-ALLOCATION"))) {
								map.put("Collateral_Id", listOfCustomerRelatedCustIds.get(i).get("CollateralID")==null?"":listOfCustomerRelatedCustIds.get(i).get("CollateralID"));
							}
							/*
							 * for(Map collValCalMap : valueCalculationMap) {
							 * map.put("Collateral_Id",listOfCustomerRelatedCustIds.get(i).get(
							 * "CollateralID"));
							 * map.put("Collateral_assignment_Value_Calculation",collValCalMap.get(
							 * "Collateral_assignment_Value_Calculation"));
							 * map.put("Percentage_Assignment",collValCalMap.get("Percentage_Assignment"));
							 * map.put("Fixed_Amount",collValCalMap.get("Fixed_Amount"));
							 * map.put("Fixed_Amount_Currency",collValCalMap.get("Fixed_Amount_Currency"));
							 * }
							 */
							map.put("Commitment_Id", listOfCustomerRelatedCustIds.get(i).get("Commitment Id")==null?"":listOfCustomerRelatedCustIds.get(i).get("Commitment Id"));
						}
					}
				}

				tempMap = new LinkedHashMap<>(map);
				tempList.add(tempMap);
			}
			modifiableExcelDataSet.addAll(tempList);
		}
		modifiableExcelDataList.addAll(modifiableExcelDataSet);
		System.out.println(modifiableExcelDataList.size());
		return modifiableExcelDataList;
	}

	private static List<Map<String, String>> collateralValueCalculationMap(String currency) {
		// TODO Auto-generated method stub
		List<Map<String, String>> collaterAssignmentValueCalculationList = new ArrayList<>();
		Map<String, String> collaterValueCalculationMap = new HashMap<>();
		collaterValueCalculationMap.put("Collateral_assignment_Value_Calculation", "COLLATERAL-ALLOCATION-PERCENTAGE");
		collaterValueCalculationMap.put("Percentage_Assignment", "80");
		collaterValueCalculationMap.put("Fixed_Amount", "0");
		collaterValueCalculationMap.put("Fixed_Amount_Currency", "");
		collaterAssignmentValueCalculationList.add(collaterValueCalculationMap);

		collaterValueCalculationMap = new HashMap<>();
		collaterValueCalculationMap.put("Collateral_assignment_Value_Calculation", "FIXED-AMOUNT-ALLOCATION");
		collaterValueCalculationMap.put("Percentage_Assignment", "80");
		collaterValueCalculationMap.put("Fixed_Amount", "8000");
		collaterValueCalculationMap.put("Fixed_Amount_Currency", currency);
		collaterAssignmentValueCalculationList.add(collaterValueCalculationMap);

		collaterValueCalculationMap = new HashMap<>();
		collaterValueCalculationMap.put("Collateral_assignment_Value_Calculation", "ACCOUNT-COVER-PERCENTAGE");
		collaterValueCalculationMap.put("Percentage_Assignment", "80");
		collaterValueCalculationMap.put("Fixed_Amount", "0");
		collaterValueCalculationMap.put("Fixed_Amount_Currency", "");
		collaterAssignmentValueCalculationList.add(collaterValueCalculationMap);

		return collaterAssignmentValueCalculationList;
	}

	public static void pushToExcelSheet(List<Map<String, Object>> modifiableExcelDataList, String filePath,
			String sheetName) throws IOException {
		File outputFile = new File(filePath);
		writeDataToExcel(modifiableExcelDataList, outputFile, sheetName);
	}

	public static void writeDataToExcel(List<Map<String, Object>> data, File fileName, String sheetName)
			throws IOException {
		logger.info("Writing into the sheet : " + sheetName);

//		FileInputStream fis = new FileInputStream(fileName);
		int lastRowToKeep = data.size(); // Change this to the last row you want to keep (0-based index)

		try (FileInputStream fis = new FileInputStream(fileName); XSSFWorkbook workbook = new XSSFWorkbook(fis)) {

//            Sheet sheet = workbook.getSheetAt(0); // Get the first sheet
			XSSFSheet sheet = workbook.getSheet(sheetName);
			// Remove rows beyond the specified last row to keep
			for (int rowIndex = sheet.getLastRowNum(); rowIndex > lastRowToKeep; rowIndex--) {
				Row row = sheet.getRow(rowIndex);
				if (row != null) {
					sheet.removeRow(row);
				}
			}

			// Workbook object
//		XSSFWorkbook workbook = new XSSFWorkbook(fis);

			// Spreadsheet object
//		XSSFSheet sheet = workbook.getSheet(sheetName);

			// Create header row
			Set<String> headers = data.get(0).keySet();
			/*
			 * // Creating Header Row Row headerRow = sheet.createRow(0); int headerIndex =
			 * 0; for (String header : headers) { Cell cell =
			 * headerRow.createCell(headerIndex++); cell.setCellValue(header); }
			 */

			// Write data rows
			int rowIndex = 1;
			for (Map<String, Object> rowData : data) {
				Row row = sheet.createRow(rowIndex++);
				int cellIndex = 0;
				for (String header : headers) {
					Cell cell = row.createCell(cellIndex++);
					if (rowData.get(header) != null) {
						System.out.println(rowData.get(header).toString());
						if (rowData.get(header).toString().contains(".")) {
							String intValue = rowData.get(header).toString().split("\\.")[0];
							cell.setCellValue(intValue); // Update the cell value
						} else
							cell.setCellValue(rowData.get(header).toString());
					}
				}
			}

			// Write the changes back to the file
			try (FileOutputStream fos = new FileOutputStream(fileName)) {
				workbook.write(fos);
			}

			System.out.println("Remaining rows removed successfully.");

			// Close the workbook

			workbook.close();

		} catch (IOException e) {
			e.printStackTrace();
		}

	}

}
