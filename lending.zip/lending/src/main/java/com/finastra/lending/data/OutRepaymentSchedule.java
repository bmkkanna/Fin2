package com.finastra.lending.data;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class OutRepaymentSchedule {
	
	    public String repaymentDate;

		public String getRepaymentDate() {
			return repaymentDate;
		}

		public void setRepaymentDate(String repaymentDate) {
			this.repaymentDate = repaymentDate;
		}
	    
}
