package com.finastra.lending.data;

   
public class EventCharges {

   String chargeAction;

   String chargeAmendReason;

   ChargeAmount chargeAmount;

   String chargeCode;

   String chargeNarrative;

   boolean waiveCharge;


    public void setChargeAction(String chargeAction) {
        this.chargeAction = chargeAction;
    }
    public String getChargeAction() {
        return chargeAction;
    }
    
    public void setChargeAmendReason(String chargeAmendReason) {
        this.chargeAmendReason = chargeAmendReason;
    }
    public String getChargeAmendReason() {
        return chargeAmendReason;
    }
    
    public void setChargeAmount(ChargeAmount chargeAmount) {
        this.chargeAmount = chargeAmount;
    }
    public ChargeAmount getChargeAmount() {
        return chargeAmount;
    }
    
    public void setChargeCode(String chargeCode) {
        this.chargeCode = chargeCode;
    }
    public String getChargeCode() {
        return chargeCode;
    }
    
    public void setChargeNarrative(String chargeNarrative) {
        this.chargeNarrative = chargeNarrative;
    }
    public String getChargeNarrative() {
        return chargeNarrative;
    }
    
    public void setWaiveCharge(boolean waiveCharge) {
        this.waiveCharge = waiveCharge;
    }
    public boolean getWaiveCharge() {
        return waiveCharge;
    }
    
}