package com.finastra.lending.data;


public class LoanTerm {

   Object calendarPeriod;

   String value;


    public void setCalendarPeriod(Object calendarPeriod) {
        this.calendarPeriod = calendarPeriod;
    }
    public Object getCalendarPeriod() {
        return calendarPeriod;
    }
    
    public void setValue(String value) {
        this.value = value;
    }
    public String getValue() {
        return value;
    }
    
}