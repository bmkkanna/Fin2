package com.finastra.lending.data;

   
public class CustomerContributionAmount {

	 String amount;

	 String currency;


    public void setAmount(String object) {
        this.amount = object;
    }
    public String getAmount() {
        return amount;
    }
    
    public void setCurrency(String currency) {
        this.currency = currency;
    }
    public String getCurrency() {
        return currency;
    }
    
}