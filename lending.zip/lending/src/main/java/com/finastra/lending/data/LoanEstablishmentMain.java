package com.finastra.lending.data;

import java.util.Date;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;

public class LoanEstablishmentMain {

	List<AdhocLoanEstablishmentCharges> adhocLoanEstablishmentCharges;

	Custom_fields custom_fields;
	
	CustomerContributionAmount customerContributionAmount;

	String customerInterestMargin;

//	BalloonPaymentAmount balloonPaymentAmount;

	CollateralDetails collateralDetails;

	String commitmentId;
	 @JsonIgnore
String outPutLoanApplicationId;
	 
	 @JsonIgnore
		String outPutcustomerId;

	 @JsonIgnore
		String outPutcustomerName;
	 @JsonIgnore
		String outPutcustomerType;
	 @JsonIgnore
		String outPutBranch;
	 @JsonIgnore
		String outPutProductName;
	 @JsonIgnore
		String outPutLoanPurpose;
	 @JsonIgnore
		String outPutLoanAmount;
	 
	 @JsonIgnore
		String outPutCurrency;
	 @JsonIgnore
		String outPutRepaymentEffective;
	 @JsonIgnore
		String outPutRepaymentStartDate;
	 
	 
	
	public String getOutPutcustomerId() {
		return outPutcustomerId;
	}

	public void setOutPutcustomerId(String outPutcustomerId) {
		this.outPutcustomerId = outPutcustomerId;
	}

	public String getOutPutcustomerName() {
		return outPutcustomerName;
	}

	public void setOutPutcustomerName(String outPutcustomerName) {
		this.outPutcustomerName = outPutcustomerName;
	}

	public String getOutPutcustomerType() {
		return outPutcustomerType;
	}

	public void setOutPutcustomerType(String outPutcustomerType) {
		this.outPutcustomerType = outPutcustomerType;
	}

	public String getOutPutBranch() {
		return outPutBranch;
	}

	public void setOutPutBranch(String outPutBranch) {
		this.outPutBranch = outPutBranch;
	}

	public String getOutPutProductName() {
		return outPutProductName;
	}

	public void setOutPutProductName(String outPutProductName) {
		this.outPutProductName = outPutProductName;
	}

	public String getOutPutLoanPurpose() {
		return outPutLoanPurpose;
	}

	public void setOutPutLoanPurpose(String outPutLoanPurpose) {
		this.outPutLoanPurpose = outPutLoanPurpose;
	}

	public String getOutPutLoanAmount() {
		return outPutLoanAmount;
	}

	public void setOutPutLoanAmount(String outPutLoanAmount) {
		this.outPutLoanAmount = outPutLoanAmount;
	}

	public String getOutPutCurrency() {
		return outPutCurrency;
	}

	public void setOutPutCurrency(String outPutCurrency) {
		this.outPutCurrency = outPutCurrency;
	}

	public String getOutPutRepaymentEffective() {
		return outPutRepaymentEffective;
	}

	public void setOutPutRepaymentEffective(String outPutRepaymentEffective) {
		this.outPutRepaymentEffective = outPutRepaymentEffective;
	}

	public String getOutPutRepaymentStartDate() {
		return outPutRepaymentStartDate;
	}

	public void setOutPutRepaymentStartDate(String outPutRepaymentStartDate) {
		this.outPutRepaymentStartDate = outPutRepaymentStartDate;
	}

	public String getLoanApplicationId() {
	return loanApplicationId;
}

public void setLoanApplicationId(String loanApplicationId) {
	this.loanApplicationId = loanApplicationId;
}

public String getLoanId() {
	return loanId;
}

public void setLoanId(String loanId) {
	this.loanId = loanId;
}

public List<OutputLoanApplicants> getOutLoanApplicants() {
	return outLoanApplicants;
}

public void setOutLoanApplicants(List<OutputLoanApplicants> outLoanApplicants) {
	this.outLoanApplicants = outLoanApplicants;
}

public String getOutLoanAccountBranch() {
	return outLoanAccountBranch;
}

public void setOutLoanAccountBranch(String outLoanAccountBranch) {
	this.outLoanAccountBranch = outLoanAccountBranch;
}

public String getOutProductName() {
	return outProductName;
}

public void setOutProductName(String outProductName) {
	this.outProductName = outProductName;
}

public String getOutLoanPurpose() {
	return outLoanPurpose;
}

public void setOutLoanPurpose(String outLoanPurpose) {
	this.outLoanPurpose = outLoanPurpose;
}

public OutputLoanRequestAmount getOutPoanRequestAmount() {
	return outPoanRequestAmount;
}

public void setOutPoanRequestAmount(OutputLoanRequestAmount outPoanRequestAmount) {
	this.outPoanRequestAmount = outPoanRequestAmount;
}

public OutputCustomerContributionAmount getOutCustomerContributionAmount() {
	return outCustomerContributionAmount;
}

public void setOutCustomerContributionAmount(OutputCustomerContributionAmount outCustomerContributionAmount) {
	this.outCustomerContributionAmount = outCustomerContributionAmount;
}

public OutputPrincipalAmount getOutPrincipalAmount() {
	return outPrincipalAmount;
}

public void setOutPrincipalAmount(OutputPrincipalAmount outPrincipalAmount) {
	this.outPrincipalAmount = outPrincipalAmount;
}

public String getOutLoanStartDate() {
	return outLoanStartDate;
}

public void setOutLoanStartDate(String outLoanStartDate) {
	this.outLoanStartDate = outLoanStartDate;
}

public LoanTerm getOutLoanTerm() {
	return outLoanTerm;
}

public void setOutLoanTerm(LoanTerm outLoanTerm) {
	this.outLoanTerm = outLoanTerm;
}

public String getOutRepaymentType() {
	return outRepaymentType;
}

public void setOutRepaymentType(String outRepaymentType) {
	this.outRepaymentType = outRepaymentType;
}

public String getOutRepaymentFrequency() {
	return outRepaymentFrequency;
}

public void setOutRepaymentFrequency(String outRepaymentFrequency) {
	this.outRepaymentFrequency = outRepaymentFrequency;
}

public String getOutMaturityDate() {
	return outMaturityDate;
}

public void setOutMaturityDate(String outMaturityDate) {
	this.outMaturityDate = outMaturityDate;
}

public String getOutInterestRateType() {
	return outInterestRateType;
}

public void setOutInterestRateType(String outInterestRateType) {
	this.outInterestRateType = outInterestRateType;
}

public int getOutProductInterestRate() {
	return outProductInterestRate;
}

public void setOutProductInterestRate(int outProductInterestRate) {
	this.outProductInterestRate = outProductInterestRate;
}

public int getOutCustomerInterestMargin() {
	return outCustomerInterestMargin;
}

public void setOutCustomerInterestMargin(int outCustomerInterestMargin) {
	this.outCustomerInterestMargin = outCustomerInterestMargin;
}

public int getOutEffectiveInterestRate() {
	return outEffectiveInterestRate;
}

public void setOutEffectiveInterestRate(int outEffectiveInterestRate) {
	this.outEffectiveInterestRate = outEffectiveInterestRate;
}

public String getOutInterestRatePostFixed() {
	return outInterestRatePostFixed;
}

public void setOutInterestRatePostFixed(String outInterestRatePostFixed) {
	this.outInterestRatePostFixed = outInterestRatePostFixed;
}

public Date getOutInterestResetDate() {
	return outInterestResetDate;
}

public void setOutInterestResetDate(Date outInterestResetDate) {
	this.outInterestResetDate = outInterestResetDate;
}

public String getOutPepaymentAccount() {
	return outPepaymentAccount;
}

public void setOutPepaymentAccount(String outPepaymentAccount) {
	this.outPepaymentAccount = outPepaymentAccount;
}

public String getOutFeeCollectionAccount() {
	return outFeeCollectionAccount;
}

public void setOutFeeCollectionAccount(String outFeeCollectionAccount) {
	this.outFeeCollectionAccount = outFeeCollectionAccount;
}

public int getOutAnnualPercentageRate() {
	return outAnnualPercentageRate;
}

public void setOutAnnualPercentageRate(int outAnnualPercentageRate) {
	this.outAnnualPercentageRate = outAnnualPercentageRate;
}
@JsonInclude(JsonInclude.Include.NON_NULL) 
	String loanApplicationId;

	String loanId;

	List<OutputLoanApplicants> outLoanApplicants;
	 @JsonIgnore
	String outLoanAccountBranch;
	 @JsonIgnore
	String outProductName;
	 @JsonIgnore
	String outLoanPurpose;
	 @JsonIgnore
	OutputLoanRequestAmount outPoanRequestAmount;
	 @JsonIgnore
	OutputCustomerContributionAmount outCustomerContributionAmount;
	 @JsonIgnore
	OutputPrincipalAmount outPrincipalAmount;
	 @JsonIgnore
	String outLoanStartDate;
	 @JsonIgnore
	LoanTerm outLoanTerm;
	 @JsonIgnore
	String outRepaymentType;
	 @JsonIgnore
	String outRepaymentFrequency;
	 @JsonIgnore
	String outMaturityDate;
	 @JsonIgnore
	String outInterestRateType;
	 @JsonIgnore
	int outProductInterestRate;
	 @JsonIgnore
	int outCustomerInterestMargin;
	 @JsonIgnore
	int outEffectiveInterestRate;
	 @JsonIgnore
	String outInterestRatePostFixed;
	 @JsonIgnore
	Date outInterestResetDate;
	 @JsonIgnore
	String outPepaymentAccount;
	 @JsonIgnore
	String outFeeCollectionAccount;
	 @JsonIgnore
	int outAnnualPercentageRate;
	public String getOutPutLoanApplicationId() {
		return outPutLoanApplicationId;
	}

	public void setOutPutLoanApplicationId(String outPutLoanApplicationId) {
		this.outPutLoanApplicationId = outPutLoanApplicationId;
	}

	List<DisbursementScheduleRequest> disbursementScheduleRequest;

	List<EventCharges> eventCharges;

	String feeCollectionAccount;

	InterestDetails interestDetails;

	public InterestDetails getInterestDetails() {
		return interestDetails;
	}

	public void setInterestDetails(InterestDetails interestDetails) {
		this.interestDetails = interestDetails;
	}

	String kycCheckRequired;

	List<LoanApplicantIds> loanApplicantIds;

//	LoanAgreementDetails loanAgreementDetails;

	LoanRequestAmount loanRequestAmount;

	String loanStartDate;

	String loanTaxFundingAccount;

	LoanTerm loanTerm;

	String mandateReference;

	Object maturityDateCalculation;

//	Date moratoriumEndDate;

	int moratoriumPeriod;

	String moratoriumType;

	//PaymentMandateDetails paymentMandateDetails;

	String productCode;

	Object repaymentAccount;

	String repaymentFrequency;

	String repaymentStartDate;

	Object retentionPeriod;

	String settlementType;

	String waiveCharge;

	String outLoanId;

	public String getOutLoanId() {
		return outLoanId;
	}

	public void setOutLoanId(String outLoanId) {
		this.outLoanId = outLoanId;
	}

	@JsonIgnore
	private int rownum;

	@JsonIgnore
	private String status;

	@JsonIgnore
	private String errorMessage;

	public void setAdhocLoanEstablishmentCharges(List<AdhocLoanEstablishmentCharges> adhocLoanEstablishmentCharges) {
		this.adhocLoanEstablishmentCharges = adhocLoanEstablishmentCharges;
	}

	public List<AdhocLoanEstablishmentCharges> getAdhocLoanEstablishmentCharges() {
		return adhocLoanEstablishmentCharges;
	}

//	public void setBalloonPaymentAmount(BalloonPaymentAmount balloonPaymentAmount) {
//		this.balloonPaymentAmount = balloonPaymentAmount;
//	}
//
//	public BalloonPaymentAmount getBalloonPaymentAmount() {
//		return balloonPaymentAmount;
//	}

	public void setCollateralDetails(CollateralDetails collateralDetails) {
		this.collateralDetails = collateralDetails;
	}

	public CollateralDetails getCollateralDetails() {
		return collateralDetails;
	}

	public void setCommitmentId(String commitmentId) {
		this.commitmentId = commitmentId;
	}

	public String getCommitmentId() {
		return commitmentId;
	}

	public Custom_fields getCustom_fields() {
		return custom_fields;
	}

	public void setCustom_fields(Custom_fields custom_fields) {
		this.custom_fields = custom_fields;
	}

	public void setCustomerContributionAmount(CustomerContributionAmount customerContributionAmount) {
		this.customerContributionAmount = customerContributionAmount;
	}

	public CustomerContributionAmount getCustomerContributionAmount() {
		return customerContributionAmount;
	}

	public void setCustomerInterestMargin(String customerInterestMargin) {
		this.customerInterestMargin = customerInterestMargin;
	}

	public String getCustomerInterestMargin() {
		return customerInterestMargin;
	}

	public void setDisbursementScheduleRequest(List<DisbursementScheduleRequest> disbursementScheduleRequest) {
		this.disbursementScheduleRequest = disbursementScheduleRequest;
	}

	public List<DisbursementScheduleRequest> getDisbursementScheduleRequest() {
		return disbursementScheduleRequest;
	}

	public void setEventCharges(List<EventCharges> eventCharges) {
		this.eventCharges = eventCharges;
	}

	public List<EventCharges> getEventCharges() {
		return eventCharges;
	}

	public void setFeeCollectionAccount(String feeCollectionAccount) {
		this.feeCollectionAccount = feeCollectionAccount;
	}

	public String getFeeCollectionAccount() {
		return feeCollectionAccount;
	}

//	public void setInterestDetails(InterestDetails interestDetails) {
//		this.interestDetails = interestDetails;
//	}
//
//	public InterestDetails getInterestDetails() {
//		return interestDetails;
//	}

	public void setKycCheckRequired(String kycCheckRequired) {
		this.kycCheckRequired = kycCheckRequired;
	}

	public String getKycCheckRequired() {
		return kycCheckRequired;
	}

/*	public void setLoanAgreementDetails(LoanAgreementDetails loanAgreementDetails) {
		this.loanAgreementDetails = loanAgreementDetails;
	}

	public LoanAgreementDetails getLoanAgreementDetails() {
		return loanAgreementDetails;
	}*/

	public void setLoanApplicantIds(List<LoanApplicantIds> loanApplicantIds) {
		this.loanApplicantIds = loanApplicantIds;
	}

	public List<LoanApplicantIds> getLoanApplicantIds() {
		return loanApplicantIds;
	}

	public void setLoanRequestAmount(LoanRequestAmount loanRequestAmount) {
		this.loanRequestAmount = loanRequestAmount;
	}

	public LoanRequestAmount getLoanRequestAmount() {
		return loanRequestAmount;
	}

	public void setLoanStartDate(String loanStartDate) {
		this.loanStartDate = loanStartDate;
	}

	public String getLoanStartDate() {
		return loanStartDate;
	}

	public void setLoanTaxFundingAccount(String loanTaxFundingAccount) {
		this.loanTaxFundingAccount = loanTaxFundingAccount;
	}

	public String getLoanTaxFundingAccount() {
		return loanTaxFundingAccount;
	}

	public void setLoanTerm(LoanTerm loanTerm) {
		this.loanTerm = loanTerm;
	}

	public LoanTerm getLoanTerm() {
		return loanTerm;
	}

	public void setMandateReference(String mandateReference) {
		this.mandateReference = mandateReference;
	}

	public String getMandateReference() {
		return mandateReference;
	}

	public void setMaturityDateCalculation(Object maturityDateCalculation) {
		this.maturityDateCalculation = maturityDateCalculation;
	}

	public Object getMaturityDateCalculation() {
		return maturityDateCalculation;
	}

//	public void setMoratoriumEndDate(Date moratoriumEndDate) {
//		this.moratoriumEndDate = moratoriumEndDate;
//	}
//
//	public Date getMoratoriumEndDate() {
//		return moratoriumEndDate;
//	}

	public void setMoratoriumPeriod(int moratoriumPeriod) {
		this.moratoriumPeriod = moratoriumPeriod;
	}

	public int getMoratoriumPeriod() {
		return moratoriumPeriod;
	}

	public void setMoratoriumType(String moratoriumType) {
		this.moratoriumType = moratoriumType;
	}

	public String getMoratoriumType() {
		return moratoriumType;
	}

	/*public void setPaymentMandateDetails(PaymentMandateDetails paymentMandateDetails) {
		this.paymentMandateDetails = paymentMandateDetails;
	}

	public PaymentMandateDetails getPaymentMandateDetails() {
		return paymentMandateDetails;
	}*/

	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}

	public String getProductCode() {
		return productCode;
	}

	public void setRepaymentAccount(Object repaymentAccount) {
		this.repaymentAccount = repaymentAccount;
	}

	public Object getRepaymentAccount() {
		return repaymentAccount;
	}

	public void setRepaymentFrequency(String repaymentFrequency) {
		this.repaymentFrequency = repaymentFrequency;
	}

	public String getRepaymentFrequency() {
		return repaymentFrequency;
	}

	public void setRepaymentStartDate(String repaymentStartDate) {
		this.repaymentStartDate = repaymentStartDate;
	}

	public String getRepaymentStartDate() {
		return repaymentStartDate;
	}

	public void setRetentionPeriod(Object retentionPeriod) {
		this.retentionPeriod = retentionPeriod;
	}

	public Object getRetentionPeriod() {
		return retentionPeriod;
	}

	public void setSettlementType(String settlementType) {
		this.settlementType = settlementType;
	}

	public String getSettlementType() {
		return settlementType;
	}

	public void setWaiveCharge(String waiveCharge) {
		this.waiveCharge = waiveCharge;
	}

	public String getWaiveCharge() {
		return waiveCharge;
	}

	public int getRownum() {
		return rownum;
	}

	public void setRownum(int rownum) {
		this.rownum = rownum;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getErrorMessage() {
		return errorMessage;
	}

	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}

}