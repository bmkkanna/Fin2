package com.finastra.lending.data;

import java.util.List;

   
public class CollateralDetails {

   List<AdhocChargeDetails> adhocChargeDetails;

   List<AssignmentDetails> assignmentDetails;

   boolean waiveCharge;


    public void setAdhocChargeDetails(List<AdhocChargeDetails> adhocChargeDetails) {
        this.adhocChargeDetails = adhocChargeDetails;
    }
    public List<AdhocChargeDetails> getAdhocChargeDetails() {
        return adhocChargeDetails;
    }
    
    public void setAssignmentDetails(List<AssignmentDetails> assignmentDetails) {
        this.assignmentDetails = assignmentDetails;
    }
    public List<AssignmentDetails> getAssignmentDetails() {
        return assignmentDetails;
    }
    
    public void setWaiveCharge(boolean waiveCharge) {
        this.waiveCharge = waiveCharge;
    }
    public boolean getWaiveCharge() {
        return waiveCharge;
    }
    
}