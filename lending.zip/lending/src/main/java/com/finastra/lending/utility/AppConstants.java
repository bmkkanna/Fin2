package com.finastra.lending.utility;

/**
 *@author Prabhat
 */
public class AppConstants {
	
	//File name and location.
	public static final String APP_CONFIGURATION_FILE="app.properties";
	
	//Configuration File name and location.
	public static final boolean IS_EXTERNAL_CONFIGURATION = true;
	public static final String EXTERNAL_CONF_FILE_EXIST = "External configuration file exists.";
	public static final String EXTERNAL_CONF_FILE_NOT_EXIST = "External configuration file is not exists.";
	
	
	public static final String EXTERNAL_CONF_FILE_SUPPLIED = "External configuration file supplied.";
	public static final String EXTERNAL_CONF_FILE_NOT_SUPPLIED = "External configuration file is not supplied.";
	
	
	//Messages.
	public static final String APP_CONFIGURATION_MSG = "Initializing application.";
	public static final String APP_CONFIGURATION_SUCCESSFUL_MSG = "Application initialization and configuration is successfully completed.";
	public static final String APP_CONFIGURATION_FILE_ERROR ="Unable to load configuration file or failed to read from configuration file.";
	public static final String INPUT_FILE_DOES_NOT_EXIST_MSG = "Input file does not exist.";
	public static final String INPUT_FILE_READ_SUCCESSFULLY_MSG = "Excel sheet has been read successfully.";
	public static final String INPUT_EXCEL_FILE_ERROR_MSG = "Excel file has additional column. It may cause error.";
	public static final String YES_STRING_MSG = "YES";
	public static final String NO_STRING_MSG = "NO";
	public static final String OUTPUT_EXCEL_FILE_EXISTS = "Output Excel file exists.";
	public static final String OUTPUT_EXCEL_FILE_NOT_EXIST = "Output Excel file does not exist.";
	public static final String OUTPUT_EXCEL_FILE_CREATED_MSG = "Output Excel file has been created.";
	public static final String OUTPUT_EXCEL_SHEET_EXISTS = "Output Excel sheet exists.";
	public static final String OUTPUT_EXCEL_SHEET_NOT_EXIST = "Output Excel sheet does not exist.";
	public static final String OUTPUT_EXCEL_SHEET_CREATED_MSG = "Output Excel sheet has been created.";
	
	public static final String STATUS_SUCCESS = "SUCCESS";
	public static final String STATUS_FAILED = "FAILED";
	public static final String API_CALL_FAILED = "API Call failed.";
	public static final String PROCESSING_OUTPUT_EXCEL_SHEET = "Processing output excel sheet.";
	public static final String PROCESSING_INPUT_EXCEL_SHEET = "Processing input excel sheet.";
	
	//Http Param property
	public static final String ACCEPT_PARAM = "Accept";
	public static final String CONTENT_TYPE_PARAM="Content-Type";
	public static final String CONTENT_TYPE_PARAM_VAL="application/json";
	public static final String AUTHORIZATION_PARAM = "Authorization";
	public static final String X_REQUEST_ID_PARAM = "X-Request-ID";
	public static final String IDEMPOTENCY_KEY_PARAM = "Idempotency-Key";
	
	//Http Response Capture
	public static final String HTTP_RESPONSE_STATUS_CODE = "RESPONSE_STATUS_CODE";
	public static final String HTTP_RESPONSE_CONTENT = "RESPONSE_CONTENT";
	
	//Http login url property
	public static final String SSO_LOGIN_URL = "/bfweb/retail/MisysSSOFBPService/SSOloginService";
	public static final String SSO_LOGIN_ERROR = "SSO Login Error.";
	public static final String SSO_LOGIN_MESSAGE = "SSO Login Successful and auth token obtained.";
	
	//Http logout url property
	public static final String SSO_LOGOUT_URL = "/bfweb/retail/MisysSSOFBPService/SSOLogoutService";
	public static final String SSO_LOGOUT_ERROR = "SSO Logout Error.";
	public static final String SSO_LOGOUT_MESSAGE = "SSO logout Successful.";
	
	//Account API
	
	public static final String LOAN_API_ERROR_MSG = "Error occurs while fetching or processing Account API.";
	public static final String LOAN_API_SUCCESS_RESPONSE_STATUS_CODE = "201";
	
	//Loan API
	public static final String CREATE_LOAN_API_URL = "/bfweb/retail/v1/loans";

	
	
	
}
