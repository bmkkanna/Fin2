package com.finastra.lending.data;

import java.util.Date;

   
public class MandateDetails {

   String amountType;

   String collectionFrequency;

   String creditAccountId;

   String creditBankIdentifier;

   String debitAccountId;

   String debitAccountType;

   String debitBankIdentifier;

   String debitCustomerCountry;

   String mandateCurrency;

   String paymentScheme;

   String relatedIdentifier;

   Date validFromDate;


    public void setAmountType(String amountType) {
        this.amountType = amountType;
    }
    public String getAmountType() {
        return amountType;
    }
    
    public void setCollectionFrequency(String collectionFrequency) {
        this.collectionFrequency = collectionFrequency;
    }
    public String getCollectionFrequency() {
        return collectionFrequency;
    }
    
    public void setCreditAccountId(String creditAccountId) {
        this.creditAccountId = creditAccountId;
    }
    public String getCreditAccountId() {
        return creditAccountId;
    }
    
    public void setCreditBankIdentifier(String creditBankIdentifier) {
        this.creditBankIdentifier = creditBankIdentifier;
    }
    public String getCreditBankIdentifier() {
        return creditBankIdentifier;
    }
    
    public void setDebitAccountId(String debitAccountId) {
        this.debitAccountId = debitAccountId;
    }
    public String getDebitAccountId() {
        return debitAccountId;
    }
    
    public void setDebitAccountType(String debitAccountType) {
        this.debitAccountType = debitAccountType;
    }
    public String getDebitAccountType() {
        return debitAccountType;
    }
    
    public void setDebitBankIdentifier(String debitBankIdentifier) {
        this.debitBankIdentifier = debitBankIdentifier;
    }
    public String getDebitBankIdentifier() {
        return debitBankIdentifier;
    }
    
    public void setDebitCustomerCountry(String debitCustomerCountry) {
        this.debitCustomerCountry = debitCustomerCountry;
    }
    public String getDebitCustomerCountry() {
        return debitCustomerCountry;
    }
    
    public void setMandateCurrency(String mandateCurrency) {
        this.mandateCurrency = mandateCurrency;
    }
    public String getMandateCurrency() {
        return mandateCurrency;
    }
    
    public void setPaymentScheme(String paymentScheme) {
        this.paymentScheme = paymentScheme;
    }
    public String getPaymentScheme() {
        return paymentScheme;
    }
    
    public void setRelatedIdentifier(String relatedIdentifier) {
        this.relatedIdentifier = relatedIdentifier;
    }
    public String getRelatedIdentifier() {
        return relatedIdentifier;
    }
    
    public void setValidFromDate(Date validFromDate) {
        this.validFromDate = validFromDate;
    }
    public Date getValidFromDate() {
        return validFromDate;
    }
    
}