/**
 * 
 */
package com.finastra.lending.utility;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class AppException extends Exception {

	static final long serialVersionUID = 1L;

	private static final Logger logger = LoggerFactory.getLogger(AppException.class);

	private String errorMessage = "";

	public AppException(String errorMessage) {
		super();
		this.errorMessage = errorMessage;
	}

	public AppException(Throwable th, String errorMessage) {
		super(th);
		logger.error(errorMessage);
		logger.error(th.getMessage());
	}
}
