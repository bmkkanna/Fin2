package com.finastra.lending.data;

public class AdhocLoanEstablishmentCharges {

   String chargeAction;

   ChargeAmount chargeAmount;

   String chargeDescription;


    public void setChargeAction(String chargeAction) {
        this.chargeAction = chargeAction;
    }
    public String getChargeAction() {
        return chargeAction;
    }
    
    public void setChargeAmount(ChargeAmount chargeAmount) {
        this.chargeAmount = chargeAmount;
    }
    public ChargeAmount getChargeAmount() {
        return chargeAmount;
    }
    
    public void setChargeDescription(String chargeDescription) {
        this.chargeDescription = chargeDescription;
    }
    public String getChargeDescription() {
        return chargeDescription;
    }
    
}