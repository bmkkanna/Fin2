package com.finastra.lending.data;

public class OutputLoanTerm {

	String calendarPeriod;

	int value;

	public void setCalendarPeriod(String calendarPeriod) {
		this.calendarPeriod = calendarPeriod;
	}

	public String getCalendarPeriod() {
		return calendarPeriod;
	}

	public void setValue(int value) {
		this.value = value;
	}

	public int getValue() {
		return value;
	}

}