package com.finastra.lending.data;

   
public class LoanApplicantIds {

   Object customerId;


    public void setCustomerId(Object customerId) {
        this.customerId = customerId;
    }
    public Object getCustomerId() {
        return customerId;
    }
    
}