package com.finastra.lending.data;

import java.util.Date;

   
public class StructuredAddress {

   String addressLine1;

   String addressLine2;

   String addressLine3;

   String addressLine4;

   String addressLine5;

   String country;

   String postCode;

   String stateProvince;

   String townOrCity;

   Date validFrom;

   Date validTo;


    public void setAddressLine1(String addressLine1) {
        this.addressLine1 = addressLine1;
    }
    public String getAddressLine1() {
        return addressLine1;
    }
    
    public void setAddressLine2(String addressLine2) {
        this.addressLine2 = addressLine2;
    }
    public String getAddressLine2() {
        return addressLine2;
    }
    
    public void setAddressLine3(String addressLine3) {
        this.addressLine3 = addressLine3;
    }
    public String getAddressLine3() {
        return addressLine3;
    }
    
    public void setAddressLine4(String addressLine4) {
        this.addressLine4 = addressLine4;
    }
    public String getAddressLine4() {
        return addressLine4;
    }
    
    public void setAddressLine5(String addressLine5) {
        this.addressLine5 = addressLine5;
    }
    public String getAddressLine5() {
        return addressLine5;
    }
    
    public void setCountry(String country) {
        this.country = country;
    }
    public String getCountry() {
        return country;
    }
    
    public void setPostCode(String postCode) {
        this.postCode = postCode;
    }
    public String getPostCode() {
        return postCode;
    }
    
    public void setStateProvince(String stateProvince) {
        this.stateProvince = stateProvince;
    }
    public String getStateProvince() {
        return stateProvince;
    }
    
    public void setTownOrCity(String townOrCity) {
        this.townOrCity = townOrCity;
    }
    public String getTownOrCity() {
        return townOrCity;
    }
    
    public void setValidFrom(Date validFrom) {
        this.validFrom = validFrom;
    }
    public Date getValidFrom() {
        return validFrom;
    }
    
    public void setValidTo(Date validTo) {
        this.validTo = validTo;
    }
    public Date getValidTo() {
        return validTo;
    }
    
}