package com.finastra.lending.data;

   
public class RateEffectiveDateTime {


}