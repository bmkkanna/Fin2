package com.finastra.lending.data;

   
public class FixedRateDetails {

   double effectiveRate;

   String rateId;


    public void setEffectiveRate(double effectiveRate) {
        this.effectiveRate = effectiveRate;
    }
    public double getEffectiveRate() {
        return effectiveRate;
    }
    
    public void setRateId(String rateId) {
        this.rateId = rateId;
    }
    public String getRateId() {
        return rateId;
    }
    
}