package com.finastra.lending.controller;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.finastra.lending.config.AppConfig;
import com.finastra.lending.data.LoanEstablishmentMain;
import com.finastra.lending.data.OutputLoanEstablishmentMain;
import com.finastra.lending.model.ModelProcessor;
import com.finastra.lending.utility.AppConstants;
import com.finastra.lending.utility.AppException;


public class AppFrontController {

	private static final Logger logger = LoggerFactory.getLogger(AppFrontController.class);

	private AppConfig appConfig = null;

	private ModelProcessor modelProcessor = null;

	public AppFrontController(AppConfig appConfig) {
		super();
		this.appConfig = appConfig;
		modelProcessor = new ModelProcessor();
	}

	public void setModelProcessor(ModelProcessor modelProcessor) {
		this.modelProcessor = modelProcessor;
	}

	public List<LoanEstablishmentMain> readInputFile() {
		File inputFile = modelProcessor.obtainInputFileObject(appConfig);

		List<LoanEstablishmentMain> loanEstablishMain = null;

		if (inputFile.exists()) {
			loanEstablishMain = modelProcessor.readInputFileAndUpdatePOJO(inputFile, appConfig);
		} else {
			logger.error(AppConstants.INPUT_FILE_DOES_NOT_EXIST_MSG);
		}

		return loanEstablishMain;
	}

	public void pushLoanApi(List<LoanEstablishmentMain> inPutDetailsList) throws Exception {
		ArrayList<OutputLoanEstablishmentMain> outputLoanEstablishmentMainList = new ArrayList<OutputLoanEstablishmentMain>();
		ArrayList<LoanEstablishmentMain> loanEstablishList = new ArrayList<LoanEstablishmentMain>();
		List<String> loanIdIdList = new ArrayList<>();
		for (LoanEstablishmentMain inputLoanDetails : inPutDetailsList) {
			
			if ((inputLoanDetails.getStatus() == null) || (inputLoanDetails.getStatus().trim().equals(""))) {
				String payLoad = modelProcessor.generatePayload(inputLoanDetails);
				HashMap<String, String> responseMap = modelProcessor.makeCreateLoanAPICall(payLoad, appConfig);
//				partyIdList.respon

				if ((responseMap != null) && (responseMap.size() > 0)) {
					if (responseMap.get(AppConstants.HTTP_RESPONSE_STATUS_CODE)
							.equals(AppConstants.LOAN_API_SUCCESS_RESPONSE_STATUS_CODE)) {
						String responseStr = responseMap.get(AppConstants.HTTP_RESPONSE_CONTENT);

						ObjectMapper mapper = new ObjectMapper();
						OutputLoanEstablishmentMain outputLoanEstablishmentMain = null;
						try {
							outputLoanEstablishmentMain = mapper.readValue(responseStr, OutputLoanEstablishmentMain.class);
						} catch (Exception e) {
							e.printStackTrace();
						}
						
						outputLoanEstablishmentMainList.add(outputLoanEstablishmentMain);
						loanIdIdList.add(outputLoanEstablishmentMain.getLoanId());
						
						updateLoanDetails(inputLoanDetails, outputLoanEstablishmentMain);
						
						loanEstablishList.add(inputLoanDetails);

					} else {
						String statusCode = responseMap.get(AppConstants.HTTP_RESPONSE_STATUS_CODE);
						logger.warn("Http Status Code: " + statusCode);

						String responseStr = responseMap.get(AppConstants.HTTP_RESPONSE_CONTENT);

						JSONObject jsonRootObject = new JSONObject(responseStr);
						String detail = jsonRootObject.getString("detail");
						int status = jsonRootObject.getInt("status");
						String title = jsonRootObject.getString("title");
						String type = jsonRootObject.getString("type");

						logger.warn("Error - Details: " + detail);
						logger.warn("Error - Status Code: " + status);
						logger.warn("Error - Title: " + title);
						logger.warn("Error - Type: " + type);

						inputLoanDetails.setStatus(AppConstants.STATUS_FAILED);
						inputLoanDetails.setErrorMessage(jsonRootObject.toString());
						loanEstablishList.add(inputLoanDetails);
					}
				} else {
					inputLoanDetails.setStatus(AppConstants.STATUS_FAILED);
					inputLoanDetails.setErrorMessage(AppConstants.API_CALL_FAILED);
					loanEstablishList.add(inputLoanDetails);
				}
			}
		
		}

		modelProcessor.updateExcelDocument(loanEstablishList, outputLoanEstablishmentMainList, appConfig);
		System.out.println("LIST OF Loan------>"+loanIdIdList!=null?loanIdIdList.size():null);
		System.out.println(appConfig.getDirectoryInput() + appConfig.getInputFile());
	}
	public void updateLoanDetails(LoanEstablishmentMain inputLoanDetails, OutputLoanEstablishmentMain outputLoanEstablishmentMain) {
	    inputLoanDetails.setStatus(AppConstants.STATUS_SUCCESS);
	    inputLoanDetails.setErrorMessage("");

	    // Setting the output loan details
	    inputLoanDetails.setOutPutLoanApplicationId(outputLoanEstablishmentMain.getLoanApplicationId());
	    inputLoanDetails.setOutLoanId(outputLoanEstablishmentMain.getLoanId());
	    inputLoanDetails.setOutLoanApplicants(outputLoanEstablishmentMain.getLoanApplicants());
	    inputLoanDetails.setOutProductName(outputLoanEstablishmentMain.getProductName());
	    inputLoanDetails.setOutLoanPurpose(outputLoanEstablishmentMain.getLoanPurpose());
	    inputLoanDetails.setOutPutBranch(outputLoanEstablishmentMain.getLoanAccountBranch());
	    
	    // Loan request amount and currency
	    inputLoanDetails.setOutPutLoanAmount(String.valueOf(outputLoanEstablishmentMain.getLoanRequestAmount().getAmount()));
	    inputLoanDetails.setOutPutCurrency(outputLoanEstablishmentMain.getLoanRequestAmount().getCurrency());
	    
	    // Loan start date and customer contribution amount
	    inputLoanDetails.setOutLoanStartDate(outputLoanEstablishmentMain.getLoanStartDate());
	    inputLoanDetails.setOutCustomerContributionAmount(outputLoanEstablishmentMain.getCustomerContributionAmount());
	    inputLoanDetails.setOutMaturityDate(outputLoanEstablishmentMain.getMaturityDate());
	    inputLoanDetails.setOutRepaymentType(outputLoanEstablishmentMain.getRepaymentType());
	    if (null != outputLoanEstablishmentMain.getOutRepaymentSchedules()) {
	    	inputLoanDetails.setOutPutRepaymentStartDate(outputLoanEstablishmentMain.getOutRepaymentSchedules().get(0).getRepaymentDate());
	    }
	    inputLoanDetails.setOutEffectiveInterestRate(outputLoanEstablishmentMain.getEffectiveInterestRate());
	    //inputLoanDetails.setOutPutRepaymentStartDate(outputLoanEstablishmentMain.getRe);
	    
	}

	public boolean obtainAuthToken() throws AppException {

		boolean isTokenObtained = false;

		HashMap<String, String> responseMap = modelProcessor.makeSSORequest(appConfig);

		if ((responseMap != null) && (responseMap.size() > 0)) {
			if (responseMap.get(AppConstants.HTTP_RESPONSE_STATUS_CODE).equals("200")) {
				String responseStr = responseMap.get(AppConstants.HTTP_RESPONSE_CONTENT);

				JSONObject jsonObject = new JSONObject(responseStr);

				appConfig.setAuthToken(jsonObject.getString("result"));

				isTokenObtained = true;
			} else if (responseMap.get(AppConstants.HTTP_RESPONSE_STATUS_CODE).equals("422")) {
				String responseStr = responseMap.get(AppConstants.HTTP_RESPONSE_CONTENT);

				JSONObject jsonRootObject = new JSONObject(responseStr);
				JSONArray jsonEventArray = jsonRootObject.getJSONArray("events");
				JSONObject jsonObject = (JSONObject) jsonEventArray.get(0);

				String eventNumber = jsonObject.getString("eventNumber");
				String message = jsonObject.getString("message");

				logger.warn("EventNumber: " + eventNumber);
				logger.warn(message);

				throw new AppException(AppConstants.SSO_LOGIN_ERROR);
			} else {
				throw new AppException(AppConstants.SSO_LOGIN_ERROR);
			}
		} else {
			throw new AppException(AppConstants.SSO_LOGIN_ERROR);
		}

		return isTokenObtained;
	}

	public boolean isSSOLogoutImplemented() throws AppException {
		boolean isTokenObtained = false;

		HashMap<String, String> responseMap = modelProcessor.makeSSOLogout(appConfig);

		if ((responseMap != null) && (responseMap.size() > 0)) {
			if (responseMap.get(AppConstants.HTTP_RESPONSE_STATUS_CODE).equals("200")) {
				String responseStr = responseMap.get(AppConstants.HTTP_RESPONSE_CONTENT);
				JSONObject jsonObject = new JSONObject(responseStr);
				String result = jsonObject.getString("result");

				logger.info("Logout status: " + result);
				isTokenObtained = true;
			} else {
				throw new AppException(AppConstants.SSO_LOGOUT_ERROR);
			}
		} else {
			throw new AppException(AppConstants.SSO_LOGOUT_ERROR);
		}

		return isTokenObtained;
	}
}
