package com.finastra.lending;

import java.io.IOException;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.finastra.lending.config.AppConfig;
import com.finastra.lending.controller.AppFrontController;
import com.finastra.lending.data.LoanEstablishmentMain;
import com.finastra.lending.model.ModelProcessor;
import com.finastra.lending.utility.AppConstants;
import com.finastra.lending.utility.AppException;


public class App {
	private static final Logger logger = LoggerFactory.getLogger(App.class);

	public static void main(String[] args) throws AppException, IOException {
		logger.info(AppConstants.APP_CONFIGURATION_MSG);
		AppConfig appConfig = new AppConfig();

		try {
			appConfig.setConfigFilePathExternal(args[0]);
			logger.info(AppConstants.EXTERNAL_CONF_FILE_SUPPLIED);
		} catch (Exception ex) {
			logger.info(AppConstants.EXTERNAL_CONF_FILE_NOT_SUPPLIED);
		}

		initialize(appConfig);
		logger.info(AppConstants.APP_CONFIGURATION_SUCCESSFUL_MSG);

		// Creating and Initializing Front Controller.
		AppFrontController controller = new AppFrontController(appConfig);
	//	ReadAndWriteExcelService readAndWriteExcelService = new ReadAndWriteExcelService();
		//List<Map<String, Object>> obj = readAndWriteExcelService.readExcel(appConfig.getDirectoryInput()+""+appConfig.getInputFile(), "loan-create");

		// SSO Login and Obtain Auth Token.
		if (controller.obtainAuthToken()) {
			logger.info(AppConstants.SSO_LOGIN_MESSAGE);

			try {
				// Push Loan one by one.
				List<LoanEstablishmentMain> inputLoan = controller.readInputFile();
			//	List<LoanEstablishmentMain> inputLoan =new  ModelProcessor().readExcelListData(obj);
				logger.info(AppConstants.INPUT_FILE_READ_SUCCESSFULLY_MSG);
				controller.pushLoanApi(inputLoan);
			} catch (Exception ex) {
				logger.error(AppConstants.LOAN_API_ERROR_MSG);
				logger.error(ex.getStackTrace().toString());
			}

			// Implement SSO Logout.
			if (controller.isSSOLogoutImplemented()) {
				logger.info(AppConstants.SSO_LOGOUT_MESSAGE);
			}
		}
	}

	private static void initialize(AppConfig appConfig) throws AppException {

		try {
			appConfig.loadConfiguration();
		} catch (AppException e) {
			logger.error(e.getLocalizedMessage());
			throw e;
		}
	}

}