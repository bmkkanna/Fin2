package com.finastra.lending.data;

public class PaymentMandateDetails {

   boolean createMandateIdAsLoanId;

   MandateDetails mandateDetails;


    public void setCreateMandateIdAsLoanId(boolean createMandateIdAsLoanId) {
        this.createMandateIdAsLoanId = createMandateIdAsLoanId;
    }
    public boolean getCreateMandateIdAsLoanId() {
        return createMandateIdAsLoanId;
    }
    
    public void setMandateDetails(MandateDetails mandateDetails) {
        this.mandateDetails = mandateDetails;
    }
    public MandateDetails getMandateDetails() {
        return mandateDetails;
    }
    
}