package com.finastra.lending.data;

   
public class Custom_fields {


}