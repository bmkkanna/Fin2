package com.finastra.lending.data;

public class AdhocChargeDetails {

   ChargeAmount chargeAmount;

   String chargeDescription;


    public void setChargeAmount(ChargeAmount chargeAmount) {
        this.chargeAmount = chargeAmount;
    }
    public ChargeAmount getChargeAmount() {
        return chargeAmount;
    }
    
    public void setChargeDescription(String chargeDescription) {
        this.chargeDescription = chargeDescription;
    }
    public String getChargeDescription() {
        return chargeDescription;
    }
    
}