package com.finastra.lending.data;

import java.util.Date;

   
public class DisbursementScheduleRequest {

   DisbursementAmount disbursementAmount;

   String disbursementBeneficiaryAccount;

   String disbursementBeneficiaryId;

   String disbursementDate;

   String disbursementType;


    public void setDisbursementAmount(DisbursementAmount disbursementAmount) {
        this.disbursementAmount = disbursementAmount;
    }
    public DisbursementAmount getDisbursementAmount() {
        return disbursementAmount;
    }
    
    public void setDisbursementBeneficiaryAccount(String disbursementBeneficiaryAccount) {
        this.disbursementBeneficiaryAccount = disbursementBeneficiaryAccount;
    }
    public String getDisbursementBeneficiaryAccount() {
        return disbursementBeneficiaryAccount;
    }
    
    public void setDisbursementBeneficiaryId(String disbursementBeneficiaryId) {
        this.disbursementBeneficiaryId = disbursementBeneficiaryId;
    }
    public String getDisbursementBeneficiaryId() {
        return disbursementBeneficiaryId;
    }
    
    public void setDisbursementDate(String disbursementDate) {
        this.disbursementDate = disbursementDate;
    }
    public String getDisbursementDate() {
        return disbursementDate;
    }
    
    public void setDisbursementType(String disbursementType) {
        this.disbursementType = disbursementType;
    }
    public String getDisbursementType() {
        return disbursementType;
    }
    
}