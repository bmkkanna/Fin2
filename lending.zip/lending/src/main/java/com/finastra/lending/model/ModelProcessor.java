package com.finastra.lending.model;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.DateUtil;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.finastra.lending.config.AppConfig;
import com.finastra.lending.data.AdhocLoanEstablishmentCharges;
import com.finastra.lending.data.AssignmentDetails;
import com.finastra.lending.data.BalloonPaymentAmount;
import com.finastra.lending.data.CollateralDetails;
import com.finastra.lending.data.Custom_fields;
import com.finastra.lending.data.CustomerContributionAmount;
import com.finastra.lending.data.DisbursementAmount;
import com.finastra.lending.data.DisbursementScheduleRequest;
import com.finastra.lending.data.EventCharges;
import com.finastra.lending.data.FixedAssignment;
import com.finastra.lending.data.InterestDetails;
import com.finastra.lending.data.LoanAgreementDetails;
import com.finastra.lending.data.LoanApplicantIds;
import com.finastra.lending.data.LoanEstablishmentMain;
import com.finastra.lending.data.LoanRequestAmount;
import com.finastra.lending.data.LoanTerm;
import com.finastra.lending.data.OutputLoanEstablishmentMain;
import com.finastra.lending.data.PaymentMandateDetails;
import com.finastra.lending.data.PeggingResetDetails;
import com.finastra.lending.data.ProgressiveRateDetails;
import com.finastra.lending.data.RequestSSOLogin;
import com.finastra.lending.utility.AppConstants;
import com.finastra.lending.utility.AppHttpClient;

public class ModelProcessor {

	private static final Logger logger = LoggerFactory.getLogger(ModelProcessor.class);

	AppHttpClient httpClient = null;

	public ModelProcessor() {
		super();
		this.httpClient = new AppHttpClient();
	}

	public File obtainInputFileObject(AppConfig appConfig) {
		File file = new File(appConfig.getDirectoryInput() + appConfig.getInputFile());

		return file;
	}

	public List<LoanEstablishmentMain> readInputFileAndUpdatePOJO(File inputFile, AppConfig appConfig) {
		List<LoanEstablishmentMain> inputLoanEstablishmentMainList = new ArrayList<LoanEstablishmentMain>();

		// obtaining bytes from the file
		FileInputStream fis;
		try {
			fis = new FileInputStream(inputFile);

			// creating Workbook instance that refers to .xlsx file
			XSSFWorkbook wb = new XSSFWorkbook(fis);

			// creating a Sheet object to retrieve object
			XSSFSheet sheet = wb.getSheet(appConfig.getInputSheet());

			// number of rows of newly form excel files
			// int rowCount = sheet.getPhysicalNumberOfRows();
			// logger.info("Total number of rows in the Excel Sheet: " + (rowCount - 1));
			boolean b = false;
			boolean boolen = true;
			Iterator<Row> rowIterator = sheet.iterator();

			while (rowIterator.hasNext()) {

				Row row = rowIterator.next();
				Iterator<Cell> cellIterator = row.cellIterator();
				// DisbursementAmount disbursementAmount = new DisbursementAmount();
				// DisbursementScheduleRequest disbursementScheduleRequest = new
				// DisbursementScheduleRequest();

				LoanEstablishmentMain loanEstablishmentMain = new LoanEstablishmentMain();
				loanEstablishmentMain.setRownum(row.getRowNum());
				ProgressiveRateDetails progressiveRateDetails = new ProgressiveRateDetails();

				List<AdhocLoanEstablishmentCharges> adhocLoanEstablishmentCharges = new ArrayList<>();

				// BalloonPaymentAmount balloonPaymentAmount = new BalloonPaymentAmount();

				CollateralDetails collateralDetails = new CollateralDetails();

				Custom_fields custom_fields = new Custom_fields();

				List<DisbursementScheduleRequest> disbursementScheduleRequestList = new ArrayList<>();

				DisbursementScheduleRequest disbursementScheduleRequest = new DisbursementScheduleRequest();
				DisbursementAmount disbursementAmount = new DisbursementAmount();

				List<EventCharges> eventCharges = new ArrayList<>();

				LoanAgreementDetails loanAgreementDetails = new LoanAgreementDetails();

				List<LoanApplicantIds> loanApplicantIdsList = new ArrayList<>();

				PaymentMandateDetails paymentMandateDetails = new PaymentMandateDetails();
				// DisbursementAmount disbursementAmount = new DisbursementAmount();

				PeggingResetDetails peggingResetDetails = new PeggingResetDetails();

				CustomerContributionAmount customerContributionAmount = new CustomerContributionAmount();
				LoanApplicantIds loanApplicantIds = new LoanApplicantIds();

				LoanRequestAmount loanRequestAmount = new LoanRequestAmount();
				LoanTerm loanTerm = new LoanTerm();

				AssignmentDetails assignmentDetails = new AssignmentDetails();
				List<AssignmentDetails> assignmentDetailsList = new ArrayList<>();
				InterestDetails interestDetails = new InterestDetails();
				FixedAssignment fixedAssignment = new FixedAssignment();

				while (cellIterator.hasNext()) {

					Cell cell = cellIterator.next();
					DataFormatter formatter = new DataFormatter();
					// DataFormatter formatter = new DataFormatter();

					// System.out.println(cell +"----------
					// "+cell.getColumnIndex()+"-----"+cell.getStringCellValue());
					if (cell.getColumnIndex() == 4) { // to read the first column
						String cellValue = (cell.getCellType() == CellType.STRING) ? cell.getStringCellValue()
								: String.valueOf(cell.getNumericCellValue());
						customerContributionAmount.setAmount(cellValue);
					} else if (cell.getColumnIndex() == 8) {
						/*
						 * String cellValue = (cell.getCellType() == CellType.STRING) ?
						 * cell.getStringCellValue() : String.valueOf(
						 * Integer.valueOf((int)cell.getNumericCellValue()));
						 * System.out.println(cellValue+"hlfdgsdglshglsh");
						 */
						loanTerm.setValue(formatter.formatCellValue(cell));

					} else if (cell.getColumnIndex() == 5) {
						String cellValue = (cell.getCellType() == CellType.STRING) ? cell.getStringCellValue()
								: String.valueOf(cell.getNumericCellValue());
						customerContributionAmount.setCurrency(cellValue);
					} else if (cell.getColumnIndex() == 17) {
						loanEstablishmentMain.setFeeCollectionAccount(cell.getStringCellValue());
					} /*
						 * else if (cell.getColumnIndex() == 3) {
						 * loanEstablishmentMain.setKycCheckRequired(cell.getStringCellValue()); }
						 */else if (cell.getColumnIndex() == 0) {
						loanApplicantIds.setCustomerId(getCellValue(cell));
					} else if (cell.getColumnIndex() == 2) {
						loanRequestAmount.setAmount(getCellValue(cell));

					} else if (cell.getColumnIndex() == 3) {
						loanRequestAmount.setCurrency(getCellValue(cell));

					} else if (cell.getColumnIndex() == 6) {
						// loanEstablishmentMain.setLoanStartDate(getCellValue(cell));
						loanEstablishmentMain.setLoanStartDate((String) getCellValue(cell));

					} /*
						 * else if (cell.getColumnIndex() == 8) { String cellValue = (cell.getCellType()
						 * == CellType.STRING) ? cell.getStringCellValue() :
						 * String.valueOf(cell.getNumericCellValue());
						 * loanEstablishmentMain.setLoanTaxFundingAccount(cellValue);
						 * 
						 * }
						 */else if (cell.getColumnIndex() == 7) {
						loanTerm.setCalendarPeriod((String) getCellValue(cell));

					} /*
						 * else if (cell.getColumnIndex() == 8) {
						 * loanTerm.setValue(cell.getStringCellValue());
						 * 
						 * }
						 */ else if (cell.getColumnIndex() == 9) {
						loanEstablishmentMain.setMaturityDateCalculation(getCellValue(cell));
					} else if (cell.getColumnIndex() == 10) {
						interestDetails.setRateType(cell.getStringCellValue());

					} else if (cell.getColumnIndex() == 11) {

						progressiveRateDetails.setPostProgressiveRateType(cell.getStringCellValue());

					}

					else if (cell.getColumnIndex() == 12) {

						peggingResetDetails.setResetDate((String) getCellValue(cell));
					}

					else if (cell.getColumnIndex() == 13) {

						peggingResetDetails.setResetFrequency(cell.getStringCellValue());

					} else if (cell.getColumnIndex() == 14) {
						String cellValue = (cell.getCellType() == CellType.STRING) ? cell.getStringCellValue()
								: String.valueOf(cell.getNumericCellValue());
						loanEstablishmentMain.setCustomerInterestMargin(cellValue);

					}

					else if (cell.getColumnIndex() == 15) {
						String morType = cell.getStringCellValue();
						String value = morType.isEmpty() ? null : morType;
						loanEstablishmentMain.setMoratoriumType(value);

					} else if (cell.getColumnIndex() == 1) {
						loanEstablishmentMain.setProductCode(cell.getStringCellValue());

					} else if (cell.getColumnIndex() == 19) {
						loanEstablishmentMain.setRepaymentAccount(cell.getStringCellValue());

					} else if (cell.getColumnIndex() == 20) {
						// loanEstablishmentMain.setRepaymentFrequency(getCellValue(cell));
						loanEstablishmentMain.setRepaymentFrequency((String) getCellValue(cell));

					} else if (cell.getColumnIndex() == 21) {
						// loanEstablishmentMain.setRepaymentStartDate(getCellValue(cell));
						loanEstablishmentMain.setRepaymentStartDate((String) getCellValue(cell));
					} else if (cell.getColumnIndex() == 17) {
						loanEstablishmentMain.setRetentionPeriod(getCellValue(cell));
					} else if (cell.getColumnIndex() == 18) {
						loanEstablishmentMain.setSettlementType(cell.getStringCellValue());
					} else if (cell.getColumnIndex() == 19) {
						loanEstablishmentMain.setWaiveCharge(cell.getStringCellValue());
					} else if (cell.getColumnIndex() == 22) {
						String cellValue = (cell.getCellType() == CellType.STRING) ? cell.getStringCellValue()
								: String.valueOf(cell.getNumericCellValue());
						disbursementAmount.setAmount(cellValue);
					} else if (cell.getColumnIndex() == 23) {
						disbursementAmount.setCurrency(cell.getStringCellValue());
						;
					} else if (cell.getColumnIndex() == 24) {
						disbursementScheduleRequest.setDisbursementType(cell.getStringCellValue());
					} else if (cell.getColumnIndex() == 25) {
						disbursementScheduleRequest.setDisbursementBeneficiaryAccount(cell.getStringCellValue());
					} else if (cell.getColumnIndex() == 26) {
						// System.out.println("roxc"+(String) getCellValue(cell));
						disbursementScheduleRequest.setDisbursementDate((String) getCellValue(cell));
					} else if (cell.getColumnIndex() == 28) {
						assignmentDetails.setAssignmentValueCalculation(cell.getStringCellValue());
					} else if (cell.getColumnIndex() == 27) {
						assignmentDetails.setCollateralId(cell.getStringCellValue());
						;
					} else if (cell.getColumnIndex() == 29) {
						String cellValue = (cell.getCellType() == CellType.STRING) ? cell.getStringCellValue()
								: String.valueOf(cell.getNumericCellValue());
						String temp = cellValue.isEmpty()?null:cellValue;
						assignmentDetails.setPercentageAssignment(cellValue);
					}
					else if (cell.getColumnIndex() == 30) {
						
						fixedAssignment.setAmount(formatter.formatCellValue(cell));
						

					} else if (cell.getColumnIndex() == 31) {
						
						fixedAssignment.setCurrency(formatter.formatCellValue(cell));

					} else if (cell.getColumnIndex() == 32) {
						
						collateralDetails.setWaiveCharge(Boolean.parseBoolean(formatter.formatCellValue(cell)));

					} 
					
					else if (cell.getColumnIndex() == 33) {
						loanEstablishmentMain.setCommitmentId(cell.getStringCellValue());
					}
					else if (cell.getColumnIndex() == 34) {
						loanEstablishmentMain.setStatus(cell.getStringCellValue());
					} else if (cell.getColumnIndex() == 35) {
						loanEstablishmentMain.setErrorMessage(cell.getStringCellValue());
					} 
					
					

				}

				loanEstablishmentMain.setMandateReference("");
				

				if (progressiveRateDetails.getPostProgressiveRateType() == null
						|| progressiveRateDetails.getPostProgressiveRateType().isEmpty()) {
					progressiveRateDetails = null;
					interestDetails.setProgressiveRateDetails(progressiveRateDetails);
				} else {
					// Otherwise, add the original assignment to the list
					interestDetails.setProgressiveRateDetails(progressiveRateDetails);

					// collateralDetails.setAssignmentDetails(assignmentDetailsList);

				}

				if (peggingResetDetails.getResetDate() == null || peggingResetDetails.getResetDate().isEmpty()) {
					peggingResetDetails = null;
					interestDetails.setPeggingResetDetails(peggingResetDetails);
				} else {
					// Otherwise, add the original assignment to the list
					interestDetails.setPeggingResetDetails(peggingResetDetails);

					// collateralDetails.setAssignmentDetails(assignmentDetailsList);

				}
				if (fixedAssignment.getAmount()!=null && !fixedAssignment.getAmount().isEmpty()) {
					assignmentDetails.setFixedAssignment(fixedAssignment);
				}
				if (assignmentDetails.getAssignmentValueCalculation() == null
						|| assignmentDetails.getAssignmentValueCalculation().isEmpty()) {
					collateralDetails = null;
				} else {
					// Otherwise, add the original assignment to the list
					assignmentDetailsList.add(assignmentDetails);

					collateralDetails.setAssignmentDetails(assignmentDetailsList);

				}
				

				loanEstablishmentMain.setInterestDetails(interestDetails);
				disbursementScheduleRequest.setDisbursementAmount(disbursementAmount);
				// balloonPaymentAmount.setCurrency("");
				loanApplicantIdsList.add(loanApplicantIds);
				disbursementScheduleRequestList.add(disbursementScheduleRequest);
				loanEstablishmentMain.setAdhocLoanEstablishmentCharges(adhocLoanEstablishmentCharges);
				// loanEstablishmentMain.setBalloonPaymentAmount(balloonPaymentAmount);
				loanEstablishmentMain.setCollateralDetails(collateralDetails);
				loanEstablishmentMain.setCustom_fields(custom_fields);
				loanEstablishmentMain.setCustomerContributionAmount(customerContributionAmount);
				loanEstablishmentMain.setLoanApplicantIds(loanApplicantIdsList);
				loanEstablishmentMain.setDisbursementScheduleRequest(disbursementScheduleRequestList);
				loanEstablishmentMain.setCustomerContributionAmount(customerContributionAmount);
				loanEstablishmentMain.setEventCharges(eventCharges);
				// loanEstablishmentMain.setLoanAgreementDetails(loanAgreementDetails);
				// loanEstablishmentMain.setPaymentMandateDetails(paymentMandateDetails);
				loanEstablishmentMain.setLoanRequestAmount(loanRequestAmount);
				loanEstablishmentMain.setLoanTerm(loanTerm);
				inputLoanEstablishmentMainList.add(loanEstablishmentMain);
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		// Removing Excel file Header from Collection.
		if (inputLoanEstablishmentMainList.size() > 0) {
			inputLoanEstablishmentMainList.remove(0);
		}
		inputLoanEstablishmentMainList.removeIf(loan -> "SUCESS".equals(loan.getStatus()));
		return inputLoanEstablishmentMainList;
	}

	public List<LoanEstablishmentMain> readExcelListData(List<Map<String, Object>> loanApplications) {
		List<LoanEstablishmentMain> inputLoanEstablishmentMainList = new ArrayList<LoanEstablishmentMain>();
		try {
			int i = 0;

			for (Map<String, Object> loanData : loanApplications) {

				System.out.println("Processing Loan Application:");
				LoanEstablishmentMain loanEstablishmentMain = new LoanEstablishmentMain();
				loanEstablishmentMain.setRownum(i++);

				List<AdhocLoanEstablishmentCharges> adhocLoanEstablishmentCharges = new ArrayList<>();

				// BalloonPaymentAmount balloonPaymentAmount = new BalloonPaymentAmount();

				CollateralDetails collateralDetails = new CollateralDetails();

				Custom_fields custom_fields = new Custom_fields();

				List<DisbursementScheduleRequest> disbursementScheduleRequest = new ArrayList<>();

				List<EventCharges> eventCharges = new ArrayList<>();

				LoanAgreementDetails loanAgreementDetails = new LoanAgreementDetails();

				List<LoanApplicantIds> loanApplicantIdsList = new ArrayList<>();

				PaymentMandateDetails paymentMandateDetails = new PaymentMandateDetails();

				CustomerContributionAmount customerContributionAmount = new CustomerContributionAmount();
				LoanApplicantIds loanApplicantIds = new LoanApplicantIds();

				LoanRequestAmount loanRequestAmount = new LoanRequestAmount();
				LoanTerm loanTerm = new LoanTerm();

				// Retrieve each field value using loanData.get("key") and store it in variables

				String customerContributionAmount1 = (String) loanData.get("Customer_Contribution_Amount").toString();
				customerContributionAmount.setAmount(customerContributionAmount1);
				String customerContributionCurrency = (String) loanData.get("Customer_Contribution_Currency")
						.toString();
				customerContributionAmount.setCurrency(customerContributionCurrency);
				String feeCollectionAccount = (String) loanData.get("Fee_Collection_Account").toString();
				loanEstablishmentMain.setFeeCollectionAccount(feeCollectionAccount);

				String kycCheckRequired = loanData.get("Kyc_Check_Required").toString();
				loanEstablishmentMain.setKycCheckRequired(kycCheckRequired);

				String customerId = (String) loanData.get("Customer_Id").toString();
				loanApplicantIds.setCustomerId(customerId);

				String loanRequestAmount1 = (String) loanData.get("Loan_Request_Amount").toString();
				loanRequestAmount.setAmount(loanRequestAmount1);

				String loanRequestCurrency = (String) loanData.get("Loan_Request_Currency").toString();
				loanRequestAmount.setCurrency(loanRequestCurrency);

				String loanStartDate = (String) loanData.get("Loan_Start_Date").toString();
				loanEstablishmentMain.setLoanStartDate(loanStartDate);

				String loanTaxFundingAccount = (String) loanData.get("Loan_Tax_Funding_Account").toString();
				loanEstablishmentMain.setLoanTaxFundingAccount(loanTaxFundingAccount);

				String termCalendarPeriod = (String) loanData.get("Term_Calendar_Period").toString();
				loanTerm.setCalendarPeriod(termCalendarPeriod);

				String termValue = (String) loanData.get("Term_Value").toString();
				loanTerm.setValue(termValue);

				String maturityDateCalculation = (String) loanData.get("Maturity_Date_Calculation").toString();
				loanEstablishmentMain.setMaturityDateCalculation(maturityDateCalculation);

				String moratoriumType = (String) loanData.get("Moratorium_Type").toString();
				loanEstablishmentMain.setMoratoriumType(moratoriumType);

				String productCode = (String) loanData.get("Product_Code").toString();
				loanEstablishmentMain.setProductCode(productCode);

				String repaymentAccount = (String) loanData.get("Repayment_Account").toString();
				loanEstablishmentMain.setRepaymentAccount(repaymentAccount);

				String repaymentFrequency = (String) loanData.get("Repaymnet_Frequency").toString();
				loanEstablishmentMain.setRepaymentFrequency(repaymentFrequency);

				String repaymentStartDate = (String) loanData.get("Repayment_Start_Date").toString();

				loanEstablishmentMain.setRepaymentStartDate(repaymentStartDate);

				String retentionPeriod = (String) loanData.get("Retention_Period").toString();

				loanEstablishmentMain.setRetentionPeriod(retentionPeriod);

				String settlementType = (String) loanData.get("Settlement_Type").toString();
				loanEstablishmentMain.setSettlementType(settlementType);
				String waiveCharge = (String) loanData.get("Waive_Charge").toString();
				;
				loanEstablishmentMain.setWaiveCharge(waiveCharge);

				String status = (String) loanData.get("status").toString();
				String errorMessage = (String) loanData.get("errorMessage").toString();
				String loanId = (String) loanData.get("LoanId").toString();
				String loanApplicationId = (String) loanData.get("LoanApplicationId").toString();
				String loanPurpose = (String) loanData.get("LoanPurpose").toString();
				/*
				 * double loanRequestAmountValue = (Double) loanData.get("LoanRequestAmount");
				 * String currency = (String) loanData.get("Currency").toString(); double
				 * customerContributionAmountValue = (Double)
				 * loanData.get("CustomerContributionAmount");
				 */

				loanEstablishmentMain.setMandateReference("");
				// balloonPaymentAmount.setCurrency("");
				loanApplicantIdsList.add(loanApplicantIds);
				loanEstablishmentMain.setAdhocLoanEstablishmentCharges(adhocLoanEstablishmentCharges);
				// loanEstablishmentMain.setBalloonPaymentAmount(balloonPaymentAmount);
				loanEstablishmentMain.setCollateralDetails(collateralDetails);
				loanEstablishmentMain.setCustom_fields(custom_fields);
				loanEstablishmentMain.setCustomerContributionAmount(customerContributionAmount);
				loanEstablishmentMain.setLoanApplicantIds(loanApplicantIdsList);
				loanEstablishmentMain.setDisbursementScheduleRequest(disbursementScheduleRequest);
				loanEstablishmentMain.setCustomerContributionAmount(customerContributionAmount);
				loanEstablishmentMain.setEventCharges(eventCharges);
				// loanEstablishmentMain.setLoanAgreementDetails(loanAgreementDetails);
				// loanEstablishmentMain.setPaymentMandateDetails(paymentMandateDetails);
				loanEstablishmentMain.setLoanRequestAmount(loanRequestAmount);
				loanEstablishmentMain.setLoanTerm(loanTerm);
				inputLoanEstablishmentMainList.add(loanEstablishmentMain);

			}
		} catch (Exception e) {
			// TODO: handle exception
			System.out.println("");
		}

		// inputPartyList.removeIf(acc -> "SUCESS".equals(acc.getStatus()));
		return inputLoanEstablishmentMainList;
	}

	public String generatePayload(LoanEstablishmentMain loanDetails) {

		ObjectMapper objectMapper = new ObjectMapper();
		String payload = "";
		objectMapper.configure(SerializationFeature.FAIL_ON_EMPTY_BEANS, false);

		try {
			payload = objectMapper.writeValueAsString(loanDetails);
		} catch (Exception e) {
			e.printStackTrace();
		}

		return payload;
	}

	public HashMap<String, String> makeSSORequest(AppConfig appConfig) {

		// Payload Preparation.
		String payLoad = "";
		RequestSSOLogin reqSSOLogin = new RequestSSOLogin();
		reqSSOLogin.setUserName(appConfig.getUsername());
		reqSSOLogin.setPassword(appConfig.getPassword());
		ObjectMapper objectMapper = new ObjectMapper();
		try {
			payLoad = objectMapper.writeValueAsString(reqSSOLogin);
		} catch (Exception e) {
			e.printStackTrace();
		}

		// Input Params.
		HashMap<String, String> paramMap = null;

		// Prepare url.
		String url = appConfig.getAppBaseUrl() + AppConstants.SSO_LOGIN_URL;

		// Call rest web-service.
		logger.debug("+++++++++ Implementing SSO Login +++++++++++++");
		logger.debug("URL: " + url);
		logger.debug("Payload: " + payLoad);

		HashMap<String, String> responseMap = httpClient.executePostRequest(url, paramMap, payLoad);

		logger.debug("Response Code: " + responseMap.get(AppConstants.HTTP_RESPONSE_STATUS_CODE));
		logger.debug("Response Content: " + responseMap.get(AppConstants.HTTP_RESPONSE_CONTENT));
		logger.debug("++++++++++ SSO Login part completed +++++++++++++++");

		return responseMap;
	}

	public HashMap<String, String> makeSSOLogout(AppConfig appConfig) {

		// Payload Preparation.
		JSONObject jsonObject = new JSONObject();
		jsonObject.put("userLocator", appConfig.getAuthToken());
		String payLoad = jsonObject.toString();

		// Input Params.
		HashMap<String, String> paramMap = null;

		// Prepare url.
		String url = appConfig.getAppBaseUrl() + AppConstants.SSO_LOGOUT_URL;

		// Call rest web-service.
		logger.debug("+++++++++ Implementing SSO Logout +++++++++++++");
		logger.debug("URL: " + url);
		logger.debug("Payload: " + payLoad);

		HashMap<String, String> responseMap = httpClient.executePostRequest(url, paramMap, payLoad);

		logger.debug("Response Code: " + responseMap.get(AppConstants.HTTP_RESPONSE_STATUS_CODE));
		logger.debug("Response Content: " + responseMap.get(AppConstants.HTTP_RESPONSE_CONTENT));
		logger.debug("++++++++++ SSO Logout part completed +++++++++++++++");

		return responseMap;
	}

	public HashMap<String, String> makeCreateLoanAPICall(String payLoad, AppConfig appConfig) {

		// Input params.
		HashMap<String, String> paramMap = new HashMap<String, String>();
		paramMap.put(AppConstants.AUTHORIZATION_PARAM, appConfig.getAuthToken());
		paramMap.put(AppConstants.X_REQUEST_ID_PARAM, UUID.randomUUID().toString());
		paramMap.put(AppConstants.IDEMPOTENCY_KEY_PARAM, UUID.randomUUID().toString());

		// Prepare URL.
		String url = appConfig.getAppBaseUrl() + AppConstants.CREATE_LOAN_API_URL;

		// Call rest web-service.
		logger.debug("+++++++++ Implementing Loan Create API Call +++++++++++++");
		logger.debug("URL: " + url);
		logger.debug("Payload: " + payLoad);

		HashMap<String, String> responseMap = httpClient.executePostRequest(url, paramMap, payLoad);

		logger.debug("Response Code: " + responseMap.get(AppConstants.HTTP_RESPONSE_STATUS_CODE));
		logger.debug("Response Content: " + responseMap.get(AppConstants.HTTP_RESPONSE_CONTENT));
		logger.debug("++++++++++ Loan Create API Call completed +++++++++++++++");

		return responseMap;
	}

	public File checkAndCreateExcelFileIfNotExist(AppConfig appConfig) {

		File outputFile = new File(appConfig.getDirectoryOutput() + appConfig.getOutputFile());

		FileInputStream fis = null;

		// Workbook object
		XSSFWorkbook workbook = null;

		if (outputFile.exists()) {
			try {
				fis = new FileInputStream(outputFile);
				workbook = new XSSFWorkbook(fis);
			} catch (Exception e1) {
				e1.printStackTrace();
			}
		}

		FileOutputStream out = null;
		if (!outputFile.exists()) {
			try {
				logger.debug(AppConstants.OUTPUT_EXCEL_FILE_NOT_EXIST);
				out = new FileOutputStream(outputFile);

				workbook = new XSSFWorkbook();

				// Spreadsheet object
				XSSFSheet spreadsheet = workbook.createSheet(appConfig.getOutputSheet());
				createHeaderRow(spreadsheet);

				workbook.write(out);
				out.close();

				logger.debug(AppConstants.OUTPUT_EXCEL_FILE_CREATED_MSG);
				logger.debug(AppConstants.OUTPUT_EXCEL_SHEET_CREATED_MSG);
			} catch (Exception e) {
				e.printStackTrace();
			}
		} else {
			logger.debug(AppConstants.OUTPUT_EXCEL_FILE_EXISTS);

			// Check Spreadsheet exists or not in Excel file.
			if (workbook.getNumberOfSheets() != 0) {
				boolean isSpreadSheetExist = false;
				for (int i = 0; i < workbook.getNumberOfSheets(); i++) {
					if (workbook.getSheetName(i).equals(appConfig.getOutputSheet())) {
						isSpreadSheetExist = true;
						break;
					}
				}

				if (isSpreadSheetExist) {
					logger.debug(AppConstants.OUTPUT_EXCEL_SHEET_EXISTS);
				} else {
					// Create new sheet to the workbook
					logger.debug(AppConstants.OUTPUT_EXCEL_SHEET_NOT_EXIST);
					XSSFSheet spreadsheet = workbook.createSheet(appConfig.getOutputSheet());
					createHeaderRow(spreadsheet);

					try {
						out = new FileOutputStream(outputFile);
						workbook.write(out);
						out.close();
					} catch (Exception ex) {
						ex.printStackTrace();
					}

					logger.debug(AppConstants.OUTPUT_EXCEL_SHEET_CREATED_MSG);
				}
			} else {
				// Create new sheet to the workbook if empty
				logger.debug(AppConstants.OUTPUT_EXCEL_SHEET_NOT_EXIST);
				XSSFSheet spreadsheet = workbook.createSheet(appConfig.getOutputSheet());
				createHeaderRow(spreadsheet);

				try {
					out = new FileOutputStream(outputFile);
					workbook.write(out);
					out.close();
				} catch (Exception ex) {
					ex.printStackTrace();
				}

				logger.debug(AppConstants.OUTPUT_EXCEL_SHEET_CREATED_MSG);
			}

		}

		return outputFile;
	}

	private void createHeaderRow(XSSFSheet spreadsheet) {
		// Getting last row number.
		int lastRow = -1;

		Row row = spreadsheet.createRow(++lastRow);
		//row.createCell(0).setCellValue("PartyId");	

	}

	public void appendDataToFile(LoanEstablishmentMain loanEstablish, File outputFile, AppConfig appConfig) {
		try {
			FileInputStream fis = new FileInputStream(outputFile);

			// Workbook object
			XSSFWorkbook workbook = new XSSFWorkbook(fis);

			// Spreadsheet object
			XSSFSheet spreadSheet = workbook.getSheet(appConfig.getOutputSheet());

			// Getting last row number.
			int lastRow = spreadSheet.getLastRowNum();

			Row row = spreadSheet.createRow(++lastRow);
			// row.createCell(0).setCellValue(outPutEnterprisParty.getPartyId());
			fis.close();

			FileOutputStream fos = new FileOutputStream(outputFile);

			// Write changes
			workbook.write(fos);

			// Closing Output Stream.
			fos.close();

		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}

	public void updateExcelDocument(ArrayList<LoanEstablishmentMain> loanEstablishmentMain,
			ArrayList<OutputLoanEstablishmentMain> outputLoanEstablishmentMain, AppConfig appConfig) {

		// Update Output Excel Sheet.
		// Verify if file exists or not. If it does not exist then create one.
		File outputFile = checkAndCreateOutputExcelFileIfNotExist(appConfig);

		if (outputLoanEstablishmentMain.size() > 0) {
			logger.info(AppConstants.PROCESSING_OUTPUT_EXCEL_SHEET);

			// Append Data to output excel file.
			// for (OutPutEnterprisParty outputParty : outputEnterprisPartys) {
			// appendDataToOutputFile(outputParty, outputFile, appConfig);
			// }
		}

		// Update Input Excel sheet.
		if (loanEstablishmentMain.size() > 0) {
			logger.info(AppConstants.PROCESSING_INPUT_EXCEL_SHEET);

			// Append Data to input excel file.
			for (LoanEstablishmentMain inputLoanEstablish : loanEstablishmentMain) {
				appendDataToInputFile(inputLoanEstablish, appConfig);
			}
		}
	}

	public File checkAndCreateOutputExcelFileIfNotExist(AppConfig appConfig) {

		File outputFile = new File(appConfig.getDirectoryOutput() + appConfig.getOutputFile());

		FileInputStream fis = null;

		// Workbook object
		XSSFWorkbook workbook = null;

		if (outputFile.exists()) {
			try {
				fis = new FileInputStream(outputFile);
				workbook = new XSSFWorkbook(fis);
			} catch (Exception e1) {
				e1.printStackTrace();
			}
		}

		FileOutputStream out = null;
		if (!outputFile.exists()) {
			try {
				logger.debug(AppConstants.OUTPUT_EXCEL_FILE_NOT_EXIST);
				out = new FileOutputStream(outputFile);

				workbook = new XSSFWorkbook();

				// Spreadsheet object
				XSSFSheet spreadsheet = workbook.createSheet(appConfig.getOutputSheet());
				createHeaderRow(spreadsheet);

				workbook.write(out);
				out.close();

				logger.debug(AppConstants.OUTPUT_EXCEL_FILE_CREATED_MSG);
				logger.debug(AppConstants.OUTPUT_EXCEL_SHEET_CREATED_MSG);
			} catch (Exception e) {
				e.printStackTrace();
			}
		} else {
			logger.debug(AppConstants.OUTPUT_EXCEL_FILE_EXISTS);

			// Check Spreadsheet exists or not in Excel file.
			if (workbook.getNumberOfSheets() != 0) {
				boolean isSpreadSheetExist = false;
				for (int i = 0; i < workbook.getNumberOfSheets(); i++) {
					if (workbook.getSheetName(i).equals(appConfig.getOutputSheet())) {
						isSpreadSheetExist = true;
						break;
					}
				}

				if (isSpreadSheetExist) {
					logger.debug(AppConstants.OUTPUT_EXCEL_SHEET_EXISTS);
				} else {
					// Create new sheet to the workbook
					logger.debug(AppConstants.OUTPUT_EXCEL_SHEET_NOT_EXIST);
					XSSFSheet spreadsheet = workbook.createSheet(appConfig.getOutputSheet());
					createHeaderRow(spreadsheet);

					try {
						out = new FileOutputStream(outputFile);
						workbook.write(out);
						out.close();
					} catch (Exception ex) {
						ex.printStackTrace();
					}

					logger.debug(AppConstants.OUTPUT_EXCEL_SHEET_CREATED_MSG);
				}
			} else {
				// Create new sheet to the workbook if empty
				logger.debug(AppConstants.OUTPUT_EXCEL_SHEET_NOT_EXIST);
				XSSFSheet spreadsheet = workbook.createSheet(appConfig.getOutputSheet());
				createHeaderRow(spreadsheet);

				try {
					out = new FileOutputStream(outputFile);
					workbook.write(out);
					out.close();
				} catch (Exception ex) {
					ex.printStackTrace();
				}

				logger.debug(AppConstants.OUTPUT_EXCEL_SHEET_CREATED_MSG);
			}

		}

		return outputFile;
	}

	public void appendDataToOutputFile(LoanEstablishmentMain loanEstablish, File outputFile,
			AppConfig appConfig) {
		try {
			FileInputStream fis = new FileInputStream(outputFile);

			// Workbook object
			XSSFWorkbook workbook = new XSSFWorkbook(fis);

			// Spreadsheet object
			XSSFSheet spreadSheet = workbook.getSheet(appConfig.getOutputSheet());

			// Getting last row number.
			int lastRow = spreadSheet.getLastRowNum();

			Row row = spreadSheet.createRow(++lastRow);
			/*
			 * row.createCell(0).setCellValue(outPutEnterprisParty.getPartyId());
			 */

			// Closing Input Stream.
			fis.close();

			FileOutputStream fos = new FileOutputStream(outputFile);

			// Write changes
			workbook.write(fos);

			// Closing Output Stream.
			fos.close();

		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}

	public void appendDataToInputFile(LoanEstablishmentMain loanEstatblish, AppConfig appConfig) {

		try {
			File inputFile = new File(appConfig.getDirectoryInput() + appConfig.getInputFile());

			FileInputStream fis = new FileInputStream(inputFile);

			// creating Workbook instance that refers to .xlsx file
			XSSFWorkbook workbook = new XSSFWorkbook(fis);

			// creating a Sheet object to retrieve object
			XSSFSheet sheet = workbook.getSheet(appConfig.getInputSheet());

			Iterator<Row> rowIterator = sheet.iterator();

			// iterating over each row in excel sheet.
			
			while (rowIterator.hasNext()) {
			    Row row = rowIterator.next();
			    
			    // Check if row number matches the one in inputPartyDetails
			    if (loanEstatblish.getRownum() == row.getRowNum()) {
			        
			        // Set values in various columns (20-31)
			        row.createCell(34, CellType.STRING).setCellValue(loanEstatblish.getStatus());
			        row.createCell(35, CellType.STRING).setCellValue(loanEstatblish.getErrorMessage());
			        row.createCell(36, CellType.STRING).setCellValue(loanEstatblish.getOutLoanId());
			        //row.createCell(53, CellType.STRING).setCellValue(inputPartyDetails.getOutPutLoanApplicationId());
			        
			        // Build comma-separated string for loan applicants (if any)
			        String id = "";
			        String name = "";
			        String cutomerType ="";
			        if (loanEstatblish.getOutLoanApplicants() != null && !loanEstatblish.getOutLoanApplicants().isEmpty()) {
			            for (int i = 0; i < loanEstatblish.getOutLoanApplicants().size(); i++) {
			                if (i == 0) {
			                    id = loanEstatblish.getOutLoanApplicants().get(i).getCustomerId();
			                    name =  loanEstatblish.getOutLoanApplicants().get(i).getCustomerName();
			                    cutomerType =  loanEstatblish.getOutLoanApplicants().get(i).getCustomerType();
			                } else {
			                    id = id + ", " + loanEstatblish.getOutLoanApplicants().get(i).getCustomerId();
			                    name = name+ ", " + loanEstatblish.getOutLoanApplicants().get(i).getCustomerName();
			                    cutomerType = cutomerType+ ", " + loanEstatblish.getOutLoanApplicants().get(i).getCustomerType();
			                }
			            }
			        }
			        row.createCell(37, CellType.STRING).setCellValue(id);
			        row.createCell(38, CellType.STRING).setCellValue(name);
			        row.createCell(39, CellType.STRING).setCellValue(cutomerType);
			        row.createCell(40, CellType.STRING).setCellValue(loanEstatblish.getOutPutBranch());
			        // Set other columns (25-31)
			        row.createCell(41, CellType.STRING).setCellValue(loanEstatblish.getOutProductName());
			        row.createCell(42, CellType.STRING).setCellValue(loanEstatblish.getOutLoanPurpose());
			        row.createCell(43, CellType.STRING).setCellValue(loanEstatblish.getOutPutLoanAmount());
			        row.createCell(44, CellType.STRING).setCellValue(loanEstatblish.getOutPutCurrency());
			        row.createCell(45, CellType.STRING).setCellValue(loanEstatblish.getOutLoanStartDate());
			        row.createCell(46, CellType.STRING).setCellValue(loanEstatblish.getOutMaturityDate());
			        row.createCell(47, CellType.STRING).setCellValue(loanEstatblish.getOutRepaymentType());
			        if (loanEstatblish.getOutEffectiveInterestRate()==0)
			        	row.createCell(48, CellType.STRING).setCellValue("");
			        else 
			        	row.createCell(48, CellType.STRING).setCellValue(loanEstatblish.getOutEffectiveInterestRate());
			        row.createCell(49, CellType.STRING).setCellValue(loanEstatblish.getOutPutRepaymentStartDate());
			        
			        
			    }
			}

			 
			// Closing Input Stream.
			fis.close();

			FileOutputStream fos = new FileOutputStream(inputFile);

			// Write changes
			workbook.write(fos);

			// Closing Output Stream.
			fos.close();

		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}

	private static Object getCellValue(Cell cell) {
		if (cell == null) {
			return null;
		}

		switch (cell.getCellType()) {
		case STRING:
			return cell.getStringCellValue();
		case NUMERIC:
			if (DateUtil.isCellDateFormatted(cell)) {
				return cell.getLocalDateTimeCellValue().toString().substring(0, 10);
			} else {
				return String.valueOf(cell.getNumericCellValue()).split("\\.")[0];
			}
		case BOOLEAN:
			return cell.getBooleanCellValue();
		case FORMULA:
			return cell.getCellFormula();
		default:
			return null;
		}
	}

}