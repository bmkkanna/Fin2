package com.finastra.lending.data;

   
public class InterestDetails {

   FixedRateDetails fixedRateDetails;

   FloatingRateDetails floatingRateDetails;

   PeggingResetDetails peggingResetDetails;

   ProgressiveRateDetails progressiveRateDetails;

   RateEffectiveDateTime rateEffectiveDateTime;

   String rateType;

    public void setFixedRateDetails(FixedRateDetails fixedRateDetails) {
        this.fixedRateDetails = fixedRateDetails;
    }
    public FixedRateDetails getFixedRateDetails() {
        return fixedRateDetails;
    }
    
    public void setFloatingRateDetails(FloatingRateDetails floatingRateDetails) {
        this.floatingRateDetails = floatingRateDetails;
    }
    public FloatingRateDetails getFloatingRateDetails() {
        return floatingRateDetails;
    }
    
    public void setPeggingResetDetails(PeggingResetDetails peggingResetDetails) {
        this.peggingResetDetails = peggingResetDetails;
    }
    public PeggingResetDetails getPeggingResetDetails() {
        return peggingResetDetails;
    }
    
    public void setProgressiveRateDetails(ProgressiveRateDetails progressiveRateDetails) {
        this.progressiveRateDetails = progressiveRateDetails;
    }
    public ProgressiveRateDetails getProgressiveRateDetails() {
        return progressiveRateDetails;
    }
    
    public void setRateEffectiveDateTime(RateEffectiveDateTime rateEffectiveDateTime) {
        this.rateEffectiveDateTime = rateEffectiveDateTime;
    }
    public RateEffectiveDateTime getRateEffectiveDateTime() {
        return rateEffectiveDateTime;
    }
    
    public void setRateType(String rateType) {
        this.rateType = rateType;
    }
    public String getRateType() {
        return rateType;
    }
    
}