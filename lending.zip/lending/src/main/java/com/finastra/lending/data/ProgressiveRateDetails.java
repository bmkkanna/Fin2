package com.finastra.lending.data;

   
public class ProgressiveRateDetails {

   String postProgressiveRateType;

   String rateId;

   Spread spread;


    public void setPostProgressiveRateType(String postProgressiveRateType) {
        this.postProgressiveRateType = postProgressiveRateType;
    }
    public String getPostProgressiveRateType() {
        return postProgressiveRateType;
    }
    
    public void setRateId(String rateId) {
        this.rateId = rateId;
    }
    public String getRateId() {
        return rateId;
    }
    
    public void setSpread(Spread spread) {
        this.spread = spread;
    }
    public Spread getSpread() {
        return spread;
    }
    
}