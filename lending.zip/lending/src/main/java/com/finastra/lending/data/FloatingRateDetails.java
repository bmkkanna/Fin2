package com.finastra.lending.data;

   
public class FloatingRateDetails {

   String rateId;

   Spread spread;


    public void setRateId(String rateId) {
        this.rateId = rateId;
    }
    public String getRateId() {
        return rateId;
    }
    
    public void setSpread(Spread spread) {
        this.spread = spread;
    }
    public Spread getSpread() {
        return spread;
    }
    
}