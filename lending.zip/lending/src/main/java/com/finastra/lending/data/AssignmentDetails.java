package com.finastra.lending.data;


   
public class AssignmentDetails {

   String assignmentValueCalculation;

   String collateralId;

   FixedAssignment fixedAssignment;

   String percentageAssignment;


    public void setAssignmentValueCalculation(String assignmentValueCalculation) {
        this.assignmentValueCalculation = assignmentValueCalculation;
    }
    public String getAssignmentValueCalculation() {
        return assignmentValueCalculation;
    }
    
    public void setCollateralId(String collateralId) {
        this.collateralId = collateralId;
    }
    public String getCollateralId() {
        return collateralId;
    }
    
    public void setFixedAssignment(FixedAssignment fixedAssignment) {
        this.fixedAssignment = fixedAssignment;
    }
    public FixedAssignment getFixedAssignment() {
        return fixedAssignment;
    }
    
    public void setPercentageAssignment(String percentageAssignment) {
        this.percentageAssignment = percentageAssignment;
    }
    public String getPercentageAssignment() {
        return percentageAssignment;
    }
    
}