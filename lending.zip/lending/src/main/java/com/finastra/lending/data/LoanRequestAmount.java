package com.finastra.lending.data;

public class LoanRequestAmount {

	Object amount;

	Object currency;

	public void setAmount(Object amount) {
		this.amount = amount;
	}

	public Object getAmount() {
		return amount;
	}

	public void setCurrency(Object currency) {
		this.currency = currency;
	}

	public Object getCurrency() {
		return currency;
	}

}