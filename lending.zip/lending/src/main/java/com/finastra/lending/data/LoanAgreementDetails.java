package com.finastra.lending.data;


public class LoanAgreementDetails {

   boolean defaultLoanAgreementId;

   String loanAgreementId;

   StructuredAddress structuredAddress;


    public void setDefaultLoanAgreementId(boolean defaultLoanAgreementId) {
        this.defaultLoanAgreementId = defaultLoanAgreementId;
    }
    public boolean getDefaultLoanAgreementId() {
        return defaultLoanAgreementId;
    }
    
    public void setLoanAgreementId(String loanAgreementId) {
        this.loanAgreementId = loanAgreementId;
    }
    public String getLoanAgreementId() {
        return loanAgreementId;
    }
    
    public void setStructuredAddress(StructuredAddress structuredAddress) {
        this.structuredAddress = structuredAddress;
    }
    public StructuredAddress getStructuredAddress() {
        return structuredAddress;
    }
    
}