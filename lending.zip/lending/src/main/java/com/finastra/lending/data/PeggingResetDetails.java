package com.finastra.lending.data;

import java.util.Date;

   
public class PeggingResetDetails {

   String resetDate;

   String resetFrequency;


    public void setResetDate(String resetDate) {
        this.resetDate = resetDate;
    }
    public String getResetDate() {
        return resetDate;
    }
    
    public void setResetFrequency(String resetFrequency) {
        this.resetFrequency = resetFrequency;
    }
    public String getResetFrequency() {
        return resetFrequency;
    }
    
}