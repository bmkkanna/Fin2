package com.finastra.lending.data;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
@JsonIgnoreProperties(ignoreUnknown = true)
public class OutputLoanEstablishmentMain {

	String loanApplicationId;

	String loanId;

	List<OutputLoanApplicants> loanApplicants;
	
	public List<OutRepaymentSchedule> repaymentSchedule;

	public List<OutRepaymentSchedule> getOutRepaymentSchedules() {
		return repaymentSchedule;
	}

	public void setOutRepaymentSchedules(List<OutRepaymentSchedule> repaymentSchedule) {
		this.repaymentSchedule = repaymentSchedule;
	}

	String loanAccountBranch;

	String productName;

	String loanPurpose;

	OutputLoanRequestAmount loanRequestAmount;

	OutputCustomerContributionAmount customerContributionAmount;

	OutputPrincipalAmount principalAmount;

	String loanStartDate;

	LoanTerm loanTerm;

	String repaymentType;

	String repaymentFrequency;

	String maturityDate;

	String interestRateType;

	int productInterestRate;

	int customerInterestMargin;

	int effectiveInterestRate;

	String interestRatePostFixed;

	Date interestResetDate;

	String repaymentAccount;

	String feeCollectionAccount;

	int annualPercentageRate;

	public String getLoanApplicationId() {
		return loanApplicationId;
	}

	public void setLoanApplicationId(String loanApplicationId) {
		this.loanApplicationId = loanApplicationId;
	}

	public String getLoanId() {
		return loanId;
	}

	public void setLoanId(String loanId) {
		this.loanId = loanId;
	}

	public List<OutputLoanApplicants> getLoanApplicants() {
		return loanApplicants;
	}

	public void setLoanApplicants(List<OutputLoanApplicants> loanApplicants) {
		this.loanApplicants = loanApplicants;
	}

	public String getLoanAccountBranch() {
		return loanAccountBranch;
	}

	public void setLoanAccountBranch(String loanAccountBranch) {
		this.loanAccountBranch = loanAccountBranch;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public String getLoanPurpose() {
		return loanPurpose;
	}

	public void setLoanPurpose(String loanPurpose) {
		this.loanPurpose = loanPurpose;
	}

	public OutputLoanRequestAmount getLoanRequestAmount() {
		return loanRequestAmount;
	}

	public void setLoanRequestAmount(OutputLoanRequestAmount loanRequestAmount) {
		this.loanRequestAmount = loanRequestAmount;
	}

	public OutputCustomerContributionAmount getCustomerContributionAmount() {
		return customerContributionAmount;
	}

	public void setCustomerContributionAmount(OutputCustomerContributionAmount customerContributionAmount) {
		this.customerContributionAmount = customerContributionAmount;
	}

	public OutputPrincipalAmount getPrincipalAmount() {
		return principalAmount;
	}

	public void setPrincipalAmount(OutputPrincipalAmount principalAmount) {
		this.principalAmount = principalAmount;
	}

	public String getLoanStartDate() {
		return loanStartDate;
	}

	public void setLoanStartDate(String loanStartDate) {
		this.loanStartDate = loanStartDate;
	}

	public LoanTerm getLoanTerm() {
		return loanTerm;
	}

	public void setLoanTerm(LoanTerm loanTerm) {
		this.loanTerm = loanTerm;
	}

	public String getRepaymentType() {
		return repaymentType;
	}

	public void setRepaymentType(String repaymentType) {
		this.repaymentType = repaymentType;
	}

	public String getRepaymentFrequency() {
		return repaymentFrequency;
	}

	public void setRepaymentFrequency(String repaymentFrequency) {
		this.repaymentFrequency = repaymentFrequency;
	}

	public String getMaturityDate() {
		return maturityDate;
	}

	public void setMaturityDate(String maturityDate) {
		this.maturityDate = maturityDate;
	}

	public String getInterestRateType() {
		return interestRateType;
	}

	public void setInterestRateType(String interestRateType) {
		this.interestRateType = interestRateType;
	}

	public int getProductInterestRate() {
		return productInterestRate;
	}

	public void setProductInterestRate(int productInterestRate) {
		this.productInterestRate = productInterestRate;
	}

	public int getCustomerInterestMargin() {
		return customerInterestMargin;
	}

	public void setCustomerInterestMargin(int customerInterestMargin) {
		this.customerInterestMargin = customerInterestMargin;
	}

	public int getEffectiveInterestRate() {
		return effectiveInterestRate;
	}

	public void setEffectiveInterestRate(int effectiveInterestRate) {
		this.effectiveInterestRate = effectiveInterestRate;
	}

	public String getInterestRatePostFixed() {
		return interestRatePostFixed;
	}

	public void setInterestRatePostFixed(String interestRatePostFixed) {
		this.interestRatePostFixed = interestRatePostFixed;
	}

	public Date getInterestResetDate() {
		return interestResetDate;
	}

	public void setInterestResetDate(Date interestResetDate) {
		this.interestResetDate = interestResetDate;
	}

	public String getRepaymentAccount() {
		return repaymentAccount;
	}

	public void setRepaymentAccount(String repaymentAccount) {
		this.repaymentAccount = repaymentAccount;
	}

	public String getFeeCollectionAccount() {
		return feeCollectionAccount;
	}

	public void setFeeCollectionAccount(String feeCollectionAccount) {
		this.feeCollectionAccount = feeCollectionAccount;
	}

	public int getAnnualPercentageRate() {
		return annualPercentageRate;
	}

	public void setAnnualPercentageRate(int annualPercentageRate) {
		this.annualPercentageRate = annualPercentageRate;
	}

}